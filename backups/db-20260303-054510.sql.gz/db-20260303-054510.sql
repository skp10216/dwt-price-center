--
-- PostgreSQL database dump
--

\restrict zRr0SQPwVca2aEz6yC0BIzyY7THt5ouiHhPhbuufZdIC0F6a0EA6FdJPRIxW6dJ

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: adjustment_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.adjustment_type AS ENUM (
    'CORRECTION',
    'RETURN',
    'WRITE_OFF',
    'DISCOUNT'
);


ALTER TYPE public.adjustment_type OWNER TO dwt_user;

--
-- Name: audit_action; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.audit_action AS ENUM (
    'MODEL_CREATE',
    'MODEL_UPDATE',
    'MODEL_DEACTIVATE',
    'MODEL_BULK_CREATE',
    'MODEL_DELETE',
    'MODEL_BULK_DELETE',
    'GRADE_CREATE',
    'GRADE_UPDATE',
    'GRADE_DEACTIVATE',
    'PRICE_UPDATE',
    'DEDUCTION_CREATE',
    'DEDUCTION_UPDATE',
    'DEDUCTION_DEACTIVATE',
    'UPLOAD_START',
    'UPLOAD_COMPLETE',
    'UPLOAD_REVIEW',
    'UPLOAD_CONFIRM',
    'UPLOAD_APPLY',
    'UPLOAD_DELETE',
    'PARTNER_CREATE',
    'PARTNER_UPDATE',
    'PARTNER_DEACTIVATE',
    'PARTNER_MAPPING_UPDATE',
    'PARTNER_DELETE',
    'PARTNER_RESTORE',
    'PARTNER_MOVE',
    'BRANCH_CREATE',
    'BRANCH_UPDATE',
    'BRANCH_DELETE',
    'BRANCH_RESTORE',
    'USER_CREATE',
    'USER_UPDATE',
    'USER_DEACTIVATE',
    'USER_ROLE_CHANGE',
    'USER_LOGIN',
    'USER_LOGOUT',
    'VOUCHER_CREATE',
    'VOUCHER_UPDATE',
    'VOUCHER_DELETE',
    'VOUCHER_UPSERT',
    'VOUCHER_LOCK',
    'VOUCHER_UNLOCK',
    'VOUCHER_BATCH_LOCK',
    'VOUCHER_BATCH_UNLOCK',
    'RECEIPT_CREATE',
    'RECEIPT_DELETE',
    'PAYMENT_CREATE',
    'PAYMENT_DELETE',
    'COUNTERPARTY_CREATE',
    'COUNTERPARTY_UPDATE',
    'COUNTERPARTY_DELETE',
    'COUNTERPARTY_BATCH_DELETE',
    'COUNTERPARTY_BATCH_CREATE',
    'COUNTERPARTY_ALIAS_CREATE',
    'COUNTERPARTY_ALIAS_DELETE',
    'VOUCHER_CHANGE_DETECTED',
    'VOUCHER_CHANGE_APPROVED',
    'VOUCHER_CHANGE_REJECTED',
    'UPLOAD_TEMPLATE_CREATE',
    'UPLOAD_TEMPLATE_UPDATE',
    'TRANSACTION_CREATE',
    'TRANSACTION_UPDATE',
    'TRANSACTION_CANCEL',
    'TRANSACTION_HOLD',
    'TRANSACTION_UNHOLD',
    'TRANSACTION_HIDE',
    'TRANSACTION_UNHIDE',
    'ALLOCATION_CREATE',
    'ALLOCATION_DELETE',
    'ALLOCATION_AUTO',
    'NETTING_CREATE',
    'NETTING_CONFIRM',
    'NETTING_CANCEL',
    'ADJUSTMENT_VOUCHER_CREATE',
    'BANK_IMPORT_UPLOAD',
    'BANK_IMPORT_CONFIRM',
    'PERIOD_LOCK',
    'PERIOD_UNLOCK',
    'PERIOD_ADJUST'
);


ALTER TYPE public.audit_action OWNER TO dwt_user;

--
-- Name: bank_import_job_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.bank_import_job_status AS ENUM (
    'UPLOADED',
    'PARSED',
    'REVIEWING',
    'CONFIRMED',
    'FAILED'
);


ALTER TYPE public.bank_import_job_status OWNER TO dwt_user;

--
-- Name: bank_import_line_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.bank_import_line_status AS ENUM (
    'UNMATCHED',
    'MATCHED',
    'CONFIRMED',
    'DUPLICATE',
    'EXCLUDED'
);


ALTER TYPE public.bank_import_line_status OWNER TO dwt_user;

--
-- Name: change_request_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.change_request_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.change_request_status OWNER TO dwt_user;

--
-- Name: connectivity; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.connectivity AS ENUM (
    'LTE',
    'WIFI',
    'WIFI_CELLULAR',
    'STANDARD'
);


ALTER TYPE public.connectivity OWNER TO dwt_user;

--
-- Name: counterparty_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.counterparty_type AS ENUM (
    'SELLER',
    'BUYER',
    'BOTH'
);


ALTER TYPE public.counterparty_type OWNER TO dwt_user;

--
-- Name: device_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.device_type AS ENUM (
    'SMARTPHONE',
    'TABLET',
    'WEARABLE'
);


ALTER TYPE public.device_type OWNER TO dwt_user;

--
-- Name: job_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.job_status AS ENUM (
    'QUEUED',
    'RUNNING',
    'SUCCEEDED',
    'FAILED'
);


ALTER TYPE public.job_status OWNER TO dwt_user;

--
-- Name: job_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.job_type AS ENUM (
    'HQ_EXCEL',
    'PARTNER_EXCEL',
    'PARTNER_IMAGE',
    'VOUCHER_SALES_EXCEL',
    'VOUCHER_PURCHASE_EXCEL'
);


ALTER TYPE public.job_type OWNER TO dwt_user;

--
-- Name: manufacturer; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.manufacturer AS ENUM (
    'APPLE',
    'SAMSUNG',
    'OTHER'
);


ALTER TYPE public.manufacturer OWNER TO dwt_user;

--
-- Name: netting_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.netting_status AS ENUM (
    'DRAFT',
    'CONFIRMED',
    'CANCELLED'
);


ALTER TYPE public.netting_status OWNER TO dwt_user;

--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.payment_status AS ENUM (
    'UNPAID',
    'PARTIAL',
    'PAID',
    'LOCKED'
);


ALTER TYPE public.payment_status OWNER TO dwt_user;

--
-- Name: period_lock_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.period_lock_status AS ENUM (
    'OPEN',
    'LOCKED',
    'ADJUSTING'
);


ALTER TYPE public.period_lock_status OWNER TO dwt_user;

--
-- Name: settlement_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.settlement_status AS ENUM (
    'OPEN',
    'SETTLING',
    'SETTLED',
    'LOCKED'
);


ALTER TYPE public.settlement_status OWNER TO dwt_user;

--
-- Name: transaction_source; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_source AS ENUM (
    'MANUAL',
    'BANK_IMPORT',
    'NETTING'
);


ALTER TYPE public.transaction_source OWNER TO dwt_user;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_status AS ENUM (
    'PENDING',
    'PARTIAL',
    'ALLOCATED',
    'ON_HOLD',
    'HIDDEN',
    'CANCELLED'
);


ALTER TYPE public.transaction_status OWNER TO dwt_user;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_type AS ENUM (
    'DEPOSIT',
    'WITHDRAWAL'
);


ALTER TYPE public.transaction_type OWNER TO dwt_user;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.user_role AS ENUM (
    'ADMIN',
    'VIEWER',
    'SETTLEMENT'
);


ALTER TYPE public.user_role OWNER TO dwt_user;

--
-- Name: voucher_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.voucher_type AS ENUM (
    'SALES',
    'PURCHASE'
);


ALTER TYPE public.voucher_type OWNER TO dwt_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    trace_id uuid,
    user_id uuid NOT NULL,
    action public.audit_action NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid,
    before_data jsonb,
    after_data jsonb,
    description text,
    ip_address character varying(45),
    user_agent character varying(500),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO dwt_user;

--
-- Name: COLUMN audit_logs.trace_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.trace_id IS '추적 ID (업로드 작업 등 동일 작업 단위로 묶음)';


--
-- Name: COLUMN audit_logs.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.user_id IS '사용자 ID';


--
-- Name: COLUMN audit_logs.action; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.action IS '액션 타입';


--
-- Name: COLUMN audit_logs.target_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.target_type IS '대상 타입 (예: ssot_model, grade, deduction, upload_job)';


--
-- Name: COLUMN audit_logs.target_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.target_id IS '대상 ID';


--
-- Name: COLUMN audit_logs.before_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.before_data IS '변경 전 데이터';


--
-- Name: COLUMN audit_logs.after_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.after_data IS '변경 후 데이터';


--
-- Name: COLUMN audit_logs.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.description IS '변경 설명';


--
-- Name: COLUMN audit_logs.ip_address; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.ip_address IS 'IP 주소';


--
-- Name: COLUMN audit_logs.user_agent; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.user_agent IS 'User Agent';


--
-- Name: COLUMN audit_logs.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.created_at IS '생성 일시';


--
-- Name: bank_import_jobs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.bank_import_jobs (
    id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_hash character varying(64),
    bank_name character varying(100),
    account_number character varying(50),
    import_date_from date,
    import_date_to date,
    status public.bank_import_job_status NOT NULL,
    total_lines integer NOT NULL,
    matched_lines integer NOT NULL,
    confirmed_lines integer NOT NULL,
    error_message text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone,
    confirmed_at timestamp without time zone
);


ALTER TABLE public.bank_import_jobs OWNER TO dwt_user;

--
-- Name: COLUMN bank_import_jobs.file_path; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.file_path IS '파일 저장 경로';


--
-- Name: COLUMN bank_import_jobs.original_filename; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.original_filename IS '원본 파일명';


--
-- Name: COLUMN bank_import_jobs.file_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.file_hash IS '파일 해시 (중복 방지)';


--
-- Name: COLUMN bank_import_jobs.bank_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.bank_name IS '은행명';


--
-- Name: COLUMN bank_import_jobs.account_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.account_number IS '계좌번호';


--
-- Name: COLUMN bank_import_jobs.import_date_from; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.import_date_from IS '가져오기 기간 시작';


--
-- Name: COLUMN bank_import_jobs.import_date_to; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.import_date_to IS '가져오기 기간 끝';


--
-- Name: COLUMN bank_import_jobs.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.status IS '작업 상태';


--
-- Name: COLUMN bank_import_jobs.total_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.total_lines IS '전체 라인 수';


--
-- Name: COLUMN bank_import_jobs.matched_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.matched_lines IS '매칭된 라인 수';


--
-- Name: COLUMN bank_import_jobs.confirmed_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.confirmed_lines IS '확정된 라인 수';


--
-- Name: COLUMN bank_import_jobs.error_message; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.error_message IS '에러 메시지';


--
-- Name: COLUMN bank_import_jobs.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.created_by IS '등록자 ID';


--
-- Name: COLUMN bank_import_jobs.completed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.completed_at IS '파싱 완료 일시';


--
-- Name: COLUMN bank_import_jobs.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.confirmed_at IS '확정 일시';


--
-- Name: bank_import_lines; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.bank_import_lines (
    id uuid NOT NULL,
    import_job_id uuid NOT NULL,
    line_number integer NOT NULL,
    transaction_date date NOT NULL,
    description character varying(500) NOT NULL,
    amount numeric(18,2) NOT NULL,
    balance_after numeric(18,2),
    counterparty_name_raw character varying(200),
    counterparty_id uuid,
    status public.bank_import_line_status NOT NULL,
    match_confidence numeric(5,2),
    duplicate_key character varying(128),
    bank_reference character varying(100),
    transaction_id uuid,
    raw_data jsonb,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.bank_import_lines OWNER TO dwt_user;

--
-- Name: COLUMN bank_import_lines.import_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.import_job_id IS '임포트 작업 ID';


--
-- Name: COLUMN bank_import_lines.line_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.line_number IS '파일 내 행 번호';


--
-- Name: COLUMN bank_import_lines.transaction_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.transaction_date IS '거래일';


--
-- Name: COLUMN bank_import_lines.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.description IS '적요/설명';


--
-- Name: COLUMN bank_import_lines.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.amount IS '금액 (양수=입금, 음수=출금)';


--
-- Name: COLUMN bank_import_lines.balance_after; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.balance_after IS '거래 후 잔액';


--
-- Name: COLUMN bank_import_lines.counterparty_name_raw; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.counterparty_name_raw IS '원본 거래처명';


--
-- Name: COLUMN bank_import_lines.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.counterparty_id IS '매칭된 거래처 ID';


--
-- Name: COLUMN bank_import_lines.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.status IS '라인 상태';


--
-- Name: COLUMN bank_import_lines.match_confidence; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.match_confidence IS '매칭 신뢰도 (0-100%)';


--
-- Name: COLUMN bank_import_lines.duplicate_key; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.duplicate_key IS '중복 감지 키: hash(date+amount+description+bank_ref)';


--
-- Name: COLUMN bank_import_lines.bank_reference; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.bank_reference IS '은행 참조번호';


--
-- Name: COLUMN bank_import_lines.transaction_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.transaction_id IS '확정 후 연결된 Transaction ID';


--
-- Name: COLUMN bank_import_lines.raw_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.raw_data IS '원본 행 전체 (JSON)';


--
-- Name: branches; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.branches (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(100),
    contact_info character varying(200),
    memo text,
    is_active boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by uuid,
    delete_reason character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.branches OWNER TO dwt_user;

--
-- Name: COLUMN branches.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.name IS '지사명';


--
-- Name: COLUMN branches.region; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.region IS '지역';


--
-- Name: COLUMN branches.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.contact_info IS '연락처 정보';


--
-- Name: COLUMN branches.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.memo IS '운영 메모';


--
-- Name: COLUMN branches.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.is_active IS '활성 상태';


--
-- Name: COLUMN branches.deleted_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.deleted_at IS '삭제 일시 (소프트 삭제)';


--
-- Name: COLUMN branches.deleted_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.deleted_by IS '삭제한 사용자 ID';


--
-- Name: COLUMN branches.delete_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.delete_reason IS '삭제 사유';


--
-- Name: COLUMN branches.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.created_at IS '생성 일시';


--
-- Name: COLUMN branches.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.updated_at IS '수정 일시 (낙관적 락 version으로 사용)';


--
-- Name: compare_list_models; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.compare_list_models (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    added_by uuid
);


ALTER TABLE public.compare_list_models OWNER TO dwt_user;

--
-- Name: COLUMN compare_list_models.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN compare_list_models.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN compare_list_models.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.created_at IS '추가 일시';


--
-- Name: COLUMN compare_list_models.added_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.added_by IS '추가한 관리자 ID';


--
-- Name: counterparties; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparties (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(50),
    counterparty_type public.counterparty_type NOT NULL,
    branch_id uuid,
    contact_info character varying(500),
    memo text,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.counterparties OWNER TO dwt_user;

--
-- Name: COLUMN counterparties.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.name IS '시스템 표준 거래처명 (SSOT)';


--
-- Name: COLUMN counterparties.code; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.code IS '거래처 고유코드 (선택)';


--
-- Name: COLUMN counterparties.counterparty_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.counterparty_type IS '거래처 타입: seller(판매처)/buyer(매입처)/both(양쪽)';


--
-- Name: COLUMN counterparties.branch_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.branch_id IS '소속 지사 ID';


--
-- Name: COLUMN counterparties.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.contact_info IS '연락처 정보';


--
-- Name: COLUMN counterparties.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.memo IS '메모';


--
-- Name: COLUMN counterparties.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.is_active IS '활성 상태';


--
-- Name: counterparty_aliases; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparty_aliases (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    alias_name character varying(200) NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.counterparty_aliases OWNER TO dwt_user;

--
-- Name: COLUMN counterparty_aliases.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.counterparty_id IS '연결된 거래처 ID';


--
-- Name: COLUMN counterparty_aliases.alias_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.alias_name IS 'UPM 표기명 (별칭)';


--
-- Name: COLUMN counterparty_aliases.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.created_by IS '등록자 ID';


--
-- Name: counterparty_transactions; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparty_transactions (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    transaction_type public.transaction_type NOT NULL,
    transaction_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    allocated_amount numeric(18,2) NOT NULL,
    memo text,
    source public.transaction_source NOT NULL,
    bank_reference character varying(100),
    bank_import_line_id uuid,
    netting_record_id uuid,
    status public.transaction_status NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_ct_allocated_lte_amount CHECK ((allocated_amount <= amount)),
    CONSTRAINT ck_ct_allocated_nonneg CHECK ((allocated_amount >= (0)::numeric)),
    CONSTRAINT ck_ct_amount_positive CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.counterparty_transactions OWNER TO dwt_user;

--
-- Name: COLUMN counterparty_transactions.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.counterparty_id IS '거래처 ID';


--
-- Name: COLUMN counterparty_transactions.transaction_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.transaction_type IS 'DEPOSIT(입금)/WITHDRAWAL(출금)';


--
-- Name: COLUMN counterparty_transactions.transaction_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.transaction_date IS '입출금일';


--
-- Name: COLUMN counterparty_transactions.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.amount IS '금액 (양수만)';


--
-- Name: COLUMN counterparty_transactions.allocated_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.allocated_amount IS '배분 누적액 (비정규화)';


--
-- Name: COLUMN counterparty_transactions.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.memo IS '메모';


--
-- Name: COLUMN counterparty_transactions.source; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.source IS '발생 소스: MANUAL/BANK_IMPORT/NETTING';


--
-- Name: COLUMN counterparty_transactions.bank_reference; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.bank_reference IS '은행 참조번호 (중복 방지)';


--
-- Name: COLUMN counterparty_transactions.bank_import_line_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.bank_import_line_id IS '은행 임포트 라인 ID';


--
-- Name: COLUMN counterparty_transactions.netting_record_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.netting_record_id IS '상계 레코드 ID';


--
-- Name: COLUMN counterparty_transactions.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.status IS 'PENDING→PARTIAL→ALLOCATED / CANCELLED';


--
-- Name: COLUMN counterparty_transactions.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.created_by IS '등록자 ID';


--
-- Name: deduction_items; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.deduction_items (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.deduction_items OWNER TO dwt_user;

--
-- Name: COLUMN deduction_items.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.name IS '차감 항목명 (예: 내부 잔상, 서브 잔상, 줄감, 외관 찍힘, 카메라 불량)';


--
-- Name: COLUMN deduction_items.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.description IS '항목 설명';


--
-- Name: COLUMN deduction_items.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN deduction_items.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.is_active IS '활성 상태 (사용 중인 항목은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN deduction_items.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.created_at IS '생성 일시';


--
-- Name: COLUMN deduction_items.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.updated_at IS '수정 일시';


--
-- Name: deduction_levels; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.deduction_levels (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    amount integer NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.deduction_levels OWNER TO dwt_user;

--
-- Name: COLUMN deduction_levels.item_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.item_id IS '차감 항목 ID';


--
-- Name: COLUMN deduction_levels.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.name IS '레벨명 (예: L1, L2, L3, L4 또는 중상, 상, 대잔상)';


--
-- Name: COLUMN deduction_levels.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.amount IS '차감 금액 (원)';


--
-- Name: COLUMN deduction_levels.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.sort_order IS '정렬 순서 (낮을수록 상위, 보통 차감 금액 순)';


--
-- Name: COLUMN deduction_levels.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.is_active IS '활성 상태 (사용 중인 레벨은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN deduction_levels.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.created_at IS '생성 일시';


--
-- Name: COLUMN deduction_levels.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.updated_at IS '수정 일시';


--
-- Name: grade_prices; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.grade_prices (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    grade_id uuid NOT NULL,
    price integer NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grade_prices OWNER TO dwt_user;

--
-- Name: COLUMN grade_prices.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN grade_prices.grade_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.grade_id IS '등급 ID';


--
-- Name: COLUMN grade_prices.price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.price IS '등급별 기본가 (원)';


--
-- Name: COLUMN grade_prices.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.applied_at IS '적용 일시';


--
-- Name: COLUMN grade_prices.version; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.version IS '버전 (업로드/적용 시 증가)';


--
-- Name: COLUMN grade_prices.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.created_at IS '생성 일시';


--
-- Name: COLUMN grade_prices.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.updated_at IS '수정 일시';


--
-- Name: grades; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.grades (
    id uuid NOT NULL,
    name character varying(20) NOT NULL,
    description character varying(200),
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grades OWNER TO dwt_user;

--
-- Name: COLUMN grades.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.name IS '등급명 (예: A+, A, A-, B+, 수출, 기타)';


--
-- Name: COLUMN grades.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.description IS '등급 설명';


--
-- Name: COLUMN grades.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN grades.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.is_active IS '활성 상태 (사용 중인 등급은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN grades.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.is_default IS '기본 등급 여부 (비교 화면 기본 선택)';


--
-- Name: COLUMN grades.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.created_at IS '생성 일시';


--
-- Name: COLUMN grades.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.updated_at IS '수정 일시';


--
-- Name: hq_price_applies; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.hq_price_applies (
    id uuid NOT NULL,
    upload_job_id uuid NOT NULL,
    version integer NOT NULL,
    memo text,
    applied_count integer NOT NULL,
    price_changes jsonb,
    applied_by uuid NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    is_current boolean NOT NULL
);


ALTER TABLE public.hq_price_applies OWNER TO dwt_user;

--
-- Name: COLUMN hq_price_applies.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.upload_job_id IS '업로드 작업 ID';


--
-- Name: COLUMN hq_price_applies.version; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.version IS '적용 버전';


--
-- Name: COLUMN hq_price_applies.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.memo IS '적용 메모';


--
-- Name: COLUMN hq_price_applies.applied_count; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_count IS '적용된 모델 수';


--
-- Name: COLUMN hq_price_applies.price_changes; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.price_changes IS '가격 변경 요약';


--
-- Name: COLUMN hq_price_applies.applied_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_by IS '적용자 ID';


--
-- Name: COLUMN hq_price_applies.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_at IS '적용 일시';


--
-- Name: COLUMN hq_price_applies.is_current; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.is_current IS '현재 적용 중 여부';


--
-- Name: hq_price_apply_locks; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.hq_price_apply_locks (
    id integer NOT NULL,
    is_locked boolean NOT NULL,
    locked_by uuid,
    locked_at timestamp without time zone,
    lock_reason character varying(200)
);


ALTER TABLE public.hq_price_apply_locks OWNER TO dwt_user;

--
-- Name: COLUMN hq_price_apply_locks.id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.id IS '락 ID (항상 1)';


--
-- Name: COLUMN hq_price_apply_locks.is_locked; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.is_locked IS '락 상태';


--
-- Name: COLUMN hq_price_apply_locks.locked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.locked_by IS '락 소유자 ID';


--
-- Name: COLUMN hq_price_apply_locks.locked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.locked_at IS '락 시작 일시';


--
-- Name: COLUMN hq_price_apply_locks.lock_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.lock_reason IS '락 사유';


--
-- Name: netting_records; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.netting_records (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    netting_date date NOT NULL,
    netting_amount numeric(18,2) NOT NULL,
    status public.netting_status NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_nr_amount_positive CHECK ((netting_amount > (0)::numeric))
);


ALTER TABLE public.netting_records OWNER TO dwt_user;

--
-- Name: COLUMN netting_records.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.counterparty_id IS '거래처 ID';


--
-- Name: COLUMN netting_records.netting_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.netting_date IS '상계일';


--
-- Name: COLUMN netting_records.netting_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.netting_amount IS '상계 금액';


--
-- Name: COLUMN netting_records.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.status IS 'DRAFT→CONFIRMED / CANCELLED';


--
-- Name: COLUMN netting_records.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.memo IS '메모';


--
-- Name: COLUMN netting_records.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.created_by IS '생성자 ID';


--
-- Name: COLUMN netting_records.confirmed_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.confirmed_by IS '확정자 ID';


--
-- Name: COLUMN netting_records.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.confirmed_at IS '확정 일시';


--
-- Name: netting_voucher_links; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.netting_voucher_links (
    id uuid NOT NULL,
    netting_record_id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    netted_amount numeric(18,2) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_nvl_amount_positive CHECK ((netted_amount > (0)::numeric))
);


ALTER TABLE public.netting_voucher_links OWNER TO dwt_user;

--
-- Name: COLUMN netting_voucher_links.netting_record_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.netting_record_id IS '상계 레코드 ID';


--
-- Name: COLUMN netting_voucher_links.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.voucher_id IS '전표 ID';


--
-- Name: COLUMN netting_voucher_links.netted_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.netted_amount IS '상계 적용 금액';


--
-- Name: partner_mappings; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partner_mappings (
    id uuid NOT NULL,
    partner_id uuid NOT NULL,
    model_id uuid NOT NULL,
    partner_expression character varying(200) NOT NULL,
    confidence double precision NOT NULL,
    is_manual boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partner_mappings OWNER TO dwt_user;

--
-- Name: COLUMN partner_mappings.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.partner_id IS '거래처 ID';


--
-- Name: COLUMN partner_mappings.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN partner_mappings.partner_expression; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.partner_expression IS '거래처 원본 표기 (예: 아이폰15프로맥스 256)';


--
-- Name: COLUMN partner_mappings.confidence; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.confidence IS '매핑 신뢰도 (0.0 ~ 1.0, 수동 매핑은 1.0)';


--
-- Name: COLUMN partner_mappings.is_manual; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.is_manual IS '수동 매핑 여부';


--
-- Name: COLUMN partner_mappings.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.created_at IS '생성 일시';


--
-- Name: COLUMN partner_mappings.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.updated_at IS '수정 일시';


--
-- Name: partner_prices; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partner_prices (
    id uuid NOT NULL,
    partner_id uuid NOT NULL,
    model_id uuid NOT NULL,
    grade_id uuid NOT NULL,
    price integer NOT NULL,
    uploaded_at timestamp without time zone NOT NULL,
    upload_job_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partner_prices OWNER TO dwt_user;

--
-- Name: COLUMN partner_prices.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.partner_id IS '거래처 ID';


--
-- Name: COLUMN partner_prices.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN partner_prices.grade_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.grade_id IS '등급 ID';


--
-- Name: COLUMN partner_prices.price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.price IS '거래처 단가 (원)';


--
-- Name: COLUMN partner_prices.uploaded_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.uploaded_at IS '업로드 일시';


--
-- Name: COLUMN partner_prices.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.upload_job_id IS '업로드 작업 ID';


--
-- Name: COLUMN partner_prices.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.created_at IS '생성 일시';


--
-- Name: COLUMN partner_prices.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.updated_at IS '수정 일시';


--
-- Name: partners; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(100),
    contact_info character varying(200),
    memo text,
    branch_id uuid,
    is_active boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by uuid,
    delete_reason character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partners OWNER TO dwt_user;

--
-- Name: COLUMN partners.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.name IS '거래처명 (예: 부천, 광명, 서울, 부산, 대전)';


--
-- Name: COLUMN partners.region; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.region IS '지역';


--
-- Name: COLUMN partners.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.contact_info IS '연락처 정보';


--
-- Name: COLUMN partners.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.memo IS '운영 메모';


--
-- Name: COLUMN partners.branch_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.branch_id IS '소속 지사 ID';


--
-- Name: COLUMN partners.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.is_active IS '활성 상태';


--
-- Name: COLUMN partners.deleted_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.deleted_at IS '삭제 일시 (소프트 삭제)';


--
-- Name: COLUMN partners.deleted_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.deleted_by IS '삭제한 사용자 ID';


--
-- Name: COLUMN partners.delete_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.delete_reason IS '삭제 사유';


--
-- Name: COLUMN partners.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.created_at IS '생성 일시';


--
-- Name: COLUMN partners.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.updated_at IS '수정 일시';


--
-- Name: payments; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.payments (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    payment_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO dwt_user;

--
-- Name: COLUMN payments.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.voucher_id IS '전표 ID';


--
-- Name: COLUMN payments.payment_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.payment_date IS '송금일';


--
-- Name: COLUMN payments.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.amount IS '송금액';


--
-- Name: COLUMN payments.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.memo IS '메모';


--
-- Name: COLUMN payments.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.created_by IS '등록자 ID';


--
-- Name: period_locks; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.period_locks (
    id uuid NOT NULL,
    year_month character varying(7) NOT NULL,
    status public.period_lock_status NOT NULL,
    locked_voucher_count integer NOT NULL,
    locked_at timestamp without time zone,
    locked_by uuid,
    unlocked_at timestamp without time zone,
    unlocked_by uuid,
    memo text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.period_locks OWNER TO dwt_user;

--
-- Name: COLUMN period_locks.year_month; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.year_month IS '마감 기간 (YYYY-MM)';


--
-- Name: COLUMN period_locks.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.status IS 'OPEN/LOCKED/ADJUSTING';


--
-- Name: COLUMN period_locks.locked_voucher_count; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_voucher_count IS '마감된 전표 수';


--
-- Name: COLUMN period_locks.locked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_at IS '마감 일시';


--
-- Name: COLUMN period_locks.locked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_by IS '마감 담당자 ID';


--
-- Name: COLUMN period_locks.unlocked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.unlocked_at IS '해제 일시';


--
-- Name: COLUMN period_locks.unlocked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.unlocked_by IS '해제 담당자 ID';


--
-- Name: COLUMN period_locks.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.memo IS '메모';


--
-- Name: receipts; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.receipts (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    receipt_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.receipts OWNER TO dwt_user;

--
-- Name: COLUMN receipts.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.voucher_id IS '전표 ID';


--
-- Name: COLUMN receipts.receipt_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.receipt_date IS '입금일';


--
-- Name: COLUMN receipts.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.amount IS '입금액';


--
-- Name: COLUMN receipts.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.memo IS '메모';


--
-- Name: COLUMN receipts.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.created_by IS '등록자 ID';


--
-- Name: ssot_models; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.ssot_models (
    id uuid NOT NULL,
    model_key character varying(100) NOT NULL,
    model_code character varying(100) NOT NULL,
    device_type public.device_type NOT NULL,
    manufacturer public.manufacturer NOT NULL,
    series character varying(100) NOT NULL,
    model_name character varying(200) NOT NULL,
    storage_gb integer NOT NULL,
    connectivity public.connectivity NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ssot_models OWNER TO dwt_user;

--
-- Name: COLUMN ssot_models.model_key; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_key IS '불변 모델 키 (동일 기종 공유, 스토리지 미포함)';


--
-- Name: COLUMN ssot_models.model_code; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_code IS '모델 코드 (model_key + storage 조합, 불변)';


--
-- Name: COLUMN ssot_models.device_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.device_type IS '기기 타입: smartphone, tablet, wearable';


--
-- Name: COLUMN ssot_models.manufacturer; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.manufacturer IS '제조사: apple, samsung, other';


--
-- Name: COLUMN ssot_models.series; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.series IS '시리즈 (예: iPhone 15, Galaxy S24)';


--
-- Name: COLUMN ssot_models.model_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_name IS '모델명 (예: iPhone 15 Pro Max)';


--
-- Name: COLUMN ssot_models.storage_gb; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.storage_gb IS '스토리지 용량 (GB 단위, 1TB=1024)';


--
-- Name: COLUMN ssot_models.connectivity; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.connectivity IS '연결성: lte(스마트폰), wifi/wifi_cellular(태블릿), standard(웨어러블)';


--
-- Name: COLUMN ssot_models.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.is_active IS '활성 상태 (비활성화 시 Viewer 화면에서 숨김)';


--
-- Name: COLUMN ssot_models.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.created_at IS '생성 일시';


--
-- Name: COLUMN ssot_models.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.updated_at IS '수정 일시';


--
-- Name: transaction_allocations; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.transaction_allocations (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    allocated_amount numeric(18,2) NOT NULL,
    allocation_order integer NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_ta_amount_positive CHECK ((allocated_amount > (0)::numeric))
);


ALTER TABLE public.transaction_allocations OWNER TO dwt_user;

--
-- Name: COLUMN transaction_allocations.transaction_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.transaction_id IS '입출금 이벤트 ID';


--
-- Name: COLUMN transaction_allocations.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.voucher_id IS '전표 ID';


--
-- Name: COLUMN transaction_allocations.allocated_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.allocated_amount IS '배분 금액';


--
-- Name: COLUMN transaction_allocations.allocation_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.allocation_order IS '배분 순서 (FIFO 순서 기록)';


--
-- Name: COLUMN transaction_allocations.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.memo IS '메모';


--
-- Name: COLUMN transaction_allocations.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.created_by IS '등록자 ID';


--
-- Name: upload_jobs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.upload_jobs (
    id uuid NOT NULL,
    job_type public.job_type NOT NULL,
    status public.job_status NOT NULL,
    progress integer NOT NULL,
    file_path character varying(500) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_hash character varying(64),
    partner_id uuid,
    created_by uuid NOT NULL,
    result_summary jsonb,
    error_message text,
    is_reviewed boolean NOT NULL,
    is_confirmed boolean NOT NULL,
    is_applied boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    confirmed_at timestamp without time zone,
    applied_at timestamp without time zone
);


ALTER TABLE public.upload_jobs OWNER TO dwt_user;

--
-- Name: COLUMN upload_jobs.job_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.job_type IS '작업 타입: hq_excel, partner_excel, partner_image';


--
-- Name: COLUMN upload_jobs.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.status IS '작업 상태: queued, running, succeeded, failed';


--
-- Name: COLUMN upload_jobs.progress; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.progress IS '진행률 (0-100, 단계 기반: 0/25/50/75/100)';


--
-- Name: COLUMN upload_jobs.file_path; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.file_path IS '업로드 파일 경로';


--
-- Name: COLUMN upload_jobs.original_filename; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.original_filename IS '원본 파일명';


--
-- Name: COLUMN upload_jobs.file_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.file_hash IS '파일 해시 (중복 방지용)';


--
-- Name: COLUMN upload_jobs.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.partner_id IS '거래처 ID (거래처 업로드 시)';


--
-- Name: COLUMN upload_jobs.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.created_by IS '생성자 ID';


--
-- Name: COLUMN upload_jobs.result_summary; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.result_summary IS '결과 요약 (매핑/미매핑 개수, 오류 등)';


--
-- Name: COLUMN upload_jobs.error_message; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.error_message IS '오류 메시지 (실패 시)';


--
-- Name: COLUMN upload_jobs.is_reviewed; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_reviewed IS '검수 완료 여부';


--
-- Name: COLUMN upload_jobs.is_confirmed; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_confirmed IS '확정 여부';


--
-- Name: COLUMN upload_jobs.is_applied; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_applied IS '적용 여부 (본사 단가표)';


--
-- Name: COLUMN upload_jobs.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.created_at IS '생성 일시';


--
-- Name: COLUMN upload_jobs.started_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.started_at IS '시작 일시';


--
-- Name: COLUMN upload_jobs.completed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.completed_at IS '완료 일시';


--
-- Name: COLUMN upload_jobs.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.confirmed_at IS '확정 일시';


--
-- Name: COLUMN upload_jobs.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.applied_at IS '적용 일시';


--
-- Name: upload_templates; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.upload_templates (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    voucher_type public.voucher_type NOT NULL,
    column_mapping jsonb NOT NULL,
    skip_columns jsonb,
    is_default boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.upload_templates OWNER TO dwt_user;

--
-- Name: COLUMN upload_templates.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.name IS '템플릿명';


--
-- Name: COLUMN upload_templates.voucher_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.voucher_type IS '전표 타입: SALES/PURCHASE';


--
-- Name: COLUMN upload_templates.column_mapping; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.column_mapping IS 'DB 필드 → 엑셀 헤더 매핑';


--
-- Name: COLUMN upload_templates.skip_columns; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.skip_columns IS '파싱 시 무시할 컬럼 목록';


--
-- Name: COLUMN upload_templates.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.is_default IS '기본 템플릿 여부';


--
-- Name: COLUMN upload_templates.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.created_by IS '생성자 ID';


--
-- Name: user_counterparty_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_counterparty_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_counterparty_favorites OWNER TO dwt_user;

--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    model_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_favorites OWNER TO dwt_user;

--
-- Name: COLUMN user_favorites.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.user_id IS '사용자 ID';


--
-- Name: COLUMN user_favorites.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN user_favorites.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.created_at IS '즐겨찾기 추가 일시';


--
-- Name: user_list_items; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_list_items (
    id uuid NOT NULL,
    list_id uuid NOT NULL,
    model_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_list_items OWNER TO dwt_user;

--
-- Name: COLUMN user_list_items.list_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.list_id IS '리스트 ID';


--
-- Name: COLUMN user_list_items.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN user_list_items.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.created_at IS '추가 일시';


--
-- Name: user_lists; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_lists (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    is_default boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_lists OWNER TO dwt_user;

--
-- Name: COLUMN user_lists.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.user_id IS '사용자 ID';


--
-- Name: COLUMN user_lists.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.name IS '리스트 이름 (예: 아이폰 라인업, 갤럭시 A급)';


--
-- Name: COLUMN user_lists.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.description IS '리스트 설명';


--
-- Name: COLUMN user_lists.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.is_default IS '기본 리스트 여부 (로그인 시 기본으로 열릴 리스트)';


--
-- Name: COLUMN user_lists.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.created_at IS '생성 일시';


--
-- Name: COLUMN user_lists.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.updated_at IS '수정 일시';


--
-- Name: user_partner_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_partner_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_partner_favorites OWNER TO dwt_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    role public.user_role NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_login_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO dwt_user;

--
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.email IS '이메일 (로그인 ID)';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.password_hash IS '해시된 비밀번호';


--
-- Name: COLUMN users.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.name IS '사용자 이름';


--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.role IS '역할: admin(관리자), viewer(조회자)';


--
-- Name: COLUMN users.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.is_active IS '활성 상태 (비활성화 시 로그인 불가)';


--
-- Name: COLUMN users.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.created_at IS '생성 일시';


--
-- Name: COLUMN users.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.updated_at IS '수정 일시';


--
-- Name: COLUMN users.last_login_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.last_login_at IS '마지막 로그인 일시';


--
-- Name: voucher_change_requests; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.voucher_change_requests (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    upload_job_id uuid,
    before_data jsonb,
    after_data jsonb,
    diff_summary jsonb,
    status public.change_request_status NOT NULL,
    reviewed_by uuid,
    review_memo text,
    created_at timestamp without time zone NOT NULL,
    reviewed_at timestamp without time zone
);


ALTER TABLE public.voucher_change_requests OWNER TO dwt_user;

--
-- Name: COLUMN voucher_change_requests.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.voucher_id IS '변경 대상 전표 ID';


--
-- Name: COLUMN voucher_change_requests.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.upload_job_id IS '재업로드 Job ID';


--
-- Name: COLUMN voucher_change_requests.before_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.before_data IS '변경 전 데이터 스냅샷';


--
-- Name: COLUMN voucher_change_requests.after_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.after_data IS '변경 후 데이터 스냅샷';


--
-- Name: COLUMN voucher_change_requests.diff_summary; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.diff_summary IS '변경된 필드 요약 [{field, old, new}, ...]';


--
-- Name: COLUMN voucher_change_requests.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.status IS '승인 상태: pending/approved/rejected';


--
-- Name: COLUMN voucher_change_requests.reviewed_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.reviewed_by IS '검토자 ID';


--
-- Name: COLUMN voucher_change_requests.review_memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.review_memo IS '검토 메모';


--
-- Name: COLUMN voucher_change_requests.reviewed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.reviewed_at IS '검토 일시';


--
-- Name: vouchers; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.vouchers (
    id uuid NOT NULL,
    trade_date date NOT NULL,
    counterparty_id uuid NOT NULL,
    voucher_number character varying(50) NOT NULL,
    voucher_type public.voucher_type NOT NULL,
    quantity integer NOT NULL,
    total_amount numeric(18,2) NOT NULL,
    purchase_cost numeric(18,2),
    actual_purchase_price numeric(18,2),
    deduction_amount numeric(18,2),
    avg_unit_price numeric(18,2),
    upm_settlement_status character varying(50),
    payment_info character varying(500),
    purchase_deduction numeric(18,2),
    as_cost numeric(18,2),
    sale_amount numeric(18,2),
    sale_deduction numeric(18,2),
    actual_sale_price numeric(18,2),
    profit numeric(18,2),
    profit_rate numeric(8,2),
    avg_margin numeric(18,2),
    is_adjustment boolean NOT NULL,
    adjustment_type public.adjustment_type,
    original_voucher_id uuid,
    adjustment_reason text,
    settlement_status public.settlement_status NOT NULL,
    payment_status public.payment_status NOT NULL,
    memo text,
    upload_job_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.vouchers OWNER TO dwt_user;

--
-- Name: COLUMN vouchers.trade_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.trade_date IS '매입일/판매일';


--
-- Name: COLUMN vouchers.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.counterparty_id IS '매입처/판매처 → Counterparty';


--
-- Name: COLUMN vouchers.voucher_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.voucher_number IS 'UPM 전표 번호';


--
-- Name: COLUMN vouchers.voucher_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.voucher_type IS 'SALES(판매)/PURCHASE(매입)';


--
-- Name: COLUMN vouchers.quantity; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.quantity IS '수량';


--
-- Name: COLUMN vouchers.total_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.total_amount IS '정산 기준 금액 (매입:실매입가, 판매:실판매가)';


--
-- Name: COLUMN vouchers.purchase_cost; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.purchase_cost IS '매입원가';


--
-- Name: COLUMN vouchers.actual_purchase_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.actual_purchase_price IS '실매입가';


--
-- Name: COLUMN vouchers.deduction_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.deduction_amount IS '차감금액 (매입 전용)';


--
-- Name: COLUMN vouchers.avg_unit_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.avg_unit_price IS '평균가 (매입 전용)';


--
-- Name: COLUMN vouchers.upm_settlement_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.upm_settlement_status IS 'UPM 원본 정산현황 (검수대기/정산완료 등)';


--
-- Name: COLUMN vouchers.payment_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.payment_info IS '송금정보 (매입 전용)';


--
-- Name: COLUMN vouchers.purchase_deduction; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.purchase_deduction IS '매입차감 (판매 전용)';


--
-- Name: COLUMN vouchers.as_cost; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.as_cost IS 'A/S비용 (판매 전용)';


--
-- Name: COLUMN vouchers.sale_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.sale_amount IS '판매금액 (판매 전용)';


--
-- Name: COLUMN vouchers.sale_deduction; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.sale_deduction IS '판매차감 (판매 전용)';


--
-- Name: COLUMN vouchers.actual_sale_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.actual_sale_price IS '실판매가 (판매 전용)';


--
-- Name: COLUMN vouchers.profit; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.profit IS '손익 (판매 전용)';


--
-- Name: COLUMN vouchers.profit_rate; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.profit_rate IS '수익율 % (판매 전용)';


--
-- Name: COLUMN vouchers.avg_margin; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.avg_margin IS '평균마진 (판매 전용)';


--
-- Name: COLUMN vouchers.is_adjustment; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.is_adjustment IS '조정 전표 여부';


--
-- Name: COLUMN vouchers.adjustment_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.adjustment_type IS '조정 유형: CORRECTION/RETURN/WRITE_OFF/DISCOUNT';


--
-- Name: COLUMN vouchers.original_voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.original_voucher_id IS '원본 전표 ID (조정 전표일 경우)';


--
-- Name: COLUMN vouchers.adjustment_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.adjustment_reason IS '조정 사유';


--
-- Name: COLUMN vouchers.settlement_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.settlement_status IS '시스템 정산 상태';


--
-- Name: COLUMN vouchers.payment_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.payment_status IS '시스템 지급 상태';


--
-- Name: COLUMN vouchers.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.memo IS '비고';


--
-- Name: COLUMN vouchers.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.upload_job_id IS '업로드 Job ID';


--
-- Name: COLUMN vouchers.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.created_by IS '생성자 ID';


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.audit_logs (id, trace_id, user_id, action, target_type, target_id, before_data, after_data, description, ip_address, user_agent, created_at) FROM stdin;
05cb8816-60a2-4f15-b5a2-54c4564f0c1e	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 04:53:15.630484
9e8b382e-51bb-4b35-872b-117bb85a4206	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:29:45.37493
b21e2f7e-68dd-4cf9-a34f-e2014682fd3a	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:21.751357
788089f0-c874-4c34-a49e-0dbc1c2f63aa	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:28.183065
261ec018-5f7a-478c-800b-47408b0ca0ba	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:35.694154
e0b79914-141b-4306-8c05-e7debe6be677	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_CREATE	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	{"name": "skp10216", "role": "admin", "email": "skp10216@gmail.com"}	\N	\N	\N	2026-03-03 05:30:36.013231
2ce6ab25-91b8-4872-81c6-c05a0ace0ff8	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:31:45.550483
7d274d93-8d97-4ca0-82e7-84bfbe2491fe	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:31:52.695246
eaf6316a-3d03-417f-be46-9aa885918379	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:24.971431
518faef7-7fa1-4fb5-8e84-70cbbf9f98f3	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:30.33166
4b273608-758d-4655-9912-4c718dc4b392	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:31.504081
dad1fcfe-cb32-4a26-b4e9-0f684df3182f	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:32.288194
3130032a-7ac0-48f7-83bb-59c3e3ab31d5	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:33.662466
\.


--
-- Data for Name: bank_import_jobs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.bank_import_jobs (id, file_path, original_filename, file_hash, bank_name, account_number, import_date_from, import_date_to, status, total_lines, matched_lines, confirmed_lines, error_message, created_by, created_at, completed_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: bank_import_lines; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.bank_import_lines (id, import_job_id, line_number, transaction_date, description, amount, balance_after, counterparty_name_raw, counterparty_id, status, match_confidence, duplicate_key, bank_reference, transaction_id, raw_data, created_at) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.branches (id, name, region, contact_info, memo, is_active, deleted_at, deleted_by, delete_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compare_list_models; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.compare_list_models (id, model_id, sort_order, created_at, added_by) FROM stdin;
\.


--
-- Data for Name: counterparties; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparties (id, name, code, counterparty_type, branch_id, contact_info, memo, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: counterparty_aliases; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparty_aliases (id, counterparty_id, alias_name, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: counterparty_transactions; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparty_transactions (id, counterparty_id, transaction_type, transaction_date, amount, allocated_amount, memo, source, bank_reference, bank_import_line_id, netting_record_id, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deduction_items; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.deduction_items (id, name, description, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deduction_levels; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.deduction_levels (id, item_id, name, amount, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grade_prices; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.grade_prices (id, model_id, grade_id, price, applied_at, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.grades (id, name, description, sort_order, is_active, is_default, created_at, updated_at) FROM stdin;
2a408257-9c92-4c71-8161-5b8d12ba89c4	A+	\N	1	t	t	2026-03-03 03:45:43.512188	2026-03-03 03:45:43.512192
cee2cf94-10c3-4cfb-ba33-093500fe8266	A	\N	2	t	f	2026-03-03 03:45:43.5122	2026-03-03 03:45:43.512201
d62bfa81-f6a5-49ce-b693-f081789525e2	A-	\N	3	t	f	2026-03-03 03:45:43.512214	2026-03-03 03:45:43.512215
fe3ef5d5-8193-4e4b-8946-227697cbed37	B+	\N	4	t	f	2026-03-03 03:45:43.512222	2026-03-03 03:45:43.512223
06c732cb-6284-4f5a-8140-28bebfddae6f	B	\N	5	t	f	2026-03-03 03:45:43.512229	2026-03-03 03:45:43.51223
dff67739-90ae-495e-bab3-e87a88d13231	B-	\N	6	t	f	2026-03-03 03:45:43.512236	2026-03-03 03:45:43.512237
d4238379-0c8c-40a4-9396-204a20461e32	C	\N	7	t	f	2026-03-03 03:45:43.512244	2026-03-03 03:45:43.512245
f76baec2-2729-4985-b1cc-caa270c24c53	수출	\N	8	t	f	2026-03-03 03:45:43.51225	2026-03-03 03:45:43.512251
71dd1488-5b06-4eec-bc1c-80d11b7c76bf	기타	\N	9	t	f	2026-03-03 03:45:43.512257	2026-03-03 03:45:43.512257
\.


--
-- Data for Name: hq_price_applies; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.hq_price_applies (id, upload_job_id, version, memo, applied_count, price_changes, applied_by, applied_at, is_current) FROM stdin;
\.


--
-- Data for Name: hq_price_apply_locks; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.hq_price_apply_locks (id, is_locked, locked_by, locked_at, lock_reason) FROM stdin;
\.


--
-- Data for Name: netting_records; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.netting_records (id, counterparty_id, netting_date, netting_amount, status, memo, created_by, confirmed_by, confirmed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: netting_voucher_links; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.netting_voucher_links (id, netting_record_id, voucher_id, netted_amount, created_at) FROM stdin;
\.


--
-- Data for Name: partner_mappings; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partner_mappings (id, partner_id, model_id, partner_expression, confidence, is_manual, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: partner_prices; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partner_prices (id, partner_id, model_id, grade_id, price, uploaded_at, upload_job_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partners (id, name, region, contact_info, memo, branch_id, is_active, deleted_at, deleted_by, delete_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.payments (id, voucher_id, payment_date, amount, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: period_locks; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.period_locks (id, year_month, status, locked_voucher_count, locked_at, locked_by, unlocked_at, unlocked_by, memo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.receipts (id, voucher_id, receipt_date, amount, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: ssot_models; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.ssot_models (id, model_key, model_code, device_type, manufacturer, series, model_name, storage_gb, connectivity, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_allocations; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.transaction_allocations (id, transaction_id, voucher_id, allocated_amount, allocation_order, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: upload_jobs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.upload_jobs (id, job_type, status, progress, file_path, original_filename, file_hash, partner_id, created_by, result_summary, error_message, is_reviewed, is_confirmed, is_applied, created_at, started_at, completed_at, confirmed_at, applied_at) FROM stdin;
\.


--
-- Data for Name: upload_templates; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.upload_templates (id, name, voucher_type, column_mapping, skip_columns, is_default, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_counterparty_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_counterparty_favorites (id, user_id, counterparty_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_favorites (id, user_id, model_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_list_items; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_list_items (id, list_id, model_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_lists; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_lists (id, user_id, name, description, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_partner_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_partner_favorites (id, user_id, partner_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at, last_login_at) FROM stdin;
0445d86e-f791-4dad-baec-5f91deb57adc	admin@example.com	$2b$12$jc7/bU1kF5FqQsHjpAhq4Okl3V4I1r0ruJTS6b9.0HfbqRyNBYmwS	관리자	ADMIN	t	2026-03-03 03:45:43.501654	2026-03-03 05:30:35.693239	2026-03-03 05:30:35.692523
2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	skp10216@gmail.com	$2b$12$i8FkV7NUIgdc2Hm1rnEdvuBERh6aHr0qd5W1AQt.io.KR6rvUKMWK	skp10216	ADMIN	t	2026-03-03 05:30:36.011157	2026-03-03 05:44:33.661355	2026-03-03 05:44:33.660303
\.


--
-- Data for Name: voucher_change_requests; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.voucher_change_requests (id, voucher_id, upload_job_id, before_data, after_data, diff_summary, status, reviewed_by, review_memo, created_at, reviewed_at) FROM stdin;
\.


--
-- Data for Name: vouchers; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.vouchers (id, trade_date, counterparty_id, voucher_number, voucher_type, quantity, total_amount, purchase_cost, actual_purchase_price, deduction_amount, avg_unit_price, upm_settlement_status, payment_info, purchase_deduction, as_cost, sale_amount, sale_deduction, actual_sale_price, profit, profit_rate, avg_margin, is_adjustment, adjustment_type, original_voucher_id, adjustment_reason, settlement_status, payment_status, memo, upload_job_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_import_jobs bank_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_jobs
    ADD CONSTRAINT bank_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: bank_import_lines bank_import_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_pkey PRIMARY KEY (id);


--
-- Name: branches branches_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_name_key UNIQUE (name);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: compare_list_models compare_list_models_model_id_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_model_id_key UNIQUE (model_id);


--
-- Name: compare_list_models compare_list_models_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_pkey PRIMARY KEY (id);


--
-- Name: counterparties counterparties_code_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_code_key UNIQUE (code);


--
-- Name: counterparties counterparties_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_name_key UNIQUE (name);


--
-- Name: counterparties counterparties_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_pkey PRIMARY KEY (id);


--
-- Name: counterparty_aliases counterparty_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_pkey PRIMARY KEY (id);


--
-- Name: counterparty_transactions counterparty_transactions_bank_reference_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_bank_reference_key UNIQUE (bank_reference);


--
-- Name: counterparty_transactions counterparty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_pkey PRIMARY KEY (id);


--
-- Name: deduction_items deduction_items_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_items
    ADD CONSTRAINT deduction_items_name_key UNIQUE (name);


--
-- Name: deduction_items deduction_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_items
    ADD CONSTRAINT deduction_items_pkey PRIMARY KEY (id);


--
-- Name: deduction_levels deduction_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_levels
    ADD CONSTRAINT deduction_levels_pkey PRIMARY KEY (id);


--
-- Name: grade_prices grade_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_pkey PRIMARY KEY (id);


--
-- Name: grades grades_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_name_key UNIQUE (name);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: hq_price_applies hq_price_applies_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_pkey PRIMARY KEY (id);


--
-- Name: hq_price_apply_locks hq_price_apply_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_apply_locks
    ADD CONSTRAINT hq_price_apply_locks_pkey PRIMARY KEY (id);


--
-- Name: netting_records netting_records_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_pkey PRIMARY KEY (id);


--
-- Name: netting_voucher_links netting_voucher_links_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_pkey PRIMARY KEY (id);


--
-- Name: partner_mappings partner_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_pkey PRIMARY KEY (id);


--
-- Name: partner_prices partner_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_pkey PRIMARY KEY (id);


--
-- Name: partners partners_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_name_key UNIQUE (name);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: period_locks period_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_pkey PRIMARY KEY (id);


--
-- Name: ssot_models ssot_models_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.ssot_models
    ADD CONSTRAINT ssot_models_pkey PRIMARY KEY (id);


--
-- Name: transaction_allocations transaction_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_pkey PRIMARY KEY (id);


--
-- Name: upload_jobs upload_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_pkey PRIMARY KEY (id);


--
-- Name: upload_templates upload_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_templates
    ADD CONSTRAINT upload_templates_pkey PRIMARY KEY (id);


--
-- Name: counterparty_aliases uq_counterparty_alias_name; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT uq_counterparty_alias_name UNIQUE (alias_name);


--
-- Name: netting_voucher_links uq_nvl_netting_voucher; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT uq_nvl_netting_voucher UNIQUE (netting_record_id, voucher_id);


--
-- Name: period_locks uq_period_lock_year_month; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT uq_period_lock_year_month UNIQUE (year_month);


--
-- Name: transaction_allocations uq_ta_transaction_voucher; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT uq_ta_transaction_voucher UNIQUE (transaction_id, voucher_id);


--
-- Name: user_counterparty_favorites uq_user_counterparty_favorite; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT uq_user_counterparty_favorite UNIQUE (user_id, counterparty_id);


--
-- Name: user_partner_favorites uq_user_partner_favorite; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT uq_user_partner_favorite UNIQUE (user_id, partner_id);


--
-- Name: vouchers uq_voucher_counterparty_date_number; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT uq_voucher_counterparty_date_number UNIQUE (counterparty_id, trade_date, voucher_number);


--
-- Name: user_counterparty_favorites user_counterparty_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_list_items user_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_pkey PRIMARY KEY (id);


--
-- Name: user_lists user_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_lists
    ADD CONSTRAINT user_lists_pkey PRIMARY KEY (id);


--
-- Name: user_partner_favorites user_partner_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: voucher_change_requests voucher_change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_pkey PRIMARY KEY (id);


--
-- Name: vouchers vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_action_created; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_action_created ON public.audit_logs USING btree (action, created_at);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_target; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_target ON public.audit_logs USING btree (target_type, target_id);


--
-- Name: ix_audit_logs_trace_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_trace_id ON public.audit_logs USING btree (trace_id);


--
-- Name: ix_audit_logs_user_created; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_user_created ON public.audit_logs USING btree (user_id, created_at);


--
-- Name: ix_bij_created_at; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bij_created_at ON public.bank_import_jobs USING btree (created_at);


--
-- Name: ix_bij_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bij_status ON public.bank_import_jobs USING btree (status);


--
-- Name: ix_bil_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_counterparty ON public.bank_import_lines USING btree (counterparty_id);


--
-- Name: ix_bil_duplicate_key; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_duplicate_key ON public.bank_import_lines USING btree (duplicate_key);


--
-- Name: ix_bil_import_job; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_import_job ON public.bank_import_lines USING btree (import_job_id);


--
-- Name: ix_bil_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_status ON public.bank_import_lines USING btree (status);


--
-- Name: ix_compare_list_models_sort; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_compare_list_models_sort ON public.compare_list_models USING btree (sort_order);


--
-- Name: ix_ct_counterparty_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_counterparty_date ON public.counterparty_transactions USING btree (counterparty_id, transaction_date);


--
-- Name: ix_ct_source; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_source ON public.counterparty_transactions USING btree (source);


--
-- Name: ix_ct_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_status ON public.counterparty_transactions USING btree (status);


--
-- Name: ix_deduction_levels_item_name; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_deduction_levels_item_name ON public.deduction_levels USING btree (item_id, name);


--
-- Name: ix_grade_prices_model_grade; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_grade_prices_model_grade ON public.grade_prices USING btree (model_id, grade_id);


--
-- Name: ix_nr_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_counterparty ON public.netting_records USING btree (counterparty_id);


--
-- Name: ix_nr_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_date ON public.netting_records USING btree (netting_date);


--
-- Name: ix_nr_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_status ON public.netting_records USING btree (status);


--
-- Name: ix_partner_mappings_partner_expression; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_partner_mappings_partner_expression ON public.partner_mappings USING btree (partner_id, partner_expression);


--
-- Name: ix_partner_prices_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_partner_prices_model ON public.partner_prices USING btree (model_id);


--
-- Name: ix_partner_prices_partner_model_grade; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_partner_prices_partner_model_grade ON public.partner_prices USING btree (partner_id, model_id, grade_id);


--
-- Name: ix_payments_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_payments_voucher_id ON public.payments USING btree (voucher_id);


--
-- Name: ix_receipts_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_receipts_voucher_id ON public.receipts USING btree (voucher_id);


--
-- Name: ix_ssot_models_model_code; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_ssot_models_model_code ON public.ssot_models USING btree (model_code);


--
-- Name: ix_ssot_models_model_key; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_model_key ON public.ssot_models USING btree (model_key);


--
-- Name: ix_ssot_models_series; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_series ON public.ssot_models USING btree (series);


--
-- Name: ix_ssot_models_type_manufacturer; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_type_manufacturer ON public.ssot_models USING btree (device_type, manufacturer);


--
-- Name: ix_ta_transaction; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ta_transaction ON public.transaction_allocations USING btree (transaction_id);


--
-- Name: ix_ta_voucher; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ta_voucher ON public.transaction_allocations USING btree (voucher_id);


--
-- Name: ix_user_counterparty_favorites_user_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_counterparty_favorites_user_id ON public.user_counterparty_favorites USING btree (user_id);


--
-- Name: ix_user_favorites_user_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_favorites_user_model ON public.user_favorites USING btree (user_id, model_id);


--
-- Name: ix_user_list_items_list_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_list_items_list_model ON public.user_list_items USING btree (list_id, model_id);


--
-- Name: ix_user_lists_user; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_lists_user ON public.user_lists USING btree (user_id);


--
-- Name: ix_user_lists_user_name; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_lists_user_name ON public.user_lists USING btree (user_id, name);


--
-- Name: ix_user_partner_favorites_user_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_partner_favorites_user_id ON public.user_partner_favorites USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_voucher_change_requests_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_voucher_change_requests_voucher_id ON public.voucher_change_requests USING btree (voucher_id);


--
-- Name: ix_vouchers_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_counterparty ON public.vouchers USING btree (counterparty_id);


--
-- Name: ix_vouchers_trade_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_trade_date ON public.vouchers USING btree (trade_date);


--
-- Name: ix_vouchers_type_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_type_status ON public.vouchers USING btree (voucher_type, settlement_status);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_import_jobs bank_import_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_jobs
    ADD CONSTRAINT bank_import_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_import_lines bank_import_lines_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE SET NULL;


--
-- Name: bank_import_lines bank_import_lines_import_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_import_job_id_fkey FOREIGN KEY (import_job_id) REFERENCES public.bank_import_jobs(id) ON DELETE CASCADE;


--
-- Name: bank_import_lines bank_import_lines_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.counterparty_transactions(id) ON DELETE SET NULL;


--
-- Name: branches branches_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compare_list_models compare_list_models_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compare_list_models compare_list_models_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: counterparties counterparties_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: counterparty_aliases counterparty_aliases_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE CASCADE;


--
-- Name: counterparty_aliases counterparty_aliases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_bank_import_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_bank_import_line_id_fkey FOREIGN KEY (bank_import_line_id) REFERENCES public.bank_import_lines(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: counterparty_transactions counterparty_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_netting_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_netting_record_id_fkey FOREIGN KEY (netting_record_id) REFERENCES public.netting_records(id) ON DELETE SET NULL;


--
-- Name: deduction_levels deduction_levels_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_levels
    ADD CONSTRAINT deduction_levels_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.deduction_items(id) ON DELETE CASCADE;


--
-- Name: grade_prices grade_prices_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON DELETE RESTRICT;


--
-- Name: grade_prices grade_prices_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: hq_price_applies hq_price_applies_applied_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_applied_by_fkey FOREIGN KEY (applied_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hq_price_applies hq_price_applies_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: hq_price_apply_locks hq_price_apply_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_apply_locks
    ADD CONSTRAINT hq_price_apply_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_records netting_records_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_records netting_records_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: netting_records netting_records_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_voucher_links netting_voucher_links_netting_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_netting_record_id_fkey FOREIGN KEY (netting_record_id) REFERENCES public.netting_records(id) ON DELETE CASCADE;


--
-- Name: netting_voucher_links netting_voucher_links_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE RESTRICT;


--
-- Name: partner_mappings partner_mappings_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: partner_mappings partner_mappings_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON DELETE RESTRICT;


--
-- Name: partner_prices partner_prices_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: partners partners_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: partners partners_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: period_locks period_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: period_locks period_locks_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: receipts receipts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: receipts receipts_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: transaction_allocations transaction_allocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transaction_allocations transaction_allocations_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.counterparty_transactions(id) ON DELETE CASCADE;


--
-- Name: transaction_allocations transaction_allocations_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE RESTRICT;


--
-- Name: upload_jobs upload_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: upload_jobs upload_jobs_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: upload_templates upload_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_templates
    ADD CONSTRAINT upload_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_counterparty_favorites user_counterparty_favorites_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE CASCADE;


--
-- Name: user_counterparty_favorites user_counterparty_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_list_items user_list_items_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.user_lists(id) ON DELETE CASCADE;


--
-- Name: user_list_items user_list_items_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: user_lists user_lists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_lists
    ADD CONSTRAINT user_lists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_partner_favorites user_partner_favorites_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: user_partner_favorites user_partner_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: voucher_change_requests voucher_change_requests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: voucher_change_requests voucher_change_requests_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: voucher_change_requests voucher_change_requests_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: vouchers vouchers_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: vouchers vouchers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vouchers vouchers_original_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_original_voucher_id_fkey FOREIGN KEY (original_voucher_id) REFERENCES public.vouchers(id) ON DELETE SET NULL;


--
-- Name: vouchers vouchers_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict zRr0SQPwVca2aEz6yC0BIzyY7THt5ouiHhPhbuufZdIC0F6a0EA6FdJPRIxW6dJ

