--
-- PostgreSQL database dump
--

\restrict ztx4HWrBwCjaQYayCAHxHgO6Kg3CdfFIwhwfhAlgFlOJVJIoCgscvavpaHadioA

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: adjustment_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.adjustment_type AS ENUM (
    'CORRECTION',
    'RETURN',
    'WRITE_OFF',
    'DISCOUNT'
);


ALTER TYPE public.adjustment_type OWNER TO dwt_user;

--
-- Name: audit_action; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.audit_action AS ENUM (
    'MODEL_CREATE',
    'MODEL_UPDATE',
    'MODEL_DEACTIVATE',
    'MODEL_BULK_CREATE',
    'MODEL_DELETE',
    'MODEL_BULK_DELETE',
    'GRADE_CREATE',
    'GRADE_UPDATE',
    'GRADE_DEACTIVATE',
    'PRICE_UPDATE',
    'DEDUCTION_CREATE',
    'DEDUCTION_UPDATE',
    'DEDUCTION_DEACTIVATE',
    'UPLOAD_START',
    'UPLOAD_COMPLETE',
    'UPLOAD_REVIEW',
    'UPLOAD_CONFIRM',
    'UPLOAD_APPLY',
    'UPLOAD_DELETE',
    'PARTNER_CREATE',
    'PARTNER_UPDATE',
    'PARTNER_DEACTIVATE',
    'PARTNER_MAPPING_UPDATE',
    'PARTNER_DELETE',
    'PARTNER_RESTORE',
    'PARTNER_MOVE',
    'BRANCH_CREATE',
    'BRANCH_UPDATE',
    'BRANCH_DELETE',
    'BRANCH_RESTORE',
    'USER_CREATE',
    'USER_UPDATE',
    'USER_DEACTIVATE',
    'USER_ROLE_CHANGE',
    'USER_LOGIN',
    'USER_LOGOUT',
    'VOUCHER_CREATE',
    'VOUCHER_UPDATE',
    'VOUCHER_DELETE',
    'VOUCHER_UPSERT',
    'VOUCHER_LOCK',
    'VOUCHER_UNLOCK',
    'VOUCHER_BATCH_LOCK',
    'VOUCHER_BATCH_UNLOCK',
    'RECEIPT_CREATE',
    'RECEIPT_DELETE',
    'PAYMENT_CREATE',
    'PAYMENT_DELETE',
    'COUNTERPARTY_CREATE',
    'COUNTERPARTY_UPDATE',
    'COUNTERPARTY_DELETE',
    'COUNTERPARTY_BATCH_DELETE',
    'COUNTERPARTY_BATCH_CREATE',
    'COUNTERPARTY_ALIAS_CREATE',
    'COUNTERPARTY_ALIAS_DELETE',
    'VOUCHER_CHANGE_DETECTED',
    'VOUCHER_CHANGE_APPROVED',
    'VOUCHER_CHANGE_REJECTED',
    'UPLOAD_TEMPLATE_CREATE',
    'UPLOAD_TEMPLATE_UPDATE',
    'TRANSACTION_CREATE',
    'TRANSACTION_UPDATE',
    'TRANSACTION_CANCEL',
    'TRANSACTION_HOLD',
    'TRANSACTION_UNHOLD',
    'TRANSACTION_HIDE',
    'TRANSACTION_UNHIDE',
    'ALLOCATION_CREATE',
    'ALLOCATION_DELETE',
    'ALLOCATION_AUTO',
    'NETTING_CREATE',
    'NETTING_CONFIRM',
    'NETTING_CANCEL',
    'ADJUSTMENT_VOUCHER_CREATE',
    'BANK_IMPORT_UPLOAD',
    'BANK_IMPORT_CONFIRM',
    'PERIOD_LOCK',
    'PERIOD_UNLOCK',
    'PERIOD_ADJUST'
);


ALTER TYPE public.audit_action OWNER TO dwt_user;

--
-- Name: bank_import_job_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.bank_import_job_status AS ENUM (
    'UPLOADED',
    'PARSED',
    'REVIEWING',
    'CONFIRMED',
    'FAILED'
);


ALTER TYPE public.bank_import_job_status OWNER TO dwt_user;

--
-- Name: bank_import_line_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.bank_import_line_status AS ENUM (
    'UNMATCHED',
    'MATCHED',
    'CONFIRMED',
    'DUPLICATE',
    'EXCLUDED'
);


ALTER TYPE public.bank_import_line_status OWNER TO dwt_user;

--
-- Name: change_request_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.change_request_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.change_request_status OWNER TO dwt_user;

--
-- Name: connectivity; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.connectivity AS ENUM (
    'LTE',
    'WIFI',
    'WIFI_CELLULAR',
    'STANDARD'
);


ALTER TYPE public.connectivity OWNER TO dwt_user;

--
-- Name: counterparty_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.counterparty_type AS ENUM (
    'SELLER',
    'BUYER',
    'BOTH'
);


ALTER TYPE public.counterparty_type OWNER TO dwt_user;

--
-- Name: device_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.device_type AS ENUM (
    'SMARTPHONE',
    'TABLET',
    'WEARABLE'
);


ALTER TYPE public.device_type OWNER TO dwt_user;

--
-- Name: job_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.job_status AS ENUM (
    'QUEUED',
    'RUNNING',
    'SUCCEEDED',
    'FAILED'
);


ALTER TYPE public.job_status OWNER TO dwt_user;

--
-- Name: job_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.job_type AS ENUM (
    'HQ_EXCEL',
    'PARTNER_EXCEL',
    'PARTNER_IMAGE',
    'VOUCHER_SALES_EXCEL',
    'VOUCHER_PURCHASE_EXCEL'
);


ALTER TYPE public.job_type OWNER TO dwt_user;

--
-- Name: manufacturer; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.manufacturer AS ENUM (
    'APPLE',
    'SAMSUNG',
    'OTHER'
);


ALTER TYPE public.manufacturer OWNER TO dwt_user;

--
-- Name: netting_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.netting_status AS ENUM (
    'DRAFT',
    'CONFIRMED',
    'CANCELLED'
);


ALTER TYPE public.netting_status OWNER TO dwt_user;

--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.payment_status AS ENUM (
    'UNPAID',
    'PARTIAL',
    'PAID',
    'LOCKED'
);


ALTER TYPE public.payment_status OWNER TO dwt_user;

--
-- Name: period_lock_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.period_lock_status AS ENUM (
    'OPEN',
    'LOCKED',
    'ADJUSTING'
);


ALTER TYPE public.period_lock_status OWNER TO dwt_user;

--
-- Name: settlement_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.settlement_status AS ENUM (
    'OPEN',
    'SETTLING',
    'SETTLED',
    'LOCKED'
);


ALTER TYPE public.settlement_status OWNER TO dwt_user;

--
-- Name: transaction_source; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_source AS ENUM (
    'MANUAL',
    'BANK_IMPORT',
    'NETTING'
);


ALTER TYPE public.transaction_source OWNER TO dwt_user;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_status AS ENUM (
    'PENDING',
    'PARTIAL',
    'ALLOCATED',
    'ON_HOLD',
    'HIDDEN',
    'CANCELLED'
);


ALTER TYPE public.transaction_status OWNER TO dwt_user;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_type AS ENUM (
    'DEPOSIT',
    'WITHDRAWAL'
);


ALTER TYPE public.transaction_type OWNER TO dwt_user;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.user_role AS ENUM (
    'ADMIN',
    'VIEWER',
    'SETTLEMENT'
);


ALTER TYPE public.user_role OWNER TO dwt_user;

--
-- Name: voucher_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.voucher_type AS ENUM (
    'SALES',
    'PURCHASE'
);


ALTER TYPE public.voucher_type OWNER TO dwt_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    trace_id uuid,
    user_id uuid NOT NULL,
    action public.audit_action NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid,
    before_data jsonb,
    after_data jsonb,
    description text,
    ip_address character varying(45),
    user_agent character varying(500),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO dwt_user;

--
-- Name: COLUMN audit_logs.trace_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.trace_id IS '추적 ID (업로드 작업 등 동일 작업 단위로 묶음)';


--
-- Name: COLUMN audit_logs.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.user_id IS '사용자 ID';


--
-- Name: COLUMN audit_logs.action; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.action IS '액션 타입';


--
-- Name: COLUMN audit_logs.target_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.target_type IS '대상 타입 (예: ssot_model, grade, deduction, upload_job)';


--
-- Name: COLUMN audit_logs.target_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.target_id IS '대상 ID';


--
-- Name: COLUMN audit_logs.before_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.before_data IS '변경 전 데이터';


--
-- Name: COLUMN audit_logs.after_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.after_data IS '변경 후 데이터';


--
-- Name: COLUMN audit_logs.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.description IS '변경 설명';


--
-- Name: COLUMN audit_logs.ip_address; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.ip_address IS 'IP 주소';


--
-- Name: COLUMN audit_logs.user_agent; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.user_agent IS 'User Agent';


--
-- Name: COLUMN audit_logs.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.created_at IS '생성 일시';


--
-- Name: bank_import_jobs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.bank_import_jobs (
    id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_hash character varying(64),
    bank_name character varying(100),
    account_number character varying(50),
    import_date_from date,
    import_date_to date,
    status public.bank_import_job_status NOT NULL,
    total_lines integer NOT NULL,
    matched_lines integer NOT NULL,
    confirmed_lines integer NOT NULL,
    error_message text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone,
    confirmed_at timestamp without time zone
);


ALTER TABLE public.bank_import_jobs OWNER TO dwt_user;

--
-- Name: COLUMN bank_import_jobs.file_path; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.file_path IS '파일 저장 경로';


--
-- Name: COLUMN bank_import_jobs.original_filename; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.original_filename IS '원본 파일명';


--
-- Name: COLUMN bank_import_jobs.file_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.file_hash IS '파일 해시 (중복 방지)';


--
-- Name: COLUMN bank_import_jobs.bank_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.bank_name IS '은행명';


--
-- Name: COLUMN bank_import_jobs.account_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.account_number IS '계좌번호';


--
-- Name: COLUMN bank_import_jobs.import_date_from; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.import_date_from IS '가져오기 기간 시작';


--
-- Name: COLUMN bank_import_jobs.import_date_to; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.import_date_to IS '가져오기 기간 끝';


--
-- Name: COLUMN bank_import_jobs.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.status IS '작업 상태';


--
-- Name: COLUMN bank_import_jobs.total_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.total_lines IS '전체 라인 수';


--
-- Name: COLUMN bank_import_jobs.matched_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.matched_lines IS '매칭된 라인 수';


--
-- Name: COLUMN bank_import_jobs.confirmed_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.confirmed_lines IS '확정된 라인 수';


--
-- Name: COLUMN bank_import_jobs.error_message; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.error_message IS '에러 메시지';


--
-- Name: COLUMN bank_import_jobs.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.created_by IS '등록자 ID';


--
-- Name: COLUMN bank_import_jobs.completed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.completed_at IS '파싱 완료 일시';


--
-- Name: COLUMN bank_import_jobs.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.confirmed_at IS '확정 일시';


--
-- Name: bank_import_lines; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.bank_import_lines (
    id uuid NOT NULL,
    import_job_id uuid NOT NULL,
    line_number integer NOT NULL,
    transaction_date date NOT NULL,
    description character varying(500) NOT NULL,
    amount numeric(18,2) NOT NULL,
    balance_after numeric(18,2),
    counterparty_name_raw character varying(200),
    counterparty_id uuid,
    status public.bank_import_line_status NOT NULL,
    match_confidence numeric(5,2),
    duplicate_key character varying(128),
    bank_reference character varying(100),
    transaction_id uuid,
    raw_data jsonb,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.bank_import_lines OWNER TO dwt_user;

--
-- Name: COLUMN bank_import_lines.import_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.import_job_id IS '임포트 작업 ID';


--
-- Name: COLUMN bank_import_lines.line_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.line_number IS '파일 내 행 번호';


--
-- Name: COLUMN bank_import_lines.transaction_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.transaction_date IS '거래일';


--
-- Name: COLUMN bank_import_lines.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.description IS '적요/설명';


--
-- Name: COLUMN bank_import_lines.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.amount IS '금액 (양수=입금, 음수=출금)';


--
-- Name: COLUMN bank_import_lines.balance_after; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.balance_after IS '거래 후 잔액';


--
-- Name: COLUMN bank_import_lines.counterparty_name_raw; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.counterparty_name_raw IS '원본 거래처명';


--
-- Name: COLUMN bank_import_lines.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.counterparty_id IS '매칭된 거래처 ID';


--
-- Name: COLUMN bank_import_lines.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.status IS '라인 상태';


--
-- Name: COLUMN bank_import_lines.match_confidence; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.match_confidence IS '매칭 신뢰도 (0-100%)';


--
-- Name: COLUMN bank_import_lines.duplicate_key; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.duplicate_key IS '중복 감지 키: hash(date+amount+description+bank_ref)';


--
-- Name: COLUMN bank_import_lines.bank_reference; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.bank_reference IS '은행 참조번호';


--
-- Name: COLUMN bank_import_lines.transaction_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.transaction_id IS '확정 후 연결된 Transaction ID';


--
-- Name: COLUMN bank_import_lines.raw_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.raw_data IS '원본 행 전체 (JSON)';


--
-- Name: branches; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.branches (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(100),
    contact_info character varying(200),
    memo text,
    is_active boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by uuid,
    delete_reason character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.branches OWNER TO dwt_user;

--
-- Name: COLUMN branches.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.name IS '지사명';


--
-- Name: COLUMN branches.region; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.region IS '지역';


--
-- Name: COLUMN branches.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.contact_info IS '연락처 정보';


--
-- Name: COLUMN branches.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.memo IS '운영 메모';


--
-- Name: COLUMN branches.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.is_active IS '활성 상태';


--
-- Name: COLUMN branches.deleted_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.deleted_at IS '삭제 일시 (소프트 삭제)';


--
-- Name: COLUMN branches.deleted_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.deleted_by IS '삭제한 사용자 ID';


--
-- Name: COLUMN branches.delete_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.delete_reason IS '삭제 사유';


--
-- Name: COLUMN branches.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.created_at IS '생성 일시';


--
-- Name: COLUMN branches.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.updated_at IS '수정 일시 (낙관적 락 version으로 사용)';


--
-- Name: compare_list_models; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.compare_list_models (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    added_by uuid
);


ALTER TABLE public.compare_list_models OWNER TO dwt_user;

--
-- Name: COLUMN compare_list_models.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN compare_list_models.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN compare_list_models.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.created_at IS '추가 일시';


--
-- Name: COLUMN compare_list_models.added_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.added_by IS '추가한 관리자 ID';


--
-- Name: counterparties; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparties (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(50),
    counterparty_type public.counterparty_type NOT NULL,
    branch_id uuid,
    contact_info character varying(500),
    memo text,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.counterparties OWNER TO dwt_user;

--
-- Name: COLUMN counterparties.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.name IS '시스템 표준 거래처명 (SSOT)';


--
-- Name: COLUMN counterparties.code; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.code IS '거래처 고유코드 (선택)';


--
-- Name: COLUMN counterparties.counterparty_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.counterparty_type IS '거래처 타입: seller(판매처)/buyer(매입처)/both(양쪽)';


--
-- Name: COLUMN counterparties.branch_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.branch_id IS '소속 지사 ID';


--
-- Name: COLUMN counterparties.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.contact_info IS '연락처 정보';


--
-- Name: COLUMN counterparties.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.memo IS '메모';


--
-- Name: COLUMN counterparties.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.is_active IS '활성 상태';


--
-- Name: counterparty_aliases; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparty_aliases (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    alias_name character varying(200) NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.counterparty_aliases OWNER TO dwt_user;

--
-- Name: COLUMN counterparty_aliases.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.counterparty_id IS '연결된 거래처 ID';


--
-- Name: COLUMN counterparty_aliases.alias_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.alias_name IS 'UPM 표기명 (별칭)';


--
-- Name: COLUMN counterparty_aliases.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.created_by IS '등록자 ID';


--
-- Name: counterparty_transactions; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparty_transactions (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    transaction_type public.transaction_type NOT NULL,
    transaction_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    allocated_amount numeric(18,2) NOT NULL,
    memo text,
    source public.transaction_source NOT NULL,
    bank_reference character varying(100),
    bank_import_line_id uuid,
    netting_record_id uuid,
    status public.transaction_status NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_ct_allocated_lte_amount CHECK ((allocated_amount <= amount)),
    CONSTRAINT ck_ct_allocated_nonneg CHECK ((allocated_amount >= (0)::numeric)),
    CONSTRAINT ck_ct_amount_positive CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.counterparty_transactions OWNER TO dwt_user;

--
-- Name: COLUMN counterparty_transactions.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.counterparty_id IS '거래처 ID';


--
-- Name: COLUMN counterparty_transactions.transaction_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.transaction_type IS 'DEPOSIT(입금)/WITHDRAWAL(출금)';


--
-- Name: COLUMN counterparty_transactions.transaction_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.transaction_date IS '입출금일';


--
-- Name: COLUMN counterparty_transactions.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.amount IS '금액 (양수만)';


--
-- Name: COLUMN counterparty_transactions.allocated_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.allocated_amount IS '배분 누적액 (비정규화)';


--
-- Name: COLUMN counterparty_transactions.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.memo IS '메모';


--
-- Name: COLUMN counterparty_transactions.source; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.source IS '발생 소스: MANUAL/BANK_IMPORT/NETTING';


--
-- Name: COLUMN counterparty_transactions.bank_reference; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.bank_reference IS '은행 참조번호 (중복 방지)';


--
-- Name: COLUMN counterparty_transactions.bank_import_line_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.bank_import_line_id IS '은행 임포트 라인 ID';


--
-- Name: COLUMN counterparty_transactions.netting_record_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.netting_record_id IS '상계 레코드 ID';


--
-- Name: COLUMN counterparty_transactions.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.status IS 'PENDING→PARTIAL→ALLOCATED / CANCELLED';


--
-- Name: COLUMN counterparty_transactions.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.created_by IS '등록자 ID';


--
-- Name: deduction_items; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.deduction_items (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.deduction_items OWNER TO dwt_user;

--
-- Name: COLUMN deduction_items.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.name IS '차감 항목명 (예: 내부 잔상, 서브 잔상, 줄감, 외관 찍힘, 카메라 불량)';


--
-- Name: COLUMN deduction_items.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.description IS '항목 설명';


--
-- Name: COLUMN deduction_items.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN deduction_items.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.is_active IS '활성 상태 (사용 중인 항목은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN deduction_items.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.created_at IS '생성 일시';


--
-- Name: COLUMN deduction_items.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.updated_at IS '수정 일시';


--
-- Name: deduction_levels; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.deduction_levels (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    amount integer NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.deduction_levels OWNER TO dwt_user;

--
-- Name: COLUMN deduction_levels.item_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.item_id IS '차감 항목 ID';


--
-- Name: COLUMN deduction_levels.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.name IS '레벨명 (예: L1, L2, L3, L4 또는 중상, 상, 대잔상)';


--
-- Name: COLUMN deduction_levels.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.amount IS '차감 금액 (원)';


--
-- Name: COLUMN deduction_levels.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.sort_order IS '정렬 순서 (낮을수록 상위, 보통 차감 금액 순)';


--
-- Name: COLUMN deduction_levels.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.is_active IS '활성 상태 (사용 중인 레벨은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN deduction_levels.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.created_at IS '생성 일시';


--
-- Name: COLUMN deduction_levels.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.updated_at IS '수정 일시';


--
-- Name: grade_prices; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.grade_prices (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    grade_id uuid NOT NULL,
    price integer NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grade_prices OWNER TO dwt_user;

--
-- Name: COLUMN grade_prices.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN grade_prices.grade_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.grade_id IS '등급 ID';


--
-- Name: COLUMN grade_prices.price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.price IS '등급별 기본가 (원)';


--
-- Name: COLUMN grade_prices.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.applied_at IS '적용 일시';


--
-- Name: COLUMN grade_prices.version; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.version IS '버전 (업로드/적용 시 증가)';


--
-- Name: COLUMN grade_prices.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.created_at IS '생성 일시';


--
-- Name: COLUMN grade_prices.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.updated_at IS '수정 일시';


--
-- Name: grades; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.grades (
    id uuid NOT NULL,
    name character varying(20) NOT NULL,
    description character varying(200),
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grades OWNER TO dwt_user;

--
-- Name: COLUMN grades.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.name IS '등급명 (예: A+, A, A-, B+, 수출, 기타)';


--
-- Name: COLUMN grades.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.description IS '등급 설명';


--
-- Name: COLUMN grades.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN grades.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.is_active IS '활성 상태 (사용 중인 등급은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN grades.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.is_default IS '기본 등급 여부 (비교 화면 기본 선택)';


--
-- Name: COLUMN grades.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.created_at IS '생성 일시';


--
-- Name: COLUMN grades.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.updated_at IS '수정 일시';


--
-- Name: hq_price_applies; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.hq_price_applies (
    id uuid NOT NULL,
    upload_job_id uuid NOT NULL,
    version integer NOT NULL,
    memo text,
    applied_count integer NOT NULL,
    price_changes jsonb,
    applied_by uuid NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    is_current boolean NOT NULL
);


ALTER TABLE public.hq_price_applies OWNER TO dwt_user;

--
-- Name: COLUMN hq_price_applies.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.upload_job_id IS '업로드 작업 ID';


--
-- Name: COLUMN hq_price_applies.version; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.version IS '적용 버전';


--
-- Name: COLUMN hq_price_applies.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.memo IS '적용 메모';


--
-- Name: COLUMN hq_price_applies.applied_count; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_count IS '적용된 모델 수';


--
-- Name: COLUMN hq_price_applies.price_changes; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.price_changes IS '가격 변경 요약';


--
-- Name: COLUMN hq_price_applies.applied_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_by IS '적용자 ID';


--
-- Name: COLUMN hq_price_applies.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_at IS '적용 일시';


--
-- Name: COLUMN hq_price_applies.is_current; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.is_current IS '현재 적용 중 여부';


--
-- Name: hq_price_apply_locks; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.hq_price_apply_locks (
    id integer NOT NULL,
    is_locked boolean NOT NULL,
    locked_by uuid,
    locked_at timestamp without time zone,
    lock_reason character varying(200)
);


ALTER TABLE public.hq_price_apply_locks OWNER TO dwt_user;

--
-- Name: COLUMN hq_price_apply_locks.id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.id IS '락 ID (항상 1)';


--
-- Name: COLUMN hq_price_apply_locks.is_locked; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.is_locked IS '락 상태';


--
-- Name: COLUMN hq_price_apply_locks.locked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.locked_by IS '락 소유자 ID';


--
-- Name: COLUMN hq_price_apply_locks.locked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.locked_at IS '락 시작 일시';


--
-- Name: COLUMN hq_price_apply_locks.lock_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.lock_reason IS '락 사유';


--
-- Name: netting_records; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.netting_records (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    netting_date date NOT NULL,
    netting_amount numeric(18,2) NOT NULL,
    status public.netting_status NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_nr_amount_positive CHECK ((netting_amount > (0)::numeric))
);


ALTER TABLE public.netting_records OWNER TO dwt_user;

--
-- Name: COLUMN netting_records.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.counterparty_id IS '거래처 ID';


--
-- Name: COLUMN netting_records.netting_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.netting_date IS '상계일';


--
-- Name: COLUMN netting_records.netting_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.netting_amount IS '상계 금액';


--
-- Name: COLUMN netting_records.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.status IS 'DRAFT→CONFIRMED / CANCELLED';


--
-- Name: COLUMN netting_records.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.memo IS '메모';


--
-- Name: COLUMN netting_records.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.created_by IS '생성자 ID';


--
-- Name: COLUMN netting_records.confirmed_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.confirmed_by IS '확정자 ID';


--
-- Name: COLUMN netting_records.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.confirmed_at IS '확정 일시';


--
-- Name: netting_voucher_links; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.netting_voucher_links (
    id uuid NOT NULL,
    netting_record_id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    netted_amount numeric(18,2) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_nvl_amount_positive CHECK ((netted_amount > (0)::numeric))
);


ALTER TABLE public.netting_voucher_links OWNER TO dwt_user;

--
-- Name: COLUMN netting_voucher_links.netting_record_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.netting_record_id IS '상계 레코드 ID';


--
-- Name: COLUMN netting_voucher_links.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.voucher_id IS '전표 ID';


--
-- Name: COLUMN netting_voucher_links.netted_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.netted_amount IS '상계 적용 금액';


--
-- Name: partner_mappings; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partner_mappings (
    id uuid NOT NULL,
    partner_id uuid NOT NULL,
    model_id uuid NOT NULL,
    partner_expression character varying(200) NOT NULL,
    confidence double precision NOT NULL,
    is_manual boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partner_mappings OWNER TO dwt_user;

--
-- Name: COLUMN partner_mappings.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.partner_id IS '거래처 ID';


--
-- Name: COLUMN partner_mappings.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN partner_mappings.partner_expression; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.partner_expression IS '거래처 원본 표기 (예: 아이폰15프로맥스 256)';


--
-- Name: COLUMN partner_mappings.confidence; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.confidence IS '매핑 신뢰도 (0.0 ~ 1.0, 수동 매핑은 1.0)';


--
-- Name: COLUMN partner_mappings.is_manual; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.is_manual IS '수동 매핑 여부';


--
-- Name: COLUMN partner_mappings.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.created_at IS '생성 일시';


--
-- Name: COLUMN partner_mappings.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.updated_at IS '수정 일시';


--
-- Name: partner_prices; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partner_prices (
    id uuid NOT NULL,
    partner_id uuid NOT NULL,
    model_id uuid NOT NULL,
    grade_id uuid NOT NULL,
    price integer NOT NULL,
    uploaded_at timestamp without time zone NOT NULL,
    upload_job_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partner_prices OWNER TO dwt_user;

--
-- Name: COLUMN partner_prices.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.partner_id IS '거래처 ID';


--
-- Name: COLUMN partner_prices.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN partner_prices.grade_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.grade_id IS '등급 ID';


--
-- Name: COLUMN partner_prices.price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.price IS '거래처 단가 (원)';


--
-- Name: COLUMN partner_prices.uploaded_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.uploaded_at IS '업로드 일시';


--
-- Name: COLUMN partner_prices.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.upload_job_id IS '업로드 작업 ID';


--
-- Name: COLUMN partner_prices.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.created_at IS '생성 일시';


--
-- Name: COLUMN partner_prices.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.updated_at IS '수정 일시';


--
-- Name: partners; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(100),
    contact_info character varying(200),
    memo text,
    branch_id uuid,
    is_active boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by uuid,
    delete_reason character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partners OWNER TO dwt_user;

--
-- Name: COLUMN partners.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.name IS '거래처명 (예: 부천, 광명, 서울, 부산, 대전)';


--
-- Name: COLUMN partners.region; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.region IS '지역';


--
-- Name: COLUMN partners.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.contact_info IS '연락처 정보';


--
-- Name: COLUMN partners.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.memo IS '운영 메모';


--
-- Name: COLUMN partners.branch_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.branch_id IS '소속 지사 ID';


--
-- Name: COLUMN partners.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.is_active IS '활성 상태';


--
-- Name: COLUMN partners.deleted_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.deleted_at IS '삭제 일시 (소프트 삭제)';


--
-- Name: COLUMN partners.deleted_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.deleted_by IS '삭제한 사용자 ID';


--
-- Name: COLUMN partners.delete_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.delete_reason IS '삭제 사유';


--
-- Name: COLUMN partners.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.created_at IS '생성 일시';


--
-- Name: COLUMN partners.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.updated_at IS '수정 일시';


--
-- Name: payments; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.payments (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    payment_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO dwt_user;

--
-- Name: COLUMN payments.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.voucher_id IS '전표 ID';


--
-- Name: COLUMN payments.payment_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.payment_date IS '송금일';


--
-- Name: COLUMN payments.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.amount IS '송금액';


--
-- Name: COLUMN payments.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.memo IS '메모';


--
-- Name: COLUMN payments.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.created_by IS '등록자 ID';


--
-- Name: period_locks; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.period_locks (
    id uuid NOT NULL,
    year_month character varying(7) NOT NULL,
    status public.period_lock_status NOT NULL,
    locked_voucher_count integer NOT NULL,
    locked_at timestamp without time zone,
    locked_by uuid,
    unlocked_at timestamp without time zone,
    unlocked_by uuid,
    memo text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.period_locks OWNER TO dwt_user;

--
-- Name: COLUMN period_locks.year_month; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.year_month IS '마감 기간 (YYYY-MM)';


--
-- Name: COLUMN period_locks.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.status IS 'OPEN/LOCKED/ADJUSTING';


--
-- Name: COLUMN period_locks.locked_voucher_count; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_voucher_count IS '마감된 전표 수';


--
-- Name: COLUMN period_locks.locked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_at IS '마감 일시';


--
-- Name: COLUMN period_locks.locked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_by IS '마감 담당자 ID';


--
-- Name: COLUMN period_locks.unlocked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.unlocked_at IS '해제 일시';


--
-- Name: COLUMN period_locks.unlocked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.unlocked_by IS '해제 담당자 ID';


--
-- Name: COLUMN period_locks.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.memo IS '메모';


--
-- Name: receipts; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.receipts (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    receipt_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.receipts OWNER TO dwt_user;

--
-- Name: COLUMN receipts.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.voucher_id IS '전표 ID';


--
-- Name: COLUMN receipts.receipt_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.receipt_date IS '입금일';


--
-- Name: COLUMN receipts.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.amount IS '입금액';


--
-- Name: COLUMN receipts.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.memo IS '메모';


--
-- Name: COLUMN receipts.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.created_by IS '등록자 ID';


--
-- Name: ssot_models; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.ssot_models (
    id uuid NOT NULL,
    model_key character varying(100) NOT NULL,
    model_code character varying(100) NOT NULL,
    device_type public.device_type NOT NULL,
    manufacturer public.manufacturer NOT NULL,
    series character varying(100) NOT NULL,
    model_name character varying(200) NOT NULL,
    storage_gb integer NOT NULL,
    connectivity public.connectivity NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ssot_models OWNER TO dwt_user;

--
-- Name: COLUMN ssot_models.model_key; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_key IS '불변 모델 키 (동일 기종 공유, 스토리지 미포함)';


--
-- Name: COLUMN ssot_models.model_code; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_code IS '모델 코드 (model_key + storage 조합, 불변)';


--
-- Name: COLUMN ssot_models.device_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.device_type IS '기기 타입: smartphone, tablet, wearable';


--
-- Name: COLUMN ssot_models.manufacturer; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.manufacturer IS '제조사: apple, samsung, other';


--
-- Name: COLUMN ssot_models.series; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.series IS '시리즈 (예: iPhone 15, Galaxy S24)';


--
-- Name: COLUMN ssot_models.model_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_name IS '모델명 (예: iPhone 15 Pro Max)';


--
-- Name: COLUMN ssot_models.storage_gb; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.storage_gb IS '스토리지 용량 (GB 단위, 1TB=1024)';


--
-- Name: COLUMN ssot_models.connectivity; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.connectivity IS '연결성: lte(스마트폰), wifi/wifi_cellular(태블릿), standard(웨어러블)';


--
-- Name: COLUMN ssot_models.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.is_active IS '활성 상태 (비활성화 시 Viewer 화면에서 숨김)';


--
-- Name: COLUMN ssot_models.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.created_at IS '생성 일시';


--
-- Name: COLUMN ssot_models.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.updated_at IS '수정 일시';


--
-- Name: transaction_allocations; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.transaction_allocations (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    allocated_amount numeric(18,2) NOT NULL,
    allocation_order integer NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_ta_amount_positive CHECK ((allocated_amount > (0)::numeric))
);


ALTER TABLE public.transaction_allocations OWNER TO dwt_user;

--
-- Name: COLUMN transaction_allocations.transaction_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.transaction_id IS '입출금 이벤트 ID';


--
-- Name: COLUMN transaction_allocations.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.voucher_id IS '전표 ID';


--
-- Name: COLUMN transaction_allocations.allocated_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.allocated_amount IS '배분 금액';


--
-- Name: COLUMN transaction_allocations.allocation_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.allocation_order IS '배분 순서 (FIFO 순서 기록)';


--
-- Name: COLUMN transaction_allocations.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.memo IS '메모';


--
-- Name: COLUMN transaction_allocations.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.created_by IS '등록자 ID';


--
-- Name: upload_jobs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.upload_jobs (
    id uuid NOT NULL,
    job_type public.job_type NOT NULL,
    status public.job_status NOT NULL,
    progress integer NOT NULL,
    file_path character varying(500) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_hash character varying(64),
    partner_id uuid,
    created_by uuid NOT NULL,
    result_summary jsonb,
    error_message text,
    is_reviewed boolean NOT NULL,
    is_confirmed boolean NOT NULL,
    is_applied boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    confirmed_at timestamp without time zone,
    applied_at timestamp without time zone
);


ALTER TABLE public.upload_jobs OWNER TO dwt_user;

--
-- Name: COLUMN upload_jobs.job_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.job_type IS '작업 타입: hq_excel, partner_excel, partner_image';


--
-- Name: COLUMN upload_jobs.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.status IS '작업 상태: queued, running, succeeded, failed';


--
-- Name: COLUMN upload_jobs.progress; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.progress IS '진행률 (0-100, 단계 기반: 0/25/50/75/100)';


--
-- Name: COLUMN upload_jobs.file_path; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.file_path IS '업로드 파일 경로';


--
-- Name: COLUMN upload_jobs.original_filename; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.original_filename IS '원본 파일명';


--
-- Name: COLUMN upload_jobs.file_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.file_hash IS '파일 해시 (중복 방지용)';


--
-- Name: COLUMN upload_jobs.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.partner_id IS '거래처 ID (거래처 업로드 시)';


--
-- Name: COLUMN upload_jobs.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.created_by IS '생성자 ID';


--
-- Name: COLUMN upload_jobs.result_summary; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.result_summary IS '결과 요약 (매핑/미매핑 개수, 오류 등)';


--
-- Name: COLUMN upload_jobs.error_message; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.error_message IS '오류 메시지 (실패 시)';


--
-- Name: COLUMN upload_jobs.is_reviewed; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_reviewed IS '검수 완료 여부';


--
-- Name: COLUMN upload_jobs.is_confirmed; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_confirmed IS '확정 여부';


--
-- Name: COLUMN upload_jobs.is_applied; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_applied IS '적용 여부 (본사 단가표)';


--
-- Name: COLUMN upload_jobs.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.created_at IS '생성 일시';


--
-- Name: COLUMN upload_jobs.started_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.started_at IS '시작 일시';


--
-- Name: COLUMN upload_jobs.completed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.completed_at IS '완료 일시';


--
-- Name: COLUMN upload_jobs.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.confirmed_at IS '확정 일시';


--
-- Name: COLUMN upload_jobs.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.applied_at IS '적용 일시';


--
-- Name: upload_templates; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.upload_templates (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    voucher_type public.voucher_type NOT NULL,
    column_mapping jsonb NOT NULL,
    skip_columns jsonb,
    is_default boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.upload_templates OWNER TO dwt_user;

--
-- Name: COLUMN upload_templates.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.name IS '템플릿명';


--
-- Name: COLUMN upload_templates.voucher_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.voucher_type IS '전표 타입: SALES/PURCHASE';


--
-- Name: COLUMN upload_templates.column_mapping; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.column_mapping IS 'DB 필드 → 엑셀 헤더 매핑';


--
-- Name: COLUMN upload_templates.skip_columns; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.skip_columns IS '파싱 시 무시할 컬럼 목록';


--
-- Name: COLUMN upload_templates.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.is_default IS '기본 템플릿 여부';


--
-- Name: COLUMN upload_templates.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.created_by IS '생성자 ID';


--
-- Name: user_counterparty_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_counterparty_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_counterparty_favorites OWNER TO dwt_user;

--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    model_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_favorites OWNER TO dwt_user;

--
-- Name: COLUMN user_favorites.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.user_id IS '사용자 ID';


--
-- Name: COLUMN user_favorites.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN user_favorites.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.created_at IS '즐겨찾기 추가 일시';


--
-- Name: user_list_items; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_list_items (
    id uuid NOT NULL,
    list_id uuid NOT NULL,
    model_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_list_items OWNER TO dwt_user;

--
-- Name: COLUMN user_list_items.list_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.list_id IS '리스트 ID';


--
-- Name: COLUMN user_list_items.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN user_list_items.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.created_at IS '추가 일시';


--
-- Name: user_lists; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_lists (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    is_default boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_lists OWNER TO dwt_user;

--
-- Name: COLUMN user_lists.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.user_id IS '사용자 ID';


--
-- Name: COLUMN user_lists.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.name IS '리스트 이름 (예: 아이폰 라인업, 갤럭시 A급)';


--
-- Name: COLUMN user_lists.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.description IS '리스트 설명';


--
-- Name: COLUMN user_lists.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.is_default IS '기본 리스트 여부 (로그인 시 기본으로 열릴 리스트)';


--
-- Name: COLUMN user_lists.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.created_at IS '생성 일시';


--
-- Name: COLUMN user_lists.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.updated_at IS '수정 일시';


--
-- Name: user_partner_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_partner_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_partner_favorites OWNER TO dwt_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    role public.user_role NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_login_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO dwt_user;

--
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.email IS '이메일 (로그인 ID)';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.password_hash IS '해시된 비밀번호';


--
-- Name: COLUMN users.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.name IS '사용자 이름';


--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.role IS '역할: admin(관리자), viewer(조회자)';


--
-- Name: COLUMN users.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.is_active IS '활성 상태 (비활성화 시 로그인 불가)';


--
-- Name: COLUMN users.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.created_at IS '생성 일시';


--
-- Name: COLUMN users.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.updated_at IS '수정 일시';


--
-- Name: COLUMN users.last_login_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.last_login_at IS '마지막 로그인 일시';


--
-- Name: voucher_change_requests; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.voucher_change_requests (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    upload_job_id uuid,
    before_data jsonb,
    after_data jsonb,
    diff_summary jsonb,
    status public.change_request_status NOT NULL,
    reviewed_by uuid,
    review_memo text,
    created_at timestamp without time zone NOT NULL,
    reviewed_at timestamp without time zone
);


ALTER TABLE public.voucher_change_requests OWNER TO dwt_user;

--
-- Name: COLUMN voucher_change_requests.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.voucher_id IS '변경 대상 전표 ID';


--
-- Name: COLUMN voucher_change_requests.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.upload_job_id IS '재업로드 Job ID';


--
-- Name: COLUMN voucher_change_requests.before_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.before_data IS '변경 전 데이터 스냅샷';


--
-- Name: COLUMN voucher_change_requests.after_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.after_data IS '변경 후 데이터 스냅샷';


--
-- Name: COLUMN voucher_change_requests.diff_summary; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.diff_summary IS '변경된 필드 요약 [{field, old, new}, ...]';


--
-- Name: COLUMN voucher_change_requests.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.status IS '승인 상태: pending/approved/rejected';


--
-- Name: COLUMN voucher_change_requests.reviewed_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.reviewed_by IS '검토자 ID';


--
-- Name: COLUMN voucher_change_requests.review_memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.review_memo IS '검토 메모';


--
-- Name: COLUMN voucher_change_requests.reviewed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.reviewed_at IS '검토 일시';


--
-- Name: vouchers; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.vouchers (
    id uuid NOT NULL,
    trade_date date NOT NULL,
    counterparty_id uuid NOT NULL,
    voucher_number character varying(50) NOT NULL,
    voucher_type public.voucher_type NOT NULL,
    quantity integer NOT NULL,
    total_amount numeric(18,2) NOT NULL,
    purchase_cost numeric(18,2),
    actual_purchase_price numeric(18,2),
    deduction_amount numeric(18,2),
    avg_unit_price numeric(18,2),
    upm_settlement_status character varying(50),
    payment_info character varying(500),
    purchase_deduction numeric(18,2),
    as_cost numeric(18,2),
    sale_amount numeric(18,2),
    sale_deduction numeric(18,2),
    actual_sale_price numeric(18,2),
    profit numeric(18,2),
    profit_rate numeric(8,2),
    avg_margin numeric(18,2),
    is_adjustment boolean NOT NULL,
    adjustment_type public.adjustment_type,
    original_voucher_id uuid,
    adjustment_reason text,
    settlement_status public.settlement_status NOT NULL,
    payment_status public.payment_status NOT NULL,
    memo text,
    upload_job_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.vouchers OWNER TO dwt_user;

--
-- Name: COLUMN vouchers.trade_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.trade_date IS '매입일/판매일';


--
-- Name: COLUMN vouchers.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.counterparty_id IS '매입처/판매처 → Counterparty';


--
-- Name: COLUMN vouchers.voucher_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.voucher_number IS 'UPM 전표 번호';


--
-- Name: COLUMN vouchers.voucher_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.voucher_type IS 'SALES(판매)/PURCHASE(매입)';


--
-- Name: COLUMN vouchers.quantity; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.quantity IS '수량';


--
-- Name: COLUMN vouchers.total_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.total_amount IS '정산 기준 금액 (매입:실매입가, 판매:실판매가)';


--
-- Name: COLUMN vouchers.purchase_cost; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.purchase_cost IS '매입원가';


--
-- Name: COLUMN vouchers.actual_purchase_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.actual_purchase_price IS '실매입가';


--
-- Name: COLUMN vouchers.deduction_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.deduction_amount IS '차감금액 (매입 전용)';


--
-- Name: COLUMN vouchers.avg_unit_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.avg_unit_price IS '평균가 (매입 전용)';


--
-- Name: COLUMN vouchers.upm_settlement_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.upm_settlement_status IS 'UPM 원본 정산현황 (검수대기/정산완료 등)';


--
-- Name: COLUMN vouchers.payment_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.payment_info IS '송금정보 (매입 전용)';


--
-- Name: COLUMN vouchers.purchase_deduction; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.purchase_deduction IS '매입차감 (판매 전용)';


--
-- Name: COLUMN vouchers.as_cost; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.as_cost IS 'A/S비용 (판매 전용)';


--
-- Name: COLUMN vouchers.sale_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.sale_amount IS '판매금액 (판매 전용)';


--
-- Name: COLUMN vouchers.sale_deduction; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.sale_deduction IS '판매차감 (판매 전용)';


--
-- Name: COLUMN vouchers.actual_sale_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.actual_sale_price IS '실판매가 (판매 전용)';


--
-- Name: COLUMN vouchers.profit; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.profit IS '손익 (판매 전용)';


--
-- Name: COLUMN vouchers.profit_rate; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.profit_rate IS '수익율 % (판매 전용)';


--
-- Name: COLUMN vouchers.avg_margin; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.avg_margin IS '평균마진 (판매 전용)';


--
-- Name: COLUMN vouchers.is_adjustment; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.is_adjustment IS '조정 전표 여부';


--
-- Name: COLUMN vouchers.adjustment_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.adjustment_type IS '조정 유형: CORRECTION/RETURN/WRITE_OFF/DISCOUNT';


--
-- Name: COLUMN vouchers.original_voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.original_voucher_id IS '원본 전표 ID (조정 전표일 경우)';


--
-- Name: COLUMN vouchers.adjustment_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.adjustment_reason IS '조정 사유';


--
-- Name: COLUMN vouchers.settlement_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.settlement_status IS '시스템 정산 상태';


--
-- Name: COLUMN vouchers.payment_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.payment_status IS '시스템 지급 상태';


--
-- Name: COLUMN vouchers.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.memo IS '비고';


--
-- Name: COLUMN vouchers.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.upload_job_id IS '업로드 Job ID';


--
-- Name: COLUMN vouchers.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.created_by IS '생성자 ID';


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.audit_logs (id, trace_id, user_id, action, target_type, target_id, before_data, after_data, description, ip_address, user_agent, created_at) FROM stdin;
05cb8816-60a2-4f15-b5a2-54c4564f0c1e	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 04:53:15.630484
9e8b382e-51bb-4b35-872b-117bb85a4206	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:29:45.37493
b21e2f7e-68dd-4cf9-a34f-e2014682fd3a	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:21.751357
788089f0-c874-4c34-a49e-0dbc1c2f63aa	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:28.183065
261ec018-5f7a-478c-800b-47408b0ca0ba	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:35.694154
e0b79914-141b-4306-8c05-e7debe6be677	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_CREATE	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	{"name": "skp10216", "role": "admin", "email": "skp10216@gmail.com"}	\N	\N	\N	2026-03-03 05:30:36.013231
2ce6ab25-91b8-4872-81c6-c05a0ace0ff8	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:31:45.550483
7d274d93-8d97-4ca0-82e7-84bfbe2491fe	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:31:52.695246
eaf6316a-3d03-417f-be46-9aa885918379	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:24.971431
518faef7-7fa1-4fb5-8e84-70cbbf9f98f3	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:30.33166
4b273608-758d-4655-9912-4c718dc4b392	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:31.504081
dad1fcfe-cb32-4a26-b4e9-0f684df3182f	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:32.288194
3130032a-7ac0-48f7-83bb-59c3e3ab31d5	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:33.662466
412e2f3d-497f-4476-bf1f-cc8b355e787b	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:49:37.960489
bec4d945-0e98-4fa4-9f00-9f4b4de4df54	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:49:50.293901
599f20c9-ffd6-4d20-8220-35c454b38dd0	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 06:57:51.848901
b84a2499-6939-4dab-af33-6710dd2e8fa1	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 07:25:22.786493
6e5edcfc-b8b5-495d-b15d-76d5a316f62d	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 07:27:23.218068
2dbcd040-b6c8-4586-8880-95a5dbc6d520	\N	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	USER_LOGIN	user	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 07:46:59.988838
d3e507eb-5490-40d9-ae73-6a3b925b04b6	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Linux; Android 15; SM-S901N Build/AP3A.240905.015.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/145.0.7632.120 Mobile Safari/537.36 KAKAOTALK/26.1.3 (INAPP)	2026-03-03 07:29:36.539045
\.


--
-- Data for Name: bank_import_jobs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.bank_import_jobs (id, file_path, original_filename, file_hash, bank_name, account_number, import_date_from, import_date_to, status, total_lines, matched_lines, confirmed_lines, error_message, created_by, created_at, completed_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: bank_import_lines; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.bank_import_lines (id, import_job_id, line_number, transaction_date, description, amount, balance_after, counterparty_name_raw, counterparty_id, status, match_confidence, duplicate_key, bank_reference, transaction_id, raw_data, created_at) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.branches (id, name, region, contact_info, memo, is_active, deleted_at, deleted_by, delete_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compare_list_models; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.compare_list_models (id, model_id, sort_order, created_at, added_by) FROM stdin;
\.


--
-- Data for Name: counterparties; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparties (id, name, code, counterparty_type, branch_id, contact_info, memo, is_active, created_at, updated_at) FROM stdin;
6eb1110b-8ec8-487c-9a82-e2442663d029	김태연(베트남)	\N	BOTH	\N	\N	\N	t	2026-03-03 07:40:32.897629	2026-03-03 07:40:32.897633
\.


--
-- Data for Name: counterparty_aliases; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparty_aliases (id, counterparty_id, alias_name, created_by, created_at) FROM stdin;
36451bb5-112f-4c14-b747-b02a960f2007	6eb1110b-8ec8-487c-9a82-e2442663d029	김태연(베트남)	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:40:32.901558
\.


--
-- Data for Name: counterparty_transactions; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparty_transactions (id, counterparty_id, transaction_type, transaction_date, amount, allocated_amount, memo, source, bank_reference, bank_import_line_id, netting_record_id, status, created_by, created_at, updated_at) FROM stdin;
9e946d1f-d7fa-4ecd-b0b1-0b39d8533359	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-06	20440000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414198	2026-03-03 07:44:55.532009
1ebdabce-0262-4282-9a9a-50c99a619410	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	3450000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414195	2026-03-03 07:44:55.535167
3eb8ed9e-e79c-4e27-9361-56262f2d3c8a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	15000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414192	2026-03-03 07:44:55.537914
80093305-77e3-4d92-8fdc-ef81e29e19a3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	5660000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414189	2026-03-03 07:44:55.540613
a1fae3c1-fbf9-4bfb-b8fa-5bf0c3097bee	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	5150000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414186	2026-03-03 07:44:55.543272
eea2f471-4077-47d2-954d-700bf9b5ae49	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	7655000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414183	2026-03-03 07:44:55.54595
2f0eb026-4893-44bf-8c95-f9a34b2614dd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-09	2405000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414507	2026-03-03 07:44:52.893063
bc7206a9-91df-49be-a895-07a03eb5a0fd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-09	9005000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414504	2026-03-03 07:44:52.897823
543065fe-b88e-466e-9990-53128d5e89de	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-09	16440000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414501	2026-03-03 07:44:52.901198
9c86a968-8454-4920-8126-78a10cc668ca	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-08	310000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414498	2026-03-03 07:44:52.9044
e1a16fbf-b7ab-4b7c-8f26-ffd914f63a39	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-08	12780000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414495	2026-03-03 07:44:52.907682
73af3a2d-d254-446e-ba8d-8b75f04d8540	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	5000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414492	2026-03-03 07:44:52.911059
2e76d140-5e4d-4b10-831b-f1e23682b147	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	6690000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414488	2026-03-03 07:44:52.914193
d8f29d00-522b-46f5-9d97-b130cd1caf7f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	1985000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414485	2026-03-03 07:44:52.918102
a9aeed25-9525-4ba6-99d6-549395309224	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	14090000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414482	2026-03-03 07:44:52.921461
53845d49-f337-4dea-bf4d-9be745b1ee89	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	18030000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414479	2026-03-03 07:44:52.924577
3338890f-9c16-4c7f-9373-a26be8127ba9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	4190000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414476	2026-03-03 07:44:52.927557
99dd07df-19f8-4a86-bb97-0dabd08ab99e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414473	2026-03-03 07:44:52.930513
857a9441-e892-47b8-b070-6051076475c4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-05	2170000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41447	2026-03-03 07:44:52.933415
3eb68f3d-52ba-44cf-95db-c9df0944d52e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	1155000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414467	2026-03-03 07:44:52.936216
c406667e-e67d-4a72-96aa-3db5ed1caeed	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-19	21008000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414821	2026-03-03 07:44:49.427324
bc0dd140-d0b7-451f-9e5b-03742bbb2a58	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-11	1500000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414817	2026-03-03 07:44:49.440792
a7b062fa-1ebb-46ee-8a48-546f5e7b1584	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	1060000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414814	2026-03-03 07:44:49.444753
2b5cbac1-fe93-4e79-8a12-0583a6e19de0	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	13250000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414811	2026-03-03 07:44:49.447994
97bd2a35-c6fa-457c-be9f-c47634362001	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	1500000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414808	2026-03-03 07:44:49.451056
3eb6eeee-0bd9-48ab-8527-c66aaa742e98	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-11	39050000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414805	2026-03-03 07:44:49.454155
98d3b9a8-251c-4052-b0f0-5c27da364893	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-10	40000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414802	2026-03-03 07:44:49.457042
2a41db1a-85a0-4a4a-bc69-3bc5d53312ed	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	14010000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414799	2026-03-03 07:44:49.459649
ada72044-f874-416e-af3e-59b74285c16f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	23245000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414796	2026-03-03 07:44:49.462261
371481d2-d5b8-476e-bda9-bb0a1a5e7a8b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	14660000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414792	2026-03-03 07:44:49.465251
8086c5e8-2f1b-48eb-af24-c75998dc1cd3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-10	4230000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414789	2026-03-03 07:44:49.467851
b6df9bdf-ede5-48d4-b632-a868c3bfc98a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-09	5010000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414786	2026-03-03 07:44:49.470563
40309681-1e95-4421-99ff-fdc91984d5c7	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	9275000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414783	2026-03-03 07:44:49.473233
7e320f59-d172-4f78-99f1-3b56078cbf2a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	8730000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41478	2026-03-03 07:44:49.475821
4864e729-a57d-48bf-b17b-7197ddd5fa1a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	1160000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414777	2026-03-03 07:44:49.478364
583b40c1-3d2b-492f-9848-a15313fa0631	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-09	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414774	2026-03-03 07:44:49.480942
0fc2b0c2-7bf3-4deb-b8dd-041cd8ede734	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-06	2575000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414771	2026-03-03 07:44:49.483615
0b1f888c-6ef1-4100-bd11-bf902693bc26	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	12085000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414767	2026-03-03 07:44:49.486227
77be9797-9148-495a-b81f-4fdc370ce15b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	29070000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414764	2026-03-03 07:44:49.489178
b754cd37-0652-4643-82ca-08022db459a3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	9865000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414761	2026-03-03 07:44:49.491794
f1e48e21-4518-44ad-90c4-39550d79a2f1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-06	42000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414758	2026-03-03 07:44:49.49452
18751b82-e01d-450b-8c4b-1041c4f08c4c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	8290000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414755	2026-03-03 07:44:49.497135
7b086a5e-9fcc-490e-9d4b-07a5938f1177	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	14985000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414752	2026-03-03 07:44:49.499708
a15fd851-fce9-4926-8ac8-59e7286859bb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	3555000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414749	2026-03-03 07:44:49.502829
dac232a4-00a7-4ec2-bf15-5bcc1d87a7bc	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	645000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414746	2026-03-03 07:44:49.505998
a3f410ec-95cf-435e-925b-541f407842e2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-04	4140000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414743	2026-03-03 07:44:49.508749
10deaee0-af53-4e50-abdd-4ed40fe7de19	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-04	18810000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414739	2026-03-03 07:44:49.511294
ee220d9b-b0ca-439f-8f3c-472b72eec21c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-04	14575000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414736	2026-03-03 07:44:49.513963
65f64ac0-5229-443c-a3f5-96f58f3719cc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-04	24460000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414733	2026-03-03 07:44:49.516551
a438e7f5-ba20-40a0-bbd0-eb38c01a42d8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-03	950000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41473	2026-03-03 07:44:49.519099
bbb090c8-0746-4a19-9f0a-4ea1bb6529ef	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-03	15740000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414727	2026-03-03 07:44:49.521752
2ae07bc8-c071-45ca-89b0-315f397e092f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-03	33000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414724	2026-03-03 07:44:49.524572
76fabc38-e3a3-4c8e-a81e-a6d97e5be914	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-02	205000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414721	2026-03-03 07:44:49.527283
e2a0cbc0-e846-437f-8c48-f748d290c676	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-02	2190000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414718	2026-03-03 07:44:49.529979
c81efe09-6fd8-47b0-89b6-3fb5b260da7c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-02	12795000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414715	2026-03-03 07:44:49.533817
8b7fc284-5d2d-4f8b-a44c-5a0d38c3b22b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-02	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414711	2026-03-03 07:44:49.536739
30b1d2a7-680b-4c0b-bf30-8378506f3e1e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-30	2270000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414708	2026-03-03 07:44:49.539422
2f1e30c4-efff-4f0d-90a9-c03ecdf67118	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	4040000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414705	2026-03-03 07:44:49.542868
51b093b6-fa9e-48ed-b782-c9b43fde3cb9	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	3885000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414702	2026-03-03 07:44:49.545725
cbba7745-8fdb-47c6-90eb-10c68f937f1c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	25430000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414698	2026-03-03 07:44:49.548549
d44f39c5-f3d4-40b6-96ab-24b0d2c627d3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	1230000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414695	2026-03-03 07:44:49.551324
272b8a4e-88e9-4955-a770-9cf8689c31bb	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-30	16500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414692	2026-03-03 07:44:49.554623
1b0a15e0-fb90-4378-a957-2c21a9b5a56e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	10470000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414689	2026-03-03 07:44:49.557572
00fe356c-1c55-4249-8035-85b17b0d4c78	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	17945000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414686	2026-03-03 07:44:49.560243
aadf283d-c3b6-4e52-afce-ead44093141b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	635000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414683	2026-03-03 07:44:49.562853
e2853045-bbbc-4c12-9885-fdfd53ac89c1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	8000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41468	2026-03-03 07:44:49.565753
b62b7c47-2d07-4fe7-b908-9ed25a0977b1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	4350000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414676	2026-03-03 07:44:49.568383
c644a701-f243-47df-8a36-6fd6607aa203	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-28	485000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414673	2026-03-03 07:44:49.57097
3255e802-b01d-42ed-8740-b56f9db39108	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	30000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41467	2026-03-03 07:44:49.573616
82e5281f-0c7f-40eb-8bb6-9a215581621f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-27	2005000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414667	2026-03-03 07:44:49.576952
dfccc409-f15b-41c4-9a98-ce9b06f0437f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	7450000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414664	2026-03-03 07:44:49.579856
4f004a72-215d-4c81-838a-d8173535d325	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	15310000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414661	2026-03-03 07:44:49.58248
804807e2-6f70-4260-b6fa-5b65426effaa	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	25495000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414657	2026-03-03 07:44:49.58519
19d4c0e0-5723-4e9e-9165-45b8298e76ba	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	910000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414654	2026-03-03 07:44:49.587781
a5bcb51d-5318-46ee-8885-25028c9f1c35	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-27	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414651	2026-03-03 07:44:49.590674
478c7027-533e-4b3d-991f-8bcbdbcd61da	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-23	4375000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414648	2026-03-03 07:44:49.593364
2eadb8ac-a712-40b0-a5df-8caaeccd2966	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	7310000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414645	2026-03-03 07:44:49.59592
26b6c077-0b72-4a68-bd12-651dc3759441	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	9435000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414641	2026-03-03 07:44:49.598518
375dbbeb-bafb-4410-a8e8-2fbde5b1bf66	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	28240000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414638	2026-03-03 07:44:49.601101
3262d380-17cf-4b49-b894-073288c1cee2	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	925000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414635	2026-03-03 07:44:49.603853
4eb377e8-719a-407d-bd99-277195002604	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-23	75000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414632	2026-03-03 07:44:49.606536
0b4cf43c-2c0b-45bb-bc2c-c56acb0885ad	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	4479000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414629	2026-03-03 07:44:49.609184
4192b9a3-7afa-4e4c-be17-410e366543b5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	22400000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414626	2026-03-03 07:44:49.612668
5d9bdf40-5638-455e-add9-f8c980897983	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	13715000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414623	2026-03-03 07:44:49.615487
7e877be3-82cc-4e2d-b485-83758307fa69	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-22	35000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414619	2026-03-03 07:44:49.618178
2af6d3b5-072f-4743-badd-e79a9e4c41b3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-21	375000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414616	2026-03-03 07:44:49.620904
189a5397-2322-4bf7-be53-e72ed18c071e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	12830000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414613	2026-03-03 07:44:49.623623
edcfe955-ab65-44c5-b324-1fdf55c0dbce	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	570000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41461	2026-03-03 07:44:49.626533
3019601b-e066-4917-8a56-fd8ed6a9d8ef	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	7730000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414607	2026-03-03 07:44:49.629344
32a89a0a-67bf-415f-abbc-c21e36f4a532	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	17435000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414604	2026-03-03 07:44:49.632052
294b778b-4745-4e5a-adf3-5439571b6d4c	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-21	40000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414601	2026-03-03 07:44:49.634901
9a610d72-25a7-482d-afa5-c44afadba0a5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	12045000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414597	2026-03-03 07:44:49.637653
e27de8f8-3641-49ca-9606-b0d131df906a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	32060000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414594	2026-03-03 07:44:49.640404
2c485c0e-b58f-4595-9c5a-1fd7d09e8adb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	121000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414591	2026-03-03 07:44:49.643085
15264239-7109-4da8-8b1c-6e407c2f70d8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	4730000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414588	2026-03-03 07:44:49.645917
96697a3a-b4ca-427e-bc30-7a3b44c4d15e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	23520000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414585	2026-03-03 07:44:49.648972
0b0273f2-9f1a-4556-9c77-07dc5ed7d736	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	33000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414582	2026-03-03 07:44:49.651729
602d68c5-6a98-48cc-822c-195ec448eb10	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	3445000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414579	2026-03-03 07:44:49.654623
91f339fc-513a-46ae-87d5-cf21d89c2b9a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	4050000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414576	2026-03-03 07:44:49.65744
df118e93-ceaf-4bf9-b108-ef8363b41278	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	18700000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414573	2026-03-03 07:44:49.660233
0851e8d9-aab6-4c26-9de3-e7b21b71183d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-16	3445000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41457	2026-03-03 07:44:49.663326
9e09c268-51e3-48ef-b6d5-adb02df3ac4d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-16	18515000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414566	2026-03-03 07:44:49.666328
abe2e609-bd4e-4cbf-bbde-ceabd7c23758	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-16	32000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414563	2026-03-03 07:44:49.669047
c75950d6-84c0-40d0-a203-78acc136387b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-15	2110000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41456	2026-03-03 07:44:49.671819
b0f1b0ff-ecfa-46f1-807f-9c7d152f0149	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-15	23385000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414557	2026-03-03 07:44:49.674714
eb938bb0-fd86-45e6-a7db-b60be563c837	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-15	5000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414554	2026-03-03 07:44:49.67757
91d8b879-3424-4123-8210-07fa0be3e097	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-15	375000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414551	2026-03-03 07:44:49.680416
3fd752da-74ae-4cfe-a78e-ac52739a0bc9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-14	4770000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414548	2026-03-03 07:44:49.683861
f3f61b64-0602-4fe5-bd8a-ce06b6d0d019	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	7610000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414545	2026-03-03 07:44:49.686596
21c19e8e-2506-41a0-b725-72eac8e73b00	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	750000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414542	2026-03-03 07:44:49.689359
556745bc-effb-4af1-8e2e-78f7d8136b90	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	1720000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414539	2026-03-03 07:44:49.692229
b3e696cd-1b11-4e0d-b9b2-861c3ce7a69d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-14	17550000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414536	2026-03-03 07:44:49.694993
e109b9e2-8eb2-4e54-bc2c-e585553cf69d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-13	1855000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414532	2026-03-03 07:44:49.697792
e4668b48-a12b-4a15-a129-1111b519be16	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	4920000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414529	2026-03-03 07:44:49.700505
0bd4f8d9-8102-4ca0-80f0-435e57b822f8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	6405000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414526	2026-03-03 07:44:49.703234
b2018489-d6ab-4e74-bbcd-a0558e198164	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	10945000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414523	2026-03-03 07:44:49.706031
adf08477-38c8-4374-98bf-48ed41a372b5	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-12	880000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41452	2026-03-03 07:44:49.708936
1b311e49-8592-4bf4-b79b-fa08c36305ff	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-12	4135000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414517	2026-03-03 07:44:49.7116
5a3d53c6-d827-43be-a923-aa7980968ff1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-12	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414514	2026-03-03 07:44:49.714337
7ccaa215-2d97-46fb-815e-e179b65754e4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-09	2100000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414511	2026-03-03 07:44:49.717172
ba8e7b80-2718-416d-8b64-8cb77c3e64b3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	10860000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414464	2026-03-03 07:44:52.938953
4ca7c60a-897d-4777-828d-834345b848bd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	32420000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414461	2026-03-03 07:44:52.941784
a5285639-f4aa-4d8f-be6e-36b91ae21b6f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-30	50000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414458	2026-03-03 07:44:52.944665
91305689-49f2-476a-939d-d7865e5d0798	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-29	105000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414455	2026-03-03 07:44:52.947325
e20fb899-0962-478b-8023-2f6dfc1c7cc4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-29	21470000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414452	2026-03-03 07:44:52.94998
a34ff496-dbf2-482c-9d00-49d18c50004d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-26	280000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414448	2026-03-03 07:44:52.95262
cf30b852-6026-43d7-a2a5-090b08ddbfc5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-26	2760000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414445	2026-03-03 07:44:52.955206
f7bfd3e9-20f8-4f05-b1da-0a899b6d02f2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-26	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414442	2026-03-03 07:44:52.957864
73461c78-07c0-4009-96a7-d27ce3aeb188	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-24	550000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414439	2026-03-03 07:44:52.960499
48f3be13-5989-4843-9f35-77790674eacc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-23	1080000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414436	2026-03-03 07:44:52.963058
e4328190-d15d-465d-9b3d-e6e533e90884	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-23	4965000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414433	2026-03-03 07:44:52.965762
3ea16246-2dd0-4575-8077-4a4844273df8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-22	5905000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41443	2026-03-03 07:44:52.968396
62bcabc0-5d23-4f49-9f83-c2151757f297	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-22	540000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414427	2026-03-03 07:44:52.971103
c434f9cb-9382-40f4-9c46-d9f24a2c6702	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-22	10000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414424	2026-03-03 07:44:52.973864
3c351e4d-b662-4c6b-8ea7-9288b6234a34	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-19	315000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414421	2026-03-03 07:44:52.976701
74ff8083-824e-42ed-9dab-e30f160d1daf	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-19	4360000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414417	2026-03-03 07:44:52.979356
1ef97430-ab74-4463-b419-b390a5e5b65d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-18	2495000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414414	2026-03-03 07:44:52.982119
3f9dbbff-8675-444d-be14-bb53db9ee6ad	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-17	1640000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414411	2026-03-03 07:44:52.984934
0d901ded-bdd4-4944-88dc-f0d7838dad98	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	1975000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414408	2026-03-03 07:44:52.98772
2531d993-955c-4569-8578-e9fa558dadeb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	14460000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414405	2026-03-03 07:44:52.990388
1bad8b90-47f2-479f-acb0-f6cbb42956ce	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	1205000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414402	2026-03-03 07:44:52.993894
e056e63a-e69a-47d7-911c-442649c0e701	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-17	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414399	2026-03-03 07:44:52.996763
feceb418-72b1-4c77-9868-87535ab1d015	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-15	4460000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414396	2026-03-03 07:44:52.999483
3bccc754-23b0-40dc-bb1c-1f7f6adaa02f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-15	11420000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414393	2026-03-03 07:44:53.002287
86265afe-e2bc-481d-bb14-7713dfbb5264	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-15	2745000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41439	2026-03-03 07:44:53.00502
8181c6a2-1cc2-4c72-89e1-e7a463abd45f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-15	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414387	2026-03-03 07:44:53.007691
ed42bd0e-e33e-4ee6-862b-a1215bea0313	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-12	2555000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414384	2026-03-03 07:44:53.010503
e9603bbc-d856-4cb0-8219-4810741c7297	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-12	41240000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41438	2026-03-03 07:44:53.013549
b85b22e1-f496-4c69-801c-8224d8370441	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-12	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414377	2026-03-03 07:44:53.016325
5e5fcdfe-c971-458b-8231-c776c2759283	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-11	11340000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414374	2026-03-03 07:44:53.019006
5fa16c99-3ff7-4744-8f9f-27d04b7e3285	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-11	31000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414371	2026-03-03 07:44:53.021746
1ef789e7-d756-4535-908b-df25caa8ccd2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-08	1140000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414368	2026-03-03 07:44:53.02452
6d2363b7-27a2-4cc0-8d74-0c402f8785dc	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-08	425000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414365	2026-03-03 07:44:53.027158
4c8a1595-853d-4c0a-964b-a4de94e6b2bf	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-04	17705000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414362	2026-03-03 07:44:53.029971
4bdf699c-7eab-4bbc-ba5e-ac19169800ed	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-01	660000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414359	2026-03-03 07:44:53.032738
be292b95-cf35-49dd-81a2-adfcf1d85017	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-01	11130000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414356	2026-03-03 07:44:53.035574
109bc7d8-edaa-4948-b57a-4ebadaeedaf1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	3775000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414353	2026-03-03 07:44:53.03835
5fe9117d-46b8-4513-b17e-bb6a3158a0f8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-28	1305000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41435	2026-03-03 07:44:53.041153
ac0cb523-a402-4ff7-95aa-ccca627765d3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	16000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414347	2026-03-03 07:44:53.044013
b8739bbd-0f11-4e58-8566-a084130c4404	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	24000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414344	2026-03-03 07:44:53.046785
6d91b589-6206-4bbe-8a76-8fb3acd7f358	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	12000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41434	2026-03-03 07:44:53.049641
fd256662-bc2b-4728-b857-4096982c394f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-27	2960000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414337	2026-03-03 07:44:53.052556
2835d476-c297-4aae-ab1c-b6fbd56ace04	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	7900000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414334	2026-03-03 07:44:53.055347
abe24b8f-09ec-457f-a68e-903daaa6a8f0	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	17310000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414331	2026-03-03 07:44:53.058071
d6e51681-a526-41bd-b544-558d70b1dc6a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	9990000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414328	2026-03-03 07:44:53.060845
a8f3e41e-90cf-4dd4-958b-b227aa374b08	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-26	2750000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414325	2026-03-03 07:44:53.064478
e9d052a0-221a-4904-8a41-f1aeaf409d68	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-26	24185000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414322	2026-03-03 07:44:53.067275
47946396-dc2f-4382-ac07-bc00b0acf7c2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-26	16840000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414319	2026-03-03 07:44:53.070103
d571ac2a-d6ce-470d-8d86-e63751677172	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-24	4180000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414316	2026-03-03 07:44:53.072864
8b171a40-1a17-4a06-b1f0-ebf5f7160f44	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-24	7025000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414313	2026-03-03 07:44:53.075617
6ed1135b-30a7-441b-b90d-76dd148ed7fa	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-24	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41431	2026-03-03 07:44:53.078455
54ab9b1f-8d4d-4a32-8505-053780676c2b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-21	2850000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414306	2026-03-03 07:44:53.081361
f4aa653e-145d-4e00-83e6-b268fca48ef6	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-20	2520000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414303	2026-03-03 07:44:53.085002
9f3b5656-77e4-4079-a29c-6c1ffb036530	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	6885000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.4143	2026-03-03 07:44:53.088231
de73bfab-1f29-450e-b641-a93aa2e2946c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	10000000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414297	2026-03-03 07:44:53.090973
46970588-ef7f-4555-bf89-a5b41d233034	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	1040000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414294	2026-03-03 07:44:53.093851
e891dd40-5801-4953-8c67-f08e4ad257d9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-20	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414291	2026-03-03 07:44:53.096556
39b7c274-9070-4d8a-950e-ff4b7e9e5460	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-19	14535000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414288	2026-03-03 07:44:53.099266
5a889bbd-b2a4-43d1-8436-b2a8f5ad45bd	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-18	260000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414285	2026-03-03 07:44:53.102024
736a6e02-3e57-479a-a47b-41e692b1cf05	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-18	7015000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414282	2026-03-03 07:44:53.104897
87cb846a-9a42-4c2e-87ca-56aba390e4f7	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-18	7880000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414279	2026-03-03 07:44:53.107708
4bb045ab-8827-49e1-920e-2c7d17dcf3b2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	4840000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414276	2026-03-03 07:44:53.110533
6ba7d575-f2ed-4217-8f0d-d88f6e6d0722	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-17	8390000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414273	2026-03-03 07:44:53.114458
8c89d68c-14b9-4225-b9d8-f5c4b23744fc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	2610000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41427	2026-03-03 07:44:53.117236
5d3c1609-a258-4f6c-be30-13542f95baec	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	26900000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414267	2026-03-03 07:44:53.119874
5f525df4-5a3b-4abb-a035-cec38f3c0df7	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-14	2275000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414263	2026-03-03 07:44:53.1227
a4714bc0-1400-4549-bd2b-6d9748e4da6e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-14	32650000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41426	2026-03-03 07:44:53.125442
bfb2af2d-2988-4a35-b8d5-d81d7895e153	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-14	6485000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414257	2026-03-03 07:44:53.128071
bc41b0c6-50f0-4a0d-8d03-5f3efba7da1e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-14	22910000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414254	2026-03-03 07:44:53.130833
3cf368e1-ba7d-4178-a76f-4af29ed79db8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-13	1600000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414251	2026-03-03 07:44:53.13364
b7a5bcf7-3cf4-4ae7-9419-a20916227324	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-13	13505000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414248	2026-03-03 07:44:53.136371
89d92c59-3227-4da8-a329-49fa2b2376ae	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-13	18180000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414245	2026-03-03 07:44:53.139014
0c3e7211-4ca0-4411-8b11-95098cec2b48	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-12	28925000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414242	2026-03-03 07:44:53.141751
f209a362-fe93-4114-83fd-b420a0ac72c1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-12	5835000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414239	2026-03-03 07:44:53.14456
a112c0b4-73d1-44f0-b093-8ee8e6b6ea6a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-11	4000000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414236	2026-03-03 07:44:53.148093
fdcbe5f6-8c22-4c29-99af-4c22cbd6850c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-11	6470000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414232	2026-03-03 07:44:53.150796
b9d4f2ea-1618-4c8c-b8bc-64a3dd7e81b7	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	21085000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414229	2026-03-03 07:44:53.153469
8f10f186-7422-41bb-a98a-e2c8b957a0db	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	19050000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414226	2026-03-03 07:44:53.156036
7a8c8d46-1fec-485f-b716-d9ee13a384c9	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-10	22110000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414223	2026-03-03 07:44:53.158715
d3488eb7-7ba7-4788-ba89-67684d9977a3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	1020000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41422	2026-03-03 07:44:53.161367
350e1857-d840-4f15-b70f-ac3d0b432fb5	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-07	1820000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414217	2026-03-03 07:44:53.164013
1776aa0a-8f48-4892-9265-e2cfaaa6fcbf	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-07	9720000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414214	2026-03-03 07:44:53.166688
3eeba075-18ae-40cd-a06a-7b82685421c4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-07	4705000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414211	2026-03-03 07:44:53.169392
8bc8a9ce-cd80-442a-a861-59e28f17db2c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-07	24290000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414208	2026-03-03 07:44:53.171929
e7c7a5a2-d933-433f-9782-d10d581ba37e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	2150000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414205	2026-03-03 07:44:53.174597
8069c760-ae88-4f61-8934-97a2bb292f7f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-06	3320000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414201	2026-03-03 07:44:53.177209
19e4187a-3a5c-475d-8dd1-3420dc6b3c7c	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41418	2026-03-03 07:44:55.548621
60debd86-32f6-43b7-a2ec-6b1e11e3b963	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	18000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414177	2026-03-03 07:44:55.551289
ce2359e0-3da1-429c-aa3b-ebdbe33be337	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	1120000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414174	2026-03-03 07:44:55.554076
80d8da65-7ebb-4df1-8b97-492493fb0567	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	2000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41417	2026-03-03 07:44:55.557537
20979edb-8aaf-4341-942a-6b5ce413b7d6	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	600000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414167	2026-03-03 07:44:55.560108
8f289eaa-648b-44e7-9854-967a3e24566f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-04	17540000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414152	2026-03-03 07:44:55.562744
b4895376-0424-488b-b35e-a7764134c295	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-04	11650000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414148	2026-03-03 07:44:55.565379
cdc8cecc-1c75-42f8-b4b8-d42bb62e0d13	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	1500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414145	2026-03-03 07:44:55.567943
bce29dc0-32c9-42de-bf0a-23bb1860ba7a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	8500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414141	2026-03-03 07:44:55.570449
048e9ccf-0bd2-48d7-8b61-d98a503a62b5	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	1325000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414137	2026-03-03 07:44:55.572993
bb56a7e9-edd2-4f66-9e97-6163a0e2186a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-03	7720000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414134	2026-03-03 07:44:55.575524
ad387181-4e53-425e-97b0-9ffefa2023be	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-03	16025000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414131	2026-03-03 07:44:55.578041
bfa83ed8-eb76-46a0-a513-e627f4e3f114	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	15000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414128	2026-03-03 07:44:55.58056
932dd910-2b21-424a-a0ad-8b8d447ad8bd	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	12420000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414124	2026-03-03 07:44:55.583009
93afb183-18c2-409f-a423-6528d68adcd9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	3740000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414121	2026-03-03 07:44:55.585603
0ec7350c-7dc1-482a-90b6-d58d098871b8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-30	11420000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414118	2026-03-03 07:44:55.588077
89ae0527-63cf-4a4e-a1d8-7b29f2a1b587	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	10000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414115	2026-03-03 07:44:55.590578
0c9fad9d-ffac-4532-b5bf-e30d8b576f8b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	1120000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414112	2026-03-03 07:44:55.59329
acd0a66e-449c-4524-a698-9d7b1aab942b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	6560000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414108	2026-03-03 07:44:55.595712
6f3ed7d4-1683-4072-8108-07ade22f8151	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	4950000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414105	2026-03-03 07:44:55.598197
65a1f4db-fc99-4a47-bb4b-074a11cd6906	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	920000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414102	2026-03-03 07:44:55.600641
068037f2-c422-4444-8790-a416c9b8cb5c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-29	4950000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414099	2026-03-03 07:44:55.60327
8f8068d8-b8f5-4f30-a53b-6a15dab6af48	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-29	17945000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414095	2026-03-03 07:44:55.605733
32e1c07c-c22d-4f13-a1ef-a25b9a62bf4b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	6925000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414092	2026-03-03 07:44:55.608199
56e0e936-16b8-4c79-acba-b1cf3865a048	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	10000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414089	2026-03-03 07:44:55.610615
93459bdc-d6bb-4f8f-894c-c315c0a9700b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	6155000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414085	2026-03-03 07:44:55.613258
f159642f-34e5-4e5f-8cc8-306c47a0c6e2	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-28	10150000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414082	2026-03-03 07:44:55.61573
25669357-8856-4a9a-b65e-f81502f4d958	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-27	6030000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414079	2026-03-03 07:44:55.618214
1729b5f6-eb46-4295-a395-dfb7514e97fd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-27	2035000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414075	2026-03-03 07:44:55.621493
cf28b119-79f9-4b4d-a61b-a50a5d540bfb	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	10190000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414072	2026-03-03 07:44:55.624085
a1c2c99d-3280-48f0-872a-dc18b347e31f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	10950000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414069	2026-03-03 07:44:55.626671
e1fc1035-e6b1-4ca2-8f5a-7f96a1ad3ad6	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	5080000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414066	2026-03-03 07:44:55.629215
ccb9ecea-f12c-480c-bc99-8645be0dbe35	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	10190000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414062	2026-03-03 07:44:55.631684
2cd6a530-aae9-433e-9bc9-b73c0a99e503	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	24060000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414059	2026-03-03 07:44:55.634252
6e6aa5ea-3be6-412e-8c4b-b06dee33327d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	25270000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414056	2026-03-03 07:44:55.636777
d364bc19-7d68-4ca5-a3f3-571575619c42	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	6970000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414053	2026-03-03 07:44:55.639264
ef63c971-2c6c-4baf-a32c-4fc5e6a64153	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	8080000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414049	2026-03-03 07:44:55.641782
c56cb135-3c7b-4d92-9ff3-307ceb5eb102	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	50000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414046	2026-03-03 07:44:55.644319
dcc7944d-cf48-4f02-bff8-68c031784ab0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	19120000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414043	2026-03-03 07:44:55.646858
c2c9f587-53a6-4e4c-a4f4-211a75488fd8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	47010000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414039	2026-03-03 07:44:55.649383
ac8234fd-781e-4cdb-99ef-eabbb7c19c05	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-23	2870000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414036	2026-03-03 07:44:55.651819
ce899d99-ccc3-4f62-9f3c-6d459998d170	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-23	24990000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414033	2026-03-03 07:44:55.654366
580d324e-dbd7-4a23-ba16-fdf6d25687f4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-23	47010000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414029	2026-03-03 07:44:55.656829
ba516449-fd29-4264-af12-9b9ac3a64b1b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-23	5320000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414026	2026-03-03 07:44:55.65927
092a075c-dbb7-488a-96cc-82d379a8ee6d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	310000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414023	2026-03-03 07:44:55.661768
fb1d4b4e-44f9-42b5-93af-480fa5d79e04	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	18040000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414019	2026-03-03 07:44:55.664448
b7c33e53-036d-4eb4-af58-a8f839e91ee4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-22	24660000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414016	2026-03-03 07:44:55.667005
e2311bd0-55dd-496c-b4a7-a893ac8d1f7a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	30310000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414013	2026-03-03 07:44:55.669581
ad8c15e0-02f8-4549-8179-83c562b526e1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	990000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41401	2026-03-03 07:44:55.672256
433c59f5-7f9c-4ef1-942b-0b963b420a1f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	10230000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414006	2026-03-03 07:44:55.674942
677fdf5f-ee97-4712-af38-4d35754dd6d1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	9870000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414003	2026-03-03 07:44:55.67752
43e45027-9351-44c9-807d-d48b20354337	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	22810000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413999	2026-03-03 07:44:55.680066
50775f85-2ec6-4700-b3bd-b34cef630509	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	15000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413996	2026-03-03 07:44:55.682793
6d85b99f-51ac-4c88-b317-a6748b787b03	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	5500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413993	2026-03-03 07:44:55.685442
85fc5b10-aed7-4961-9b4b-7648df6bdca9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	600000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413988	2026-03-03 07:44:55.688775
29576ca7-da0c-4cc6-a15b-a6d2fe59b899	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-20	9760000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413984	2026-03-03 07:44:55.691375
b32dd438-5102-462d-ba55-b925e7f75a0b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-20	34820000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413981	2026-03-03 07:44:55.694026
9fbd7549-175a-4439-8c55-61907808dcc8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	4260000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413977	2026-03-03 07:44:55.696613
e482593b-a7b0-4d1a-94a8-e607e72a1462	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	34820000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413974	2026-03-03 07:44:55.699144
dab505b6-c04d-4b01-b897-3c2ccb1a5535	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-17	14450000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413967	2026-03-03 07:44:55.701697
9c8905cc-dce6-4cac-8c35-46cde758588e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-17	14450000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413958	2026-03-03 07:44:55.704415
\.


--
-- Data for Name: deduction_items; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.deduction_items (id, name, description, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deduction_levels; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.deduction_levels (id, item_id, name, amount, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grade_prices; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.grade_prices (id, model_id, grade_id, price, applied_at, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.grades (id, name, description, sort_order, is_active, is_default, created_at, updated_at) FROM stdin;
2a408257-9c92-4c71-8161-5b8d12ba89c4	A+	\N	1	t	t	2026-03-03 03:45:43.512188	2026-03-03 03:45:43.512192
cee2cf94-10c3-4cfb-ba33-093500fe8266	A	\N	2	t	f	2026-03-03 03:45:43.5122	2026-03-03 03:45:43.512201
d62bfa81-f6a5-49ce-b693-f081789525e2	A-	\N	3	t	f	2026-03-03 03:45:43.512214	2026-03-03 03:45:43.512215
fe3ef5d5-8193-4e4b-8946-227697cbed37	B+	\N	4	t	f	2026-03-03 03:45:43.512222	2026-03-03 03:45:43.512223
06c732cb-6284-4f5a-8140-28bebfddae6f	B	\N	5	t	f	2026-03-03 03:45:43.512229	2026-03-03 03:45:43.51223
dff67739-90ae-495e-bab3-e87a88d13231	B-	\N	6	t	f	2026-03-03 03:45:43.512236	2026-03-03 03:45:43.512237
d4238379-0c8c-40a4-9396-204a20461e32	C	\N	7	t	f	2026-03-03 03:45:43.512244	2026-03-03 03:45:43.512245
f76baec2-2729-4985-b1cc-caa270c24c53	수출	\N	8	t	f	2026-03-03 03:45:43.51225	2026-03-03 03:45:43.512251
71dd1488-5b06-4eec-bc1c-80d11b7c76bf	기타	\N	9	t	f	2026-03-03 03:45:43.512257	2026-03-03 03:45:43.512257
\.


--
-- Data for Name: hq_price_applies; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.hq_price_applies (id, upload_job_id, version, memo, applied_count, price_changes, applied_by, applied_at, is_current) FROM stdin;
\.


--
-- Data for Name: hq_price_apply_locks; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.hq_price_apply_locks (id, is_locked, locked_by, locked_at, lock_reason) FROM stdin;
\.


--
-- Data for Name: netting_records; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.netting_records (id, counterparty_id, netting_date, netting_amount, status, memo, created_by, confirmed_by, confirmed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: netting_voucher_links; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.netting_voucher_links (id, netting_record_id, voucher_id, netted_amount, created_at) FROM stdin;
\.


--
-- Data for Name: partner_mappings; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partner_mappings (id, partner_id, model_id, partner_expression, confidence, is_manual, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: partner_prices; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partner_prices (id, partner_id, model_id, grade_id, price, uploaded_at, upload_job_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partners (id, name, region, contact_info, memo, branch_id, is_active, deleted_at, deleted_by, delete_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.payments (id, voucher_id, payment_date, amount, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: period_locks; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.period_locks (id, year_month, status, locked_voucher_count, locked_at, locked_by, unlocked_at, unlocked_by, memo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.receipts (id, voucher_id, receipt_date, amount, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: ssot_models; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.ssot_models (id, model_key, model_code, device_type, manufacturer, series, model_name, storage_gb, connectivity, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_allocations; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.transaction_allocations (id, transaction_id, voucher_id, allocated_amount, allocation_order, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: upload_jobs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.upload_jobs (id, job_type, status, progress, file_path, original_filename, file_hash, partner_id, created_by, result_summary, error_message, is_reviewed, is_confirmed, is_applied, created_at, started_at, completed_at, confirmed_at, applied_at) FROM stdin;
09ac4801-1570-491f-b4b3-67c0e3773601	VOUCHER_SALES_EXCEL	SUCCEEDED	100	uploads/settlement/725ebb83-aff8-483b-9d5d-79c439bf7023.xlsx	판매자료(반입포함).xlsx	8c53b14b2445e7fa2addb55b4b2fe980436c166f597bd1ef03850e65cc0bd8e5	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	{"new_count": 0, "total_rows": 361, "error_count": 0, "locked_count": 0, "update_count": 0, "conflict_count": 0, "excluded_count": 1, "unmatched_count": 360, "unmatched_names": ["엔터프라이즈(평택)", "아이온코리아", "윈윈사장님", "네오홀딩스(오주석)", "아프리카 중고폰", "에스텔", "허랑(IBS)", "누랄리(키르기스탄)", "균호 사장님", "필리핀(연합)", "베트남 중(수원)", "이브로힘(우즈백)", "소미트헌(우즈백)", "네이버스토어", "리퍼마켓(B2B)", "추가금(온라인)", "에코트레이드", "산하울라(압둘라동생)", "오재", "김하나", "옥션", "베트남 지사", "엔터프라이즈(당진)", "박팀장", "아심(두바이)", "문승현 (피지)", "광주 팔구사구", "베트남 홍손", "볼트테크", "다원", "중고나라", "HSH", "레이컴", "광주(sj컴퍼니)", "지덕", "다원 성준", "오에스티이씨에이치(홍대)", "쿠팡(대단한)", "뉴퍼마켓(대단한)", "폰테이너", "애플박사", "아초", "마삽", "앤디", "올웨이즈(다원)", "오사장님", "요크헤이븐 코리아", "11번가", "박걸", "어기(몽골)", "아정당", "W무역", "옥션(대단한)", "ANCOM(홍콩)", "STK-PK", "호두모바일", "에이블리4910", "자이드(미얀마)", "리씽크", "수리실(작업)", "김태연(베트남)", "폰가비(업스테어스)", "쿠팡(엘씨오씨)", "카카오쇼핑", "지마켓 (대단한)", "바이라(몽골)", "권영환(외부)", "솝다(몽골)", "미니", "이사장님", "김조아(우즈백)", "콕딜", "KREAM(금화)", "아부바크르", "떠리몰", "토스쇼핑", "마블", "지마켓(대단한)", "임태종(스든코퍼레이션)", "폰박스", "쿠팡(리플립)", "홍이(박걸)", "살람", "쿠팡", "11번가(대단한)", "스마트M", "인스코리아", "정엽 사장님", "뉴퍼마켓(다원)", "에코폰 상암점", "홍부희 사장님", "아이즈모바일", "네이버스토어(대단한)", "지마켓", "T딜", "STK.카림"], "column_mapping_used": {"memo": "비고", "profit": "손익", "as_cost": "A/S비용", "quantity": "수량", "avg_margin": "평균마진", "trade_date": "판매일", "profit_rate": "수익율", "sale_amount": "판매금액", "purchase_cost": "매입원가", "sale_deduction": "판매차감", "voucher_number": "번호", "actual_sale_price": "실판매가", "counterparty_name": "판매처", "purchase_deduction": "매입차감", "actual_purchase_price": "실매입가"}, "header_row_detected": 1}	\N	f	f	f	2026-03-03 07:28:27.141151	2026-03-03 07:28:31.345877	2026-03-03 07:28:32.208039	\N	\N
\.


--
-- Data for Name: upload_templates; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.upload_templates (id, name, voucher_type, column_mapping, skip_columns, is_default, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_counterparty_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_counterparty_favorites (id, user_id, counterparty_id, created_at) FROM stdin;
2004750b-8cc9-4d94-a0a7-0d587a628e11	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	6eb1110b-8ec8-487c-9a82-e2442663d029	2026-03-03 07:42:53.97478
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_favorites (id, user_id, model_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_list_items; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_list_items (id, list_id, model_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_lists; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_lists (id, user_id, name, description, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_partner_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_partner_favorites (id, user_id, partner_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at, last_login_at) FROM stdin;
0445d86e-f791-4dad-baec-5f91deb57adc	admin@example.com	$2b$12$jc7/bU1kF5FqQsHjpAhq4Okl3V4I1r0ruJTS6b9.0HfbqRyNBYmwS	관리자	ADMIN	t	2026-03-03 03:45:43.501654	2026-03-03 05:30:35.693239	2026-03-03 05:30:35.692523
2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	skp10216@gmail.com	$2b$12$i8FkV7NUIgdc2Hm1rnEdvuBERh6aHr0qd5W1AQt.io.KR6rvUKMWK	skp10216	ADMIN	t	2026-03-03 05:30:36.011157	2026-03-03 07:29:36.538107	2026-03-03 07:29:36.537364
d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	oys@dwt.kr	$2b$12$ckjUh36vsc7pjppgzKB4BOWpEay.dBb43P8SCLWNPEb5vtehg.38a	오유선	ADMIN	t	2026-03-03 07:36:59.756935	2026-03-03 07:46:59.986546	2026-03-03 07:46:59.985331
\.


--
-- Data for Name: voucher_change_requests; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.voucher_change_requests (id, voucher_id, upload_job_id, before_data, after_data, diff_summary, status, reviewed_by, review_memo, created_at, reviewed_at) FROM stdin;
\.


--
-- Data for Name: vouchers; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.vouchers (id, trade_date, counterparty_id, voucher_number, voucher_type, quantity, total_amount, purchase_cost, actual_purchase_price, deduction_amount, avg_unit_price, upm_settlement_status, payment_info, purchase_deduction, as_cost, sale_amount, sale_deduction, actual_sale_price, profit, profit_rate, avg_margin, is_adjustment, adjustment_type, original_voucher_id, adjustment_reason, settlement_status, payment_status, memo, upload_job_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_import_jobs bank_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_jobs
    ADD CONSTRAINT bank_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: bank_import_lines bank_import_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_pkey PRIMARY KEY (id);


--
-- Name: branches branches_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_name_key UNIQUE (name);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: compare_list_models compare_list_models_model_id_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_model_id_key UNIQUE (model_id);


--
-- Name: compare_list_models compare_list_models_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_pkey PRIMARY KEY (id);


--
-- Name: counterparties counterparties_code_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_code_key UNIQUE (code);


--
-- Name: counterparties counterparties_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_name_key UNIQUE (name);


--
-- Name: counterparties counterparties_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_pkey PRIMARY KEY (id);


--
-- Name: counterparty_aliases counterparty_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_pkey PRIMARY KEY (id);


--
-- Name: counterparty_transactions counterparty_transactions_bank_reference_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_bank_reference_key UNIQUE (bank_reference);


--
-- Name: counterparty_transactions counterparty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_pkey PRIMARY KEY (id);


--
-- Name: deduction_items deduction_items_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_items
    ADD CONSTRAINT deduction_items_name_key UNIQUE (name);


--
-- Name: deduction_items deduction_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_items
    ADD CONSTRAINT deduction_items_pkey PRIMARY KEY (id);


--
-- Name: deduction_levels deduction_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_levels
    ADD CONSTRAINT deduction_levels_pkey PRIMARY KEY (id);


--
-- Name: grade_prices grade_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_pkey PRIMARY KEY (id);


--
-- Name: grades grades_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_name_key UNIQUE (name);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: hq_price_applies hq_price_applies_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_pkey PRIMARY KEY (id);


--
-- Name: hq_price_apply_locks hq_price_apply_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_apply_locks
    ADD CONSTRAINT hq_price_apply_locks_pkey PRIMARY KEY (id);


--
-- Name: netting_records netting_records_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_pkey PRIMARY KEY (id);


--
-- Name: netting_voucher_links netting_voucher_links_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_pkey PRIMARY KEY (id);


--
-- Name: partner_mappings partner_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_pkey PRIMARY KEY (id);


--
-- Name: partner_prices partner_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_pkey PRIMARY KEY (id);


--
-- Name: partners partners_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_name_key UNIQUE (name);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: period_locks period_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_pkey PRIMARY KEY (id);


--
-- Name: ssot_models ssot_models_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.ssot_models
    ADD CONSTRAINT ssot_models_pkey PRIMARY KEY (id);


--
-- Name: transaction_allocations transaction_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_pkey PRIMARY KEY (id);


--
-- Name: upload_jobs upload_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_pkey PRIMARY KEY (id);


--
-- Name: upload_templates upload_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_templates
    ADD CONSTRAINT upload_templates_pkey PRIMARY KEY (id);


--
-- Name: counterparty_aliases uq_counterparty_alias_name; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT uq_counterparty_alias_name UNIQUE (alias_name);


--
-- Name: netting_voucher_links uq_nvl_netting_voucher; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT uq_nvl_netting_voucher UNIQUE (netting_record_id, voucher_id);


--
-- Name: period_locks uq_period_lock_year_month; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT uq_period_lock_year_month UNIQUE (year_month);


--
-- Name: transaction_allocations uq_ta_transaction_voucher; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT uq_ta_transaction_voucher UNIQUE (transaction_id, voucher_id);


--
-- Name: user_counterparty_favorites uq_user_counterparty_favorite; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT uq_user_counterparty_favorite UNIQUE (user_id, counterparty_id);


--
-- Name: user_partner_favorites uq_user_partner_favorite; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT uq_user_partner_favorite UNIQUE (user_id, partner_id);


--
-- Name: vouchers uq_voucher_counterparty_date_number; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT uq_voucher_counterparty_date_number UNIQUE (counterparty_id, trade_date, voucher_number);


--
-- Name: user_counterparty_favorites user_counterparty_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_list_items user_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_pkey PRIMARY KEY (id);


--
-- Name: user_lists user_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_lists
    ADD CONSTRAINT user_lists_pkey PRIMARY KEY (id);


--
-- Name: user_partner_favorites user_partner_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: voucher_change_requests voucher_change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_pkey PRIMARY KEY (id);


--
-- Name: vouchers vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_action_created; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_action_created ON public.audit_logs USING btree (action, created_at);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_target; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_target ON public.audit_logs USING btree (target_type, target_id);


--
-- Name: ix_audit_logs_trace_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_trace_id ON public.audit_logs USING btree (trace_id);


--
-- Name: ix_audit_logs_user_created; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_user_created ON public.audit_logs USING btree (user_id, created_at);


--
-- Name: ix_bij_created_at; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bij_created_at ON public.bank_import_jobs USING btree (created_at);


--
-- Name: ix_bij_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bij_status ON public.bank_import_jobs USING btree (status);


--
-- Name: ix_bil_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_counterparty ON public.bank_import_lines USING btree (counterparty_id);


--
-- Name: ix_bil_duplicate_key; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_duplicate_key ON public.bank_import_lines USING btree (duplicate_key);


--
-- Name: ix_bil_import_job; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_import_job ON public.bank_import_lines USING btree (import_job_id);


--
-- Name: ix_bil_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_status ON public.bank_import_lines USING btree (status);


--
-- Name: ix_compare_list_models_sort; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_compare_list_models_sort ON public.compare_list_models USING btree (sort_order);


--
-- Name: ix_ct_counterparty_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_counterparty_date ON public.counterparty_transactions USING btree (counterparty_id, transaction_date);


--
-- Name: ix_ct_source; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_source ON public.counterparty_transactions USING btree (source);


--
-- Name: ix_ct_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_status ON public.counterparty_transactions USING btree (status);


--
-- Name: ix_deduction_levels_item_name; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_deduction_levels_item_name ON public.deduction_levels USING btree (item_id, name);


--
-- Name: ix_grade_prices_model_grade; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_grade_prices_model_grade ON public.grade_prices USING btree (model_id, grade_id);


--
-- Name: ix_nr_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_counterparty ON public.netting_records USING btree (counterparty_id);


--
-- Name: ix_nr_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_date ON public.netting_records USING btree (netting_date);


--
-- Name: ix_nr_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_status ON public.netting_records USING btree (status);


--
-- Name: ix_partner_mappings_partner_expression; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_partner_mappings_partner_expression ON public.partner_mappings USING btree (partner_id, partner_expression);


--
-- Name: ix_partner_prices_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_partner_prices_model ON public.partner_prices USING btree (model_id);


--
-- Name: ix_partner_prices_partner_model_grade; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_partner_prices_partner_model_grade ON public.partner_prices USING btree (partner_id, model_id, grade_id);


--
-- Name: ix_payments_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_payments_voucher_id ON public.payments USING btree (voucher_id);


--
-- Name: ix_receipts_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_receipts_voucher_id ON public.receipts USING btree (voucher_id);


--
-- Name: ix_ssot_models_model_code; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_ssot_models_model_code ON public.ssot_models USING btree (model_code);


--
-- Name: ix_ssot_models_model_key; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_model_key ON public.ssot_models USING btree (model_key);


--
-- Name: ix_ssot_models_series; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_series ON public.ssot_models USING btree (series);


--
-- Name: ix_ssot_models_type_manufacturer; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_type_manufacturer ON public.ssot_models USING btree (device_type, manufacturer);


--
-- Name: ix_ta_transaction; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ta_transaction ON public.transaction_allocations USING btree (transaction_id);


--
-- Name: ix_ta_voucher; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ta_voucher ON public.transaction_allocations USING btree (voucher_id);


--
-- Name: ix_user_counterparty_favorites_user_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_counterparty_favorites_user_id ON public.user_counterparty_favorites USING btree (user_id);


--
-- Name: ix_user_favorites_user_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_favorites_user_model ON public.user_favorites USING btree (user_id, model_id);


--
-- Name: ix_user_list_items_list_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_list_items_list_model ON public.user_list_items USING btree (list_id, model_id);


--
-- Name: ix_user_lists_user; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_lists_user ON public.user_lists USING btree (user_id);


--
-- Name: ix_user_lists_user_name; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_lists_user_name ON public.user_lists USING btree (user_id, name);


--
-- Name: ix_user_partner_favorites_user_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_partner_favorites_user_id ON public.user_partner_favorites USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_voucher_change_requests_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_voucher_change_requests_voucher_id ON public.voucher_change_requests USING btree (voucher_id);


--
-- Name: ix_vouchers_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_counterparty ON public.vouchers USING btree (counterparty_id);


--
-- Name: ix_vouchers_trade_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_trade_date ON public.vouchers USING btree (trade_date);


--
-- Name: ix_vouchers_type_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_type_status ON public.vouchers USING btree (voucher_type, settlement_status);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_import_jobs bank_import_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_jobs
    ADD CONSTRAINT bank_import_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_import_lines bank_import_lines_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE SET NULL;


--
-- Name: bank_import_lines bank_import_lines_import_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_import_job_id_fkey FOREIGN KEY (import_job_id) REFERENCES public.bank_import_jobs(id) ON DELETE CASCADE;


--
-- Name: bank_import_lines bank_import_lines_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.counterparty_transactions(id) ON DELETE SET NULL;


--
-- Name: branches branches_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compare_list_models compare_list_models_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compare_list_models compare_list_models_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: counterparties counterparties_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: counterparty_aliases counterparty_aliases_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE CASCADE;


--
-- Name: counterparty_aliases counterparty_aliases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_bank_import_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_bank_import_line_id_fkey FOREIGN KEY (bank_import_line_id) REFERENCES public.bank_import_lines(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: counterparty_transactions counterparty_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_netting_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_netting_record_id_fkey FOREIGN KEY (netting_record_id) REFERENCES public.netting_records(id) ON DELETE SET NULL;


--
-- Name: deduction_levels deduction_levels_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_levels
    ADD CONSTRAINT deduction_levels_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.deduction_items(id) ON DELETE CASCADE;


--
-- Name: grade_prices grade_prices_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON DELETE RESTRICT;


--
-- Name: grade_prices grade_prices_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: hq_price_applies hq_price_applies_applied_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_applied_by_fkey FOREIGN KEY (applied_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hq_price_applies hq_price_applies_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: hq_price_apply_locks hq_price_apply_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_apply_locks
    ADD CONSTRAINT hq_price_apply_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_records netting_records_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_records netting_records_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: netting_records netting_records_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_voucher_links netting_voucher_links_netting_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_netting_record_id_fkey FOREIGN KEY (netting_record_id) REFERENCES public.netting_records(id) ON DELETE CASCADE;


--
-- Name: netting_voucher_links netting_voucher_links_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE RESTRICT;


--
-- Name: partner_mappings partner_mappings_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: partner_mappings partner_mappings_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON DELETE RESTRICT;


--
-- Name: partner_prices partner_prices_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: partners partners_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: partners partners_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: period_locks period_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: period_locks period_locks_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: receipts receipts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: receipts receipts_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: transaction_allocations transaction_allocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transaction_allocations transaction_allocations_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.counterparty_transactions(id) ON DELETE CASCADE;


--
-- Name: transaction_allocations transaction_allocations_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE RESTRICT;


--
-- Name: upload_jobs upload_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: upload_jobs upload_jobs_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: upload_templates upload_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_templates
    ADD CONSTRAINT upload_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_counterparty_favorites user_counterparty_favorites_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE CASCADE;


--
-- Name: user_counterparty_favorites user_counterparty_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_list_items user_list_items_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.user_lists(id) ON DELETE CASCADE;


--
-- Name: user_list_items user_list_items_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: user_lists user_lists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_lists
    ADD CONSTRAINT user_lists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_partner_favorites user_partner_favorites_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: user_partner_favorites user_partner_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: voucher_change_requests voucher_change_requests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: voucher_change_requests voucher_change_requests_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: voucher_change_requests voucher_change_requests_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: vouchers vouchers_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: vouchers vouchers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vouchers vouchers_original_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_original_voucher_id_fkey FOREIGN KEY (original_voucher_id) REFERENCES public.vouchers(id) ON DELETE SET NULL;


--
-- Name: vouchers vouchers_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict ztx4HWrBwCjaQYayCAHxHgO6Kg3CdfFIwhwfhAlgFlOJVJIoCgscvavpaHadioA

