--
-- PostgreSQL database dump
--

\restrict iYDinn5hE3NQ5bgot3wSf8fVaXYKRfn25SQ8p3cRC5m7qC79mY3OTG0exFtzMuh

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: adjustment_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.adjustment_type AS ENUM (
    'CORRECTION',
    'RETURN',
    'WRITE_OFF',
    'DISCOUNT'
);


ALTER TYPE public.adjustment_type OWNER TO dwt_user;

--
-- Name: audit_action; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.audit_action AS ENUM (
    'MODEL_CREATE',
    'MODEL_UPDATE',
    'MODEL_DEACTIVATE',
    'MODEL_BULK_CREATE',
    'MODEL_DELETE',
    'MODEL_BULK_DELETE',
    'GRADE_CREATE',
    'GRADE_UPDATE',
    'GRADE_DEACTIVATE',
    'PRICE_UPDATE',
    'DEDUCTION_CREATE',
    'DEDUCTION_UPDATE',
    'DEDUCTION_DEACTIVATE',
    'UPLOAD_START',
    'UPLOAD_COMPLETE',
    'UPLOAD_REVIEW',
    'UPLOAD_CONFIRM',
    'UPLOAD_APPLY',
    'UPLOAD_DELETE',
    'PARTNER_CREATE',
    'PARTNER_UPDATE',
    'PARTNER_DEACTIVATE',
    'PARTNER_MAPPING_UPDATE',
    'PARTNER_DELETE',
    'PARTNER_RESTORE',
    'PARTNER_MOVE',
    'BRANCH_CREATE',
    'BRANCH_UPDATE',
    'BRANCH_DELETE',
    'BRANCH_RESTORE',
    'USER_CREATE',
    'USER_UPDATE',
    'USER_DEACTIVATE',
    'USER_ROLE_CHANGE',
    'USER_LOGIN',
    'USER_LOGOUT',
    'VOUCHER_CREATE',
    'VOUCHER_UPDATE',
    'VOUCHER_DELETE',
    'VOUCHER_UPSERT',
    'VOUCHER_LOCK',
    'VOUCHER_UNLOCK',
    'VOUCHER_BATCH_LOCK',
    'VOUCHER_BATCH_UNLOCK',
    'RECEIPT_CREATE',
    'RECEIPT_DELETE',
    'PAYMENT_CREATE',
    'PAYMENT_DELETE',
    'COUNTERPARTY_CREATE',
    'COUNTERPARTY_UPDATE',
    'COUNTERPARTY_DELETE',
    'COUNTERPARTY_BATCH_DELETE',
    'COUNTERPARTY_BATCH_CREATE',
    'COUNTERPARTY_ALIAS_CREATE',
    'COUNTERPARTY_ALIAS_DELETE',
    'VOUCHER_CHANGE_DETECTED',
    'VOUCHER_CHANGE_APPROVED',
    'VOUCHER_CHANGE_REJECTED',
    'UPLOAD_TEMPLATE_CREATE',
    'UPLOAD_TEMPLATE_UPDATE',
    'TRANSACTION_CREATE',
    'TRANSACTION_UPDATE',
    'TRANSACTION_CANCEL',
    'TRANSACTION_HOLD',
    'TRANSACTION_UNHOLD',
    'TRANSACTION_HIDE',
    'TRANSACTION_UNHIDE',
    'ALLOCATION_CREATE',
    'ALLOCATION_DELETE',
    'ALLOCATION_AUTO',
    'NETTING_CREATE',
    'NETTING_CONFIRM',
    'NETTING_CANCEL',
    'ADJUSTMENT_VOUCHER_CREATE',
    'BANK_IMPORT_UPLOAD',
    'BANK_IMPORT_CONFIRM',
    'PERIOD_LOCK',
    'PERIOD_UNLOCK',
    'PERIOD_ADJUST'
);


ALTER TYPE public.audit_action OWNER TO dwt_user;

--
-- Name: bank_import_job_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.bank_import_job_status AS ENUM (
    'UPLOADED',
    'PARSED',
    'REVIEWING',
    'CONFIRMED',
    'FAILED'
);


ALTER TYPE public.bank_import_job_status OWNER TO dwt_user;

--
-- Name: bank_import_line_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.bank_import_line_status AS ENUM (
    'UNMATCHED',
    'MATCHED',
    'CONFIRMED',
    'DUPLICATE',
    'EXCLUDED'
);


ALTER TYPE public.bank_import_line_status OWNER TO dwt_user;

--
-- Name: change_request_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.change_request_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.change_request_status OWNER TO dwt_user;

--
-- Name: connectivity; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.connectivity AS ENUM (
    'LTE',
    'WIFI',
    'WIFI_CELLULAR',
    'STANDARD'
);


ALTER TYPE public.connectivity OWNER TO dwt_user;

--
-- Name: counterparty_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.counterparty_type AS ENUM (
    'SELLER',
    'BUYER',
    'BOTH'
);


ALTER TYPE public.counterparty_type OWNER TO dwt_user;

--
-- Name: device_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.device_type AS ENUM (
    'SMARTPHONE',
    'TABLET',
    'WEARABLE'
);


ALTER TYPE public.device_type OWNER TO dwt_user;

--
-- Name: job_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.job_status AS ENUM (
    'QUEUED',
    'RUNNING',
    'SUCCEEDED',
    'FAILED'
);


ALTER TYPE public.job_status OWNER TO dwt_user;

--
-- Name: job_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.job_type AS ENUM (
    'HQ_EXCEL',
    'PARTNER_EXCEL',
    'PARTNER_IMAGE',
    'VOUCHER_SALES_EXCEL',
    'VOUCHER_PURCHASE_EXCEL'
);


ALTER TYPE public.job_type OWNER TO dwt_user;

--
-- Name: manufacturer; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.manufacturer AS ENUM (
    'APPLE',
    'SAMSUNG',
    'OTHER'
);


ALTER TYPE public.manufacturer OWNER TO dwt_user;

--
-- Name: netting_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.netting_status AS ENUM (
    'DRAFT',
    'CONFIRMED',
    'CANCELLED'
);


ALTER TYPE public.netting_status OWNER TO dwt_user;

--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.payment_status AS ENUM (
    'UNPAID',
    'PARTIAL',
    'PAID',
    'LOCKED'
);


ALTER TYPE public.payment_status OWNER TO dwt_user;

--
-- Name: period_lock_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.period_lock_status AS ENUM (
    'OPEN',
    'LOCKED',
    'ADJUSTING'
);


ALTER TYPE public.period_lock_status OWNER TO dwt_user;

--
-- Name: settlement_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.settlement_status AS ENUM (
    'OPEN',
    'SETTLING',
    'SETTLED',
    'LOCKED'
);


ALTER TYPE public.settlement_status OWNER TO dwt_user;

--
-- Name: transaction_source; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_source AS ENUM (
    'MANUAL',
    'BANK_IMPORT',
    'NETTING'
);


ALTER TYPE public.transaction_source OWNER TO dwt_user;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_status AS ENUM (
    'PENDING',
    'PARTIAL',
    'ALLOCATED',
    'ON_HOLD',
    'HIDDEN',
    'CANCELLED'
);


ALTER TYPE public.transaction_status OWNER TO dwt_user;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.transaction_type AS ENUM (
    'DEPOSIT',
    'WITHDRAWAL'
);


ALTER TYPE public.transaction_type OWNER TO dwt_user;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.user_role AS ENUM (
    'ADMIN',
    'VIEWER',
    'SETTLEMENT'
);


ALTER TYPE public.user_role OWNER TO dwt_user;

--
-- Name: voucher_type; Type: TYPE; Schema: public; Owner: dwt_user
--

CREATE TYPE public.voucher_type AS ENUM (
    'SALES',
    'PURCHASE'
);


ALTER TYPE public.voucher_type OWNER TO dwt_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    trace_id uuid,
    user_id uuid NOT NULL,
    action public.audit_action NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid,
    before_data jsonb,
    after_data jsonb,
    description text,
    ip_address character varying(45),
    user_agent character varying(500),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO dwt_user;

--
-- Name: COLUMN audit_logs.trace_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.trace_id IS '추적 ID (업로드 작업 등 동일 작업 단위로 묶음)';


--
-- Name: COLUMN audit_logs.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.user_id IS '사용자 ID';


--
-- Name: COLUMN audit_logs.action; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.action IS '액션 타입';


--
-- Name: COLUMN audit_logs.target_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.target_type IS '대상 타입 (예: ssot_model, grade, deduction, upload_job)';


--
-- Name: COLUMN audit_logs.target_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.target_id IS '대상 ID';


--
-- Name: COLUMN audit_logs.before_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.before_data IS '변경 전 데이터';


--
-- Name: COLUMN audit_logs.after_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.after_data IS '변경 후 데이터';


--
-- Name: COLUMN audit_logs.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.description IS '변경 설명';


--
-- Name: COLUMN audit_logs.ip_address; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.ip_address IS 'IP 주소';


--
-- Name: COLUMN audit_logs.user_agent; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.user_agent IS 'User Agent';


--
-- Name: COLUMN audit_logs.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.audit_logs.created_at IS '생성 일시';


--
-- Name: bank_import_jobs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.bank_import_jobs (
    id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_hash character varying(64),
    bank_name character varying(100),
    account_number character varying(50),
    import_date_from date,
    import_date_to date,
    status public.bank_import_job_status NOT NULL,
    total_lines integer NOT NULL,
    matched_lines integer NOT NULL,
    confirmed_lines integer NOT NULL,
    error_message text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone,
    confirmed_at timestamp without time zone
);


ALTER TABLE public.bank_import_jobs OWNER TO dwt_user;

--
-- Name: COLUMN bank_import_jobs.file_path; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.file_path IS '파일 저장 경로';


--
-- Name: COLUMN bank_import_jobs.original_filename; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.original_filename IS '원본 파일명';


--
-- Name: COLUMN bank_import_jobs.file_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.file_hash IS '파일 해시 (중복 방지)';


--
-- Name: COLUMN bank_import_jobs.bank_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.bank_name IS '은행명';


--
-- Name: COLUMN bank_import_jobs.account_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.account_number IS '계좌번호';


--
-- Name: COLUMN bank_import_jobs.import_date_from; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.import_date_from IS '가져오기 기간 시작';


--
-- Name: COLUMN bank_import_jobs.import_date_to; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.import_date_to IS '가져오기 기간 끝';


--
-- Name: COLUMN bank_import_jobs.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.status IS '작업 상태';


--
-- Name: COLUMN bank_import_jobs.total_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.total_lines IS '전체 라인 수';


--
-- Name: COLUMN bank_import_jobs.matched_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.matched_lines IS '매칭된 라인 수';


--
-- Name: COLUMN bank_import_jobs.confirmed_lines; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.confirmed_lines IS '확정된 라인 수';


--
-- Name: COLUMN bank_import_jobs.error_message; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.error_message IS '에러 메시지';


--
-- Name: COLUMN bank_import_jobs.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.created_by IS '등록자 ID';


--
-- Name: COLUMN bank_import_jobs.completed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.completed_at IS '파싱 완료 일시';


--
-- Name: COLUMN bank_import_jobs.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_jobs.confirmed_at IS '확정 일시';


--
-- Name: bank_import_lines; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.bank_import_lines (
    id uuid NOT NULL,
    import_job_id uuid NOT NULL,
    line_number integer NOT NULL,
    transaction_date date NOT NULL,
    description character varying(500) NOT NULL,
    amount numeric(18,2) NOT NULL,
    balance_after numeric(18,2),
    counterparty_name_raw character varying(200),
    counterparty_id uuid,
    status public.bank_import_line_status NOT NULL,
    match_confidence numeric(5,2),
    duplicate_key character varying(128),
    bank_reference character varying(100),
    transaction_id uuid,
    raw_data jsonb,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.bank_import_lines OWNER TO dwt_user;

--
-- Name: COLUMN bank_import_lines.import_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.import_job_id IS '임포트 작업 ID';


--
-- Name: COLUMN bank_import_lines.line_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.line_number IS '파일 내 행 번호';


--
-- Name: COLUMN bank_import_lines.transaction_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.transaction_date IS '거래일';


--
-- Name: COLUMN bank_import_lines.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.description IS '적요/설명';


--
-- Name: COLUMN bank_import_lines.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.amount IS '금액 (양수=입금, 음수=출금)';


--
-- Name: COLUMN bank_import_lines.balance_after; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.balance_after IS '거래 후 잔액';


--
-- Name: COLUMN bank_import_lines.counterparty_name_raw; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.counterparty_name_raw IS '원본 거래처명';


--
-- Name: COLUMN bank_import_lines.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.counterparty_id IS '매칭된 거래처 ID';


--
-- Name: COLUMN bank_import_lines.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.status IS '라인 상태';


--
-- Name: COLUMN bank_import_lines.match_confidence; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.match_confidence IS '매칭 신뢰도 (0-100%)';


--
-- Name: COLUMN bank_import_lines.duplicate_key; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.duplicate_key IS '중복 감지 키: hash(date+amount+description+bank_ref)';


--
-- Name: COLUMN bank_import_lines.bank_reference; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.bank_reference IS '은행 참조번호';


--
-- Name: COLUMN bank_import_lines.transaction_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.transaction_id IS '확정 후 연결된 Transaction ID';


--
-- Name: COLUMN bank_import_lines.raw_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.bank_import_lines.raw_data IS '원본 행 전체 (JSON)';


--
-- Name: branches; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.branches (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(100),
    contact_info character varying(200),
    memo text,
    is_active boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by uuid,
    delete_reason character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.branches OWNER TO dwt_user;

--
-- Name: COLUMN branches.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.name IS '지사명';


--
-- Name: COLUMN branches.region; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.region IS '지역';


--
-- Name: COLUMN branches.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.contact_info IS '연락처 정보';


--
-- Name: COLUMN branches.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.memo IS '운영 메모';


--
-- Name: COLUMN branches.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.is_active IS '활성 상태';


--
-- Name: COLUMN branches.deleted_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.deleted_at IS '삭제 일시 (소프트 삭제)';


--
-- Name: COLUMN branches.deleted_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.deleted_by IS '삭제한 사용자 ID';


--
-- Name: COLUMN branches.delete_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.delete_reason IS '삭제 사유';


--
-- Name: COLUMN branches.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.created_at IS '생성 일시';


--
-- Name: COLUMN branches.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.branches.updated_at IS '수정 일시 (낙관적 락 version으로 사용)';


--
-- Name: compare_list_models; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.compare_list_models (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    added_by uuid
);


ALTER TABLE public.compare_list_models OWNER TO dwt_user;

--
-- Name: COLUMN compare_list_models.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN compare_list_models.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN compare_list_models.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.created_at IS '추가 일시';


--
-- Name: COLUMN compare_list_models.added_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.compare_list_models.added_by IS '추가한 관리자 ID';


--
-- Name: counterparties; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparties (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(50),
    counterparty_type public.counterparty_type NOT NULL,
    branch_id uuid,
    contact_info character varying(500),
    memo text,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.counterparties OWNER TO dwt_user;

--
-- Name: COLUMN counterparties.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.name IS '시스템 표준 거래처명 (SSOT)';


--
-- Name: COLUMN counterparties.code; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.code IS '거래처 고유코드 (선택)';


--
-- Name: COLUMN counterparties.counterparty_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.counterparty_type IS '거래처 타입: seller(판매처)/buyer(매입처)/both(양쪽)';


--
-- Name: COLUMN counterparties.branch_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.branch_id IS '소속 지사 ID';


--
-- Name: COLUMN counterparties.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.contact_info IS '연락처 정보';


--
-- Name: COLUMN counterparties.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.memo IS '메모';


--
-- Name: COLUMN counterparties.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparties.is_active IS '활성 상태';


--
-- Name: counterparty_aliases; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparty_aliases (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    alias_name character varying(200) NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.counterparty_aliases OWNER TO dwt_user;

--
-- Name: COLUMN counterparty_aliases.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.counterparty_id IS '연결된 거래처 ID';


--
-- Name: COLUMN counterparty_aliases.alias_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.alias_name IS 'UPM 표기명 (별칭)';


--
-- Name: COLUMN counterparty_aliases.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_aliases.created_by IS '등록자 ID';


--
-- Name: counterparty_transactions; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.counterparty_transactions (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    transaction_type public.transaction_type NOT NULL,
    transaction_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    allocated_amount numeric(18,2) NOT NULL,
    memo text,
    source public.transaction_source NOT NULL,
    bank_reference character varying(100),
    bank_import_line_id uuid,
    netting_record_id uuid,
    status public.transaction_status NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_ct_allocated_lte_amount CHECK ((allocated_amount <= amount)),
    CONSTRAINT ck_ct_allocated_nonneg CHECK ((allocated_amount >= (0)::numeric)),
    CONSTRAINT ck_ct_amount_positive CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.counterparty_transactions OWNER TO dwt_user;

--
-- Name: COLUMN counterparty_transactions.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.counterparty_id IS '거래처 ID';


--
-- Name: COLUMN counterparty_transactions.transaction_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.transaction_type IS 'DEPOSIT(입금)/WITHDRAWAL(출금)';


--
-- Name: COLUMN counterparty_transactions.transaction_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.transaction_date IS '입출금일';


--
-- Name: COLUMN counterparty_transactions.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.amount IS '금액 (양수만)';


--
-- Name: COLUMN counterparty_transactions.allocated_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.allocated_amount IS '배분 누적액 (비정규화)';


--
-- Name: COLUMN counterparty_transactions.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.memo IS '메모';


--
-- Name: COLUMN counterparty_transactions.source; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.source IS '발생 소스: MANUAL/BANK_IMPORT/NETTING';


--
-- Name: COLUMN counterparty_transactions.bank_reference; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.bank_reference IS '은행 참조번호 (중복 방지)';


--
-- Name: COLUMN counterparty_transactions.bank_import_line_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.bank_import_line_id IS '은행 임포트 라인 ID';


--
-- Name: COLUMN counterparty_transactions.netting_record_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.netting_record_id IS '상계 레코드 ID';


--
-- Name: COLUMN counterparty_transactions.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.status IS 'PENDING→PARTIAL→ALLOCATED / CANCELLED';


--
-- Name: COLUMN counterparty_transactions.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.counterparty_transactions.created_by IS '등록자 ID';


--
-- Name: deduction_items; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.deduction_items (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.deduction_items OWNER TO dwt_user;

--
-- Name: COLUMN deduction_items.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.name IS '차감 항목명 (예: 내부 잔상, 서브 잔상, 줄감, 외관 찍힘, 카메라 불량)';


--
-- Name: COLUMN deduction_items.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.description IS '항목 설명';


--
-- Name: COLUMN deduction_items.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN deduction_items.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.is_active IS '활성 상태 (사용 중인 항목은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN deduction_items.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.created_at IS '생성 일시';


--
-- Name: COLUMN deduction_items.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_items.updated_at IS '수정 일시';


--
-- Name: deduction_levels; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.deduction_levels (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    amount integer NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.deduction_levels OWNER TO dwt_user;

--
-- Name: COLUMN deduction_levels.item_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.item_id IS '차감 항목 ID';


--
-- Name: COLUMN deduction_levels.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.name IS '레벨명 (예: L1, L2, L3, L4 또는 중상, 상, 대잔상)';


--
-- Name: COLUMN deduction_levels.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.amount IS '차감 금액 (원)';


--
-- Name: COLUMN deduction_levels.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.sort_order IS '정렬 순서 (낮을수록 상위, 보통 차감 금액 순)';


--
-- Name: COLUMN deduction_levels.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.is_active IS '활성 상태 (사용 중인 레벨은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN deduction_levels.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.created_at IS '생성 일시';


--
-- Name: COLUMN deduction_levels.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.deduction_levels.updated_at IS '수정 일시';


--
-- Name: grade_prices; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.grade_prices (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    grade_id uuid NOT NULL,
    price integer NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grade_prices OWNER TO dwt_user;

--
-- Name: COLUMN grade_prices.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN grade_prices.grade_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.grade_id IS '등급 ID';


--
-- Name: COLUMN grade_prices.price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.price IS '등급별 기본가 (원)';


--
-- Name: COLUMN grade_prices.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.applied_at IS '적용 일시';


--
-- Name: COLUMN grade_prices.version; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.version IS '버전 (업로드/적용 시 증가)';


--
-- Name: COLUMN grade_prices.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.created_at IS '생성 일시';


--
-- Name: COLUMN grade_prices.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grade_prices.updated_at IS '수정 일시';


--
-- Name: grades; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.grades (
    id uuid NOT NULL,
    name character varying(20) NOT NULL,
    description character varying(200),
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grades OWNER TO dwt_user;

--
-- Name: COLUMN grades.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.name IS '등급명 (예: A+, A, A-, B+, 수출, 기타)';


--
-- Name: COLUMN grades.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.description IS '등급 설명';


--
-- Name: COLUMN grades.sort_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.sort_order IS '정렬 순서 (낮을수록 상위)';


--
-- Name: COLUMN grades.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.is_active IS '활성 상태 (사용 중인 등급은 삭제 금지, 비활성화로 운영)';


--
-- Name: COLUMN grades.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.is_default IS '기본 등급 여부 (비교 화면 기본 선택)';


--
-- Name: COLUMN grades.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.created_at IS '생성 일시';


--
-- Name: COLUMN grades.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.grades.updated_at IS '수정 일시';


--
-- Name: hq_price_applies; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.hq_price_applies (
    id uuid NOT NULL,
    upload_job_id uuid NOT NULL,
    version integer NOT NULL,
    memo text,
    applied_count integer NOT NULL,
    price_changes jsonb,
    applied_by uuid NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    is_current boolean NOT NULL
);


ALTER TABLE public.hq_price_applies OWNER TO dwt_user;

--
-- Name: COLUMN hq_price_applies.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.upload_job_id IS '업로드 작업 ID';


--
-- Name: COLUMN hq_price_applies.version; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.version IS '적용 버전';


--
-- Name: COLUMN hq_price_applies.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.memo IS '적용 메모';


--
-- Name: COLUMN hq_price_applies.applied_count; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_count IS '적용된 모델 수';


--
-- Name: COLUMN hq_price_applies.price_changes; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.price_changes IS '가격 변경 요약';


--
-- Name: COLUMN hq_price_applies.applied_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_by IS '적용자 ID';


--
-- Name: COLUMN hq_price_applies.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.applied_at IS '적용 일시';


--
-- Name: COLUMN hq_price_applies.is_current; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_applies.is_current IS '현재 적용 중 여부';


--
-- Name: hq_price_apply_locks; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.hq_price_apply_locks (
    id integer NOT NULL,
    is_locked boolean NOT NULL,
    locked_by uuid,
    locked_at timestamp without time zone,
    lock_reason character varying(200)
);


ALTER TABLE public.hq_price_apply_locks OWNER TO dwt_user;

--
-- Name: COLUMN hq_price_apply_locks.id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.id IS '락 ID (항상 1)';


--
-- Name: COLUMN hq_price_apply_locks.is_locked; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.is_locked IS '락 상태';


--
-- Name: COLUMN hq_price_apply_locks.locked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.locked_by IS '락 소유자 ID';


--
-- Name: COLUMN hq_price_apply_locks.locked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.locked_at IS '락 시작 일시';


--
-- Name: COLUMN hq_price_apply_locks.lock_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.hq_price_apply_locks.lock_reason IS '락 사유';


--
-- Name: netting_records; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.netting_records (
    id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    netting_date date NOT NULL,
    netting_amount numeric(18,2) NOT NULL,
    status public.netting_status NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_nr_amount_positive CHECK ((netting_amount > (0)::numeric))
);


ALTER TABLE public.netting_records OWNER TO dwt_user;

--
-- Name: COLUMN netting_records.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.counterparty_id IS '거래처 ID';


--
-- Name: COLUMN netting_records.netting_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.netting_date IS '상계일';


--
-- Name: COLUMN netting_records.netting_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.netting_amount IS '상계 금액';


--
-- Name: COLUMN netting_records.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.status IS 'DRAFT→CONFIRMED / CANCELLED';


--
-- Name: COLUMN netting_records.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.memo IS '메모';


--
-- Name: COLUMN netting_records.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.created_by IS '생성자 ID';


--
-- Name: COLUMN netting_records.confirmed_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.confirmed_by IS '확정자 ID';


--
-- Name: COLUMN netting_records.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_records.confirmed_at IS '확정 일시';


--
-- Name: netting_voucher_links; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.netting_voucher_links (
    id uuid NOT NULL,
    netting_record_id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    netted_amount numeric(18,2) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_nvl_amount_positive CHECK ((netted_amount > (0)::numeric))
);


ALTER TABLE public.netting_voucher_links OWNER TO dwt_user;

--
-- Name: COLUMN netting_voucher_links.netting_record_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.netting_record_id IS '상계 레코드 ID';


--
-- Name: COLUMN netting_voucher_links.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.voucher_id IS '전표 ID';


--
-- Name: COLUMN netting_voucher_links.netted_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.netting_voucher_links.netted_amount IS '상계 적용 금액';


--
-- Name: partner_mappings; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partner_mappings (
    id uuid NOT NULL,
    partner_id uuid NOT NULL,
    model_id uuid NOT NULL,
    partner_expression character varying(200) NOT NULL,
    confidence double precision NOT NULL,
    is_manual boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partner_mappings OWNER TO dwt_user;

--
-- Name: COLUMN partner_mappings.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.partner_id IS '거래처 ID';


--
-- Name: COLUMN partner_mappings.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN partner_mappings.partner_expression; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.partner_expression IS '거래처 원본 표기 (예: 아이폰15프로맥스 256)';


--
-- Name: COLUMN partner_mappings.confidence; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.confidence IS '매핑 신뢰도 (0.0 ~ 1.0, 수동 매핑은 1.0)';


--
-- Name: COLUMN partner_mappings.is_manual; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.is_manual IS '수동 매핑 여부';


--
-- Name: COLUMN partner_mappings.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.created_at IS '생성 일시';


--
-- Name: COLUMN partner_mappings.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_mappings.updated_at IS '수정 일시';


--
-- Name: partner_prices; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partner_prices (
    id uuid NOT NULL,
    partner_id uuid NOT NULL,
    model_id uuid NOT NULL,
    grade_id uuid NOT NULL,
    price integer NOT NULL,
    uploaded_at timestamp without time zone NOT NULL,
    upload_job_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partner_prices OWNER TO dwt_user;

--
-- Name: COLUMN partner_prices.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.partner_id IS '거래처 ID';


--
-- Name: COLUMN partner_prices.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN partner_prices.grade_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.grade_id IS '등급 ID';


--
-- Name: COLUMN partner_prices.price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.price IS '거래처 단가 (원)';


--
-- Name: COLUMN partner_prices.uploaded_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.uploaded_at IS '업로드 일시';


--
-- Name: COLUMN partner_prices.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.upload_job_id IS '업로드 작업 ID';


--
-- Name: COLUMN partner_prices.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.created_at IS '생성 일시';


--
-- Name: COLUMN partner_prices.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partner_prices.updated_at IS '수정 일시';


--
-- Name: partners; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(100),
    contact_info character varying(200),
    memo text,
    branch_id uuid,
    is_active boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by uuid,
    delete_reason character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.partners OWNER TO dwt_user;

--
-- Name: COLUMN partners.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.name IS '거래처명 (예: 부천, 광명, 서울, 부산, 대전)';


--
-- Name: COLUMN partners.region; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.region IS '지역';


--
-- Name: COLUMN partners.contact_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.contact_info IS '연락처 정보';


--
-- Name: COLUMN partners.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.memo IS '운영 메모';


--
-- Name: COLUMN partners.branch_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.branch_id IS '소속 지사 ID';


--
-- Name: COLUMN partners.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.is_active IS '활성 상태';


--
-- Name: COLUMN partners.deleted_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.deleted_at IS '삭제 일시 (소프트 삭제)';


--
-- Name: COLUMN partners.deleted_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.deleted_by IS '삭제한 사용자 ID';


--
-- Name: COLUMN partners.delete_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.delete_reason IS '삭제 사유';


--
-- Name: COLUMN partners.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.created_at IS '생성 일시';


--
-- Name: COLUMN partners.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.partners.updated_at IS '수정 일시';


--
-- Name: payments; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.payments (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    payment_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO dwt_user;

--
-- Name: COLUMN payments.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.voucher_id IS '전표 ID';


--
-- Name: COLUMN payments.payment_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.payment_date IS '송금일';


--
-- Name: COLUMN payments.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.amount IS '송금액';


--
-- Name: COLUMN payments.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.memo IS '메모';


--
-- Name: COLUMN payments.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.payments.created_by IS '등록자 ID';


--
-- Name: period_locks; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.period_locks (
    id uuid NOT NULL,
    year_month character varying(7) NOT NULL,
    status public.period_lock_status NOT NULL,
    locked_voucher_count integer NOT NULL,
    locked_at timestamp without time zone,
    locked_by uuid,
    unlocked_at timestamp without time zone,
    unlocked_by uuid,
    memo text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.period_locks OWNER TO dwt_user;

--
-- Name: COLUMN period_locks.year_month; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.year_month IS '마감 기간 (YYYY-MM)';


--
-- Name: COLUMN period_locks.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.status IS 'OPEN/LOCKED/ADJUSTING';


--
-- Name: COLUMN period_locks.locked_voucher_count; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_voucher_count IS '마감된 전표 수';


--
-- Name: COLUMN period_locks.locked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_at IS '마감 일시';


--
-- Name: COLUMN period_locks.locked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.locked_by IS '마감 담당자 ID';


--
-- Name: COLUMN period_locks.unlocked_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.unlocked_at IS '해제 일시';


--
-- Name: COLUMN period_locks.unlocked_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.unlocked_by IS '해제 담당자 ID';


--
-- Name: COLUMN period_locks.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.period_locks.memo IS '메모';


--
-- Name: receipts; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.receipts (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    receipt_date date NOT NULL,
    amount numeric(18,2) NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.receipts OWNER TO dwt_user;

--
-- Name: COLUMN receipts.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.voucher_id IS '전표 ID';


--
-- Name: COLUMN receipts.receipt_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.receipt_date IS '입금일';


--
-- Name: COLUMN receipts.amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.amount IS '입금액';


--
-- Name: COLUMN receipts.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.memo IS '메모';


--
-- Name: COLUMN receipts.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.receipts.created_by IS '등록자 ID';


--
-- Name: ssot_models; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.ssot_models (
    id uuid NOT NULL,
    model_key character varying(100) NOT NULL,
    model_code character varying(100) NOT NULL,
    device_type public.device_type NOT NULL,
    manufacturer public.manufacturer NOT NULL,
    series character varying(100) NOT NULL,
    model_name character varying(200) NOT NULL,
    storage_gb integer NOT NULL,
    connectivity public.connectivity NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ssot_models OWNER TO dwt_user;

--
-- Name: COLUMN ssot_models.model_key; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_key IS '불변 모델 키 (동일 기종 공유, 스토리지 미포함)';


--
-- Name: COLUMN ssot_models.model_code; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_code IS '모델 코드 (model_key + storage 조합, 불변)';


--
-- Name: COLUMN ssot_models.device_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.device_type IS '기기 타입: smartphone, tablet, wearable';


--
-- Name: COLUMN ssot_models.manufacturer; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.manufacturer IS '제조사: apple, samsung, other';


--
-- Name: COLUMN ssot_models.series; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.series IS '시리즈 (예: iPhone 15, Galaxy S24)';


--
-- Name: COLUMN ssot_models.model_name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.model_name IS '모델명 (예: iPhone 15 Pro Max)';


--
-- Name: COLUMN ssot_models.storage_gb; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.storage_gb IS '스토리지 용량 (GB 단위, 1TB=1024)';


--
-- Name: COLUMN ssot_models.connectivity; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.connectivity IS '연결성: lte(스마트폰), wifi/wifi_cellular(태블릿), standard(웨어러블)';


--
-- Name: COLUMN ssot_models.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.is_active IS '활성 상태 (비활성화 시 Viewer 화면에서 숨김)';


--
-- Name: COLUMN ssot_models.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.created_at IS '생성 일시';


--
-- Name: COLUMN ssot_models.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.ssot_models.updated_at IS '수정 일시';


--
-- Name: transaction_allocations; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.transaction_allocations (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    allocated_amount numeric(18,2) NOT NULL,
    allocation_order integer NOT NULL,
    memo text,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_ta_amount_positive CHECK ((allocated_amount > (0)::numeric))
);


ALTER TABLE public.transaction_allocations OWNER TO dwt_user;

--
-- Name: COLUMN transaction_allocations.transaction_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.transaction_id IS '입출금 이벤트 ID';


--
-- Name: COLUMN transaction_allocations.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.voucher_id IS '전표 ID';


--
-- Name: COLUMN transaction_allocations.allocated_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.allocated_amount IS '배분 금액';


--
-- Name: COLUMN transaction_allocations.allocation_order; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.allocation_order IS '배분 순서 (FIFO 순서 기록)';


--
-- Name: COLUMN transaction_allocations.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.memo IS '메모';


--
-- Name: COLUMN transaction_allocations.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.transaction_allocations.created_by IS '등록자 ID';


--
-- Name: upload_jobs; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.upload_jobs (
    id uuid NOT NULL,
    job_type public.job_type NOT NULL,
    status public.job_status NOT NULL,
    progress integer NOT NULL,
    file_path character varying(500) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_hash character varying(64),
    partner_id uuid,
    created_by uuid NOT NULL,
    result_summary jsonb,
    error_message text,
    is_reviewed boolean NOT NULL,
    is_confirmed boolean NOT NULL,
    is_applied boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    confirmed_at timestamp without time zone,
    applied_at timestamp without time zone
);


ALTER TABLE public.upload_jobs OWNER TO dwt_user;

--
-- Name: COLUMN upload_jobs.job_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.job_type IS '작업 타입: hq_excel, partner_excel, partner_image';


--
-- Name: COLUMN upload_jobs.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.status IS '작업 상태: queued, running, succeeded, failed';


--
-- Name: COLUMN upload_jobs.progress; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.progress IS '진행률 (0-100, 단계 기반: 0/25/50/75/100)';


--
-- Name: COLUMN upload_jobs.file_path; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.file_path IS '업로드 파일 경로';


--
-- Name: COLUMN upload_jobs.original_filename; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.original_filename IS '원본 파일명';


--
-- Name: COLUMN upload_jobs.file_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.file_hash IS '파일 해시 (중복 방지용)';


--
-- Name: COLUMN upload_jobs.partner_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.partner_id IS '거래처 ID (거래처 업로드 시)';


--
-- Name: COLUMN upload_jobs.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.created_by IS '생성자 ID';


--
-- Name: COLUMN upload_jobs.result_summary; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.result_summary IS '결과 요약 (매핑/미매핑 개수, 오류 등)';


--
-- Name: COLUMN upload_jobs.error_message; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.error_message IS '오류 메시지 (실패 시)';


--
-- Name: COLUMN upload_jobs.is_reviewed; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_reviewed IS '검수 완료 여부';


--
-- Name: COLUMN upload_jobs.is_confirmed; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_confirmed IS '확정 여부';


--
-- Name: COLUMN upload_jobs.is_applied; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.is_applied IS '적용 여부 (본사 단가표)';


--
-- Name: COLUMN upload_jobs.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.created_at IS '생성 일시';


--
-- Name: COLUMN upload_jobs.started_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.started_at IS '시작 일시';


--
-- Name: COLUMN upload_jobs.completed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.completed_at IS '완료 일시';


--
-- Name: COLUMN upload_jobs.confirmed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.confirmed_at IS '확정 일시';


--
-- Name: COLUMN upload_jobs.applied_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_jobs.applied_at IS '적용 일시';


--
-- Name: upload_templates; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.upload_templates (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    voucher_type public.voucher_type NOT NULL,
    column_mapping jsonb NOT NULL,
    skip_columns jsonb,
    is_default boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.upload_templates OWNER TO dwt_user;

--
-- Name: COLUMN upload_templates.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.name IS '템플릿명';


--
-- Name: COLUMN upload_templates.voucher_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.voucher_type IS '전표 타입: SALES/PURCHASE';


--
-- Name: COLUMN upload_templates.column_mapping; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.column_mapping IS 'DB 필드 → 엑셀 헤더 매핑';


--
-- Name: COLUMN upload_templates.skip_columns; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.skip_columns IS '파싱 시 무시할 컬럼 목록';


--
-- Name: COLUMN upload_templates.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.is_default IS '기본 템플릿 여부';


--
-- Name: COLUMN upload_templates.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.upload_templates.created_by IS '생성자 ID';


--
-- Name: user_counterparty_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_counterparty_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    counterparty_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_counterparty_favorites OWNER TO dwt_user;

--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    model_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_favorites OWNER TO dwt_user;

--
-- Name: COLUMN user_favorites.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.user_id IS '사용자 ID';


--
-- Name: COLUMN user_favorites.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN user_favorites.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_favorites.created_at IS '즐겨찾기 추가 일시';


--
-- Name: user_list_items; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_list_items (
    id uuid NOT NULL,
    list_id uuid NOT NULL,
    model_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_list_items OWNER TO dwt_user;

--
-- Name: COLUMN user_list_items.list_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.list_id IS '리스트 ID';


--
-- Name: COLUMN user_list_items.model_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.model_id IS 'SSOT 모델 ID';


--
-- Name: COLUMN user_list_items.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_list_items.created_at IS '추가 일시';


--
-- Name: user_lists; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_lists (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    is_default boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_lists OWNER TO dwt_user;

--
-- Name: COLUMN user_lists.user_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.user_id IS '사용자 ID';


--
-- Name: COLUMN user_lists.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.name IS '리스트 이름 (예: 아이폰 라인업, 갤럭시 A급)';


--
-- Name: COLUMN user_lists.description; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.description IS '리스트 설명';


--
-- Name: COLUMN user_lists.is_default; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.is_default IS '기본 리스트 여부 (로그인 시 기본으로 열릴 리스트)';


--
-- Name: COLUMN user_lists.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.created_at IS '생성 일시';


--
-- Name: COLUMN user_lists.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.user_lists.updated_at IS '수정 일시';


--
-- Name: user_partner_favorites; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.user_partner_favorites (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_partner_favorites OWNER TO dwt_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    role public.user_role NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_login_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO dwt_user;

--
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.email IS '이메일 (로그인 ID)';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.password_hash IS '해시된 비밀번호';


--
-- Name: COLUMN users.name; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.name IS '사용자 이름';


--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.role IS '역할: admin(관리자), viewer(조회자)';


--
-- Name: COLUMN users.is_active; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.is_active IS '활성 상태 (비활성화 시 로그인 불가)';


--
-- Name: COLUMN users.created_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.created_at IS '생성 일시';


--
-- Name: COLUMN users.updated_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.updated_at IS '수정 일시';


--
-- Name: COLUMN users.last_login_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.users.last_login_at IS '마지막 로그인 일시';


--
-- Name: voucher_change_requests; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.voucher_change_requests (
    id uuid NOT NULL,
    voucher_id uuid NOT NULL,
    upload_job_id uuid,
    before_data jsonb,
    after_data jsonb,
    diff_summary jsonb,
    status public.change_request_status NOT NULL,
    reviewed_by uuid,
    review_memo text,
    created_at timestamp without time zone NOT NULL,
    reviewed_at timestamp without time zone
);


ALTER TABLE public.voucher_change_requests OWNER TO dwt_user;

--
-- Name: COLUMN voucher_change_requests.voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.voucher_id IS '변경 대상 전표 ID';


--
-- Name: COLUMN voucher_change_requests.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.upload_job_id IS '재업로드 Job ID';


--
-- Name: COLUMN voucher_change_requests.before_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.before_data IS '변경 전 데이터 스냅샷';


--
-- Name: COLUMN voucher_change_requests.after_data; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.after_data IS '변경 후 데이터 스냅샷';


--
-- Name: COLUMN voucher_change_requests.diff_summary; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.diff_summary IS '변경된 필드 요약 [{field, old, new}, ...]';


--
-- Name: COLUMN voucher_change_requests.status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.status IS '승인 상태: pending/approved/rejected';


--
-- Name: COLUMN voucher_change_requests.reviewed_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.reviewed_by IS '검토자 ID';


--
-- Name: COLUMN voucher_change_requests.review_memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.review_memo IS '검토 메모';


--
-- Name: COLUMN voucher_change_requests.reviewed_at; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.voucher_change_requests.reviewed_at IS '검토 일시';


--
-- Name: vouchers; Type: TABLE; Schema: public; Owner: dwt_user
--

CREATE TABLE public.vouchers (
    id uuid NOT NULL,
    trade_date date NOT NULL,
    counterparty_id uuid NOT NULL,
    voucher_number character varying(50) NOT NULL,
    voucher_type public.voucher_type NOT NULL,
    quantity integer NOT NULL,
    total_amount numeric(18,2) NOT NULL,
    purchase_cost numeric(18,2),
    actual_purchase_price numeric(18,2),
    deduction_amount numeric(18,2),
    avg_unit_price numeric(18,2),
    upm_settlement_status character varying(50),
    payment_info character varying(500),
    purchase_deduction numeric(18,2),
    as_cost numeric(18,2),
    sale_amount numeric(18,2),
    sale_deduction numeric(18,2),
    actual_sale_price numeric(18,2),
    profit numeric(18,2),
    profit_rate numeric(8,2),
    avg_margin numeric(18,2),
    is_adjustment boolean NOT NULL,
    adjustment_type public.adjustment_type,
    original_voucher_id uuid,
    adjustment_reason text,
    settlement_status public.settlement_status NOT NULL,
    payment_status public.payment_status NOT NULL,
    memo text,
    upload_job_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.vouchers OWNER TO dwt_user;

--
-- Name: COLUMN vouchers.trade_date; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.trade_date IS '매입일/판매일';


--
-- Name: COLUMN vouchers.counterparty_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.counterparty_id IS '매입처/판매처 → Counterparty';


--
-- Name: COLUMN vouchers.voucher_number; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.voucher_number IS 'UPM 전표 번호';


--
-- Name: COLUMN vouchers.voucher_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.voucher_type IS 'SALES(판매)/PURCHASE(매입)';


--
-- Name: COLUMN vouchers.quantity; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.quantity IS '수량';


--
-- Name: COLUMN vouchers.total_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.total_amount IS '정산 기준 금액 (매입:실매입가, 판매:실판매가)';


--
-- Name: COLUMN vouchers.purchase_cost; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.purchase_cost IS '매입원가';


--
-- Name: COLUMN vouchers.actual_purchase_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.actual_purchase_price IS '실매입가';


--
-- Name: COLUMN vouchers.deduction_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.deduction_amount IS '차감금액 (매입 전용)';


--
-- Name: COLUMN vouchers.avg_unit_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.avg_unit_price IS '평균가 (매입 전용)';


--
-- Name: COLUMN vouchers.upm_settlement_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.upm_settlement_status IS 'UPM 원본 정산현황 (검수대기/정산완료 등)';


--
-- Name: COLUMN vouchers.payment_info; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.payment_info IS '송금정보 (매입 전용)';


--
-- Name: COLUMN vouchers.purchase_deduction; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.purchase_deduction IS '매입차감 (판매 전용)';


--
-- Name: COLUMN vouchers.as_cost; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.as_cost IS 'A/S비용 (판매 전용)';


--
-- Name: COLUMN vouchers.sale_amount; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.sale_amount IS '판매금액 (판매 전용)';


--
-- Name: COLUMN vouchers.sale_deduction; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.sale_deduction IS '판매차감 (판매 전용)';


--
-- Name: COLUMN vouchers.actual_sale_price; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.actual_sale_price IS '실판매가 (판매 전용)';


--
-- Name: COLUMN vouchers.profit; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.profit IS '손익 (판매 전용)';


--
-- Name: COLUMN vouchers.profit_rate; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.profit_rate IS '수익율 % (판매 전용)';


--
-- Name: COLUMN vouchers.avg_margin; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.avg_margin IS '평균마진 (판매 전용)';


--
-- Name: COLUMN vouchers.is_adjustment; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.is_adjustment IS '조정 전표 여부';


--
-- Name: COLUMN vouchers.adjustment_type; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.adjustment_type IS '조정 유형: CORRECTION/RETURN/WRITE_OFF/DISCOUNT';


--
-- Name: COLUMN vouchers.original_voucher_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.original_voucher_id IS '원본 전표 ID (조정 전표일 경우)';


--
-- Name: COLUMN vouchers.adjustment_reason; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.adjustment_reason IS '조정 사유';


--
-- Name: COLUMN vouchers.settlement_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.settlement_status IS '시스템 정산 상태';


--
-- Name: COLUMN vouchers.payment_status; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.payment_status IS '시스템 지급 상태';


--
-- Name: COLUMN vouchers.memo; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.memo IS '비고';


--
-- Name: COLUMN vouchers.upload_job_id; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.upload_job_id IS '업로드 Job ID';


--
-- Name: COLUMN vouchers.created_by; Type: COMMENT; Schema: public; Owner: dwt_user
--

COMMENT ON COLUMN public.vouchers.created_by IS '생성자 ID';


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.audit_logs (id, trace_id, user_id, action, target_type, target_id, before_data, after_data, description, ip_address, user_agent, created_at) FROM stdin;
05cb8816-60a2-4f15-b5a2-54c4564f0c1e	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 04:53:15.630484
9e8b382e-51bb-4b35-872b-117bb85a4206	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:29:45.37493
b21e2f7e-68dd-4cf9-a34f-e2014682fd3a	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:21.751357
788089f0-c874-4c34-a49e-0dbc1c2f63aa	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:28.183065
261ec018-5f7a-478c-800b-47408b0ca0ba	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_LOGIN	user	0445d86e-f791-4dad-baec-5f91deb57adc	\N	\N	로그인 (아이디 저장: N)	172.18.0.1	curl/8.17.0	2026-03-03 05:30:35.694154
e0b79914-141b-4306-8c05-e7debe6be677	\N	0445d86e-f791-4dad-baec-5f91deb57adc	USER_CREATE	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	{"name": "skp10216", "role": "admin", "email": "skp10216@gmail.com"}	\N	\N	\N	2026-03-03 05:30:36.013231
2ce6ab25-91b8-4872-81c6-c05a0ace0ff8	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:31:45.550483
7d274d93-8d97-4ca0-82e7-84bfbe2491fe	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:31:52.695246
eaf6316a-3d03-417f-be46-9aa885918379	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:24.971431
518faef7-7fa1-4fb5-8e84-70cbbf9f98f3	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:30.33166
4b273608-758d-4655-9912-4c718dc4b392	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:31.504081
dad1fcfe-cb32-4a26-b4e9-0f684df3182f	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:32.288194
3130032a-7ac0-48f7-83bb-59c3e3ab31d5	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:44:33.662466
412e2f3d-497f-4476-bf1f-cc8b355e787b	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:49:37.960489
bec4d945-0e98-4fa4-9f00-9f4b4de4df54	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 05:49:50.293901
599f20c9-ffd6-4d20-8220-35c454b38dd0	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 06:57:51.848901
b84a2499-6939-4dab-af33-6710dd2e8fa1	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 07:25:22.786493
6e5edcfc-b8b5-495d-b15d-76d5a316f62d	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 07:27:23.218068
2dbcd040-b6c8-4586-8880-95a5dbc6d520	\N	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	USER_LOGIN	user	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 07:46:59.988838
d3e507eb-5490-40d9-ae73-6a3b925b04b6	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	USER_LOGIN	user	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Linux; Android 15; SM-S901N Build/AP3A.240905.015.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/145.0.7632.120 Mobile Safari/537.36 KAKAOTALK/26.1.3 (INAPP)	2026-03-03 07:29:36.539045
e3e9c3e3-6cea-4f07-891a-2dfe54fed0c3	\N	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	USER_LOGIN	user	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	\N	\N	로그인 (아이디 저장: Y)	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-03 08:38:01.609962
0aae7d46-e84a-4fd3-b801-2ea3c7b196b0	\N	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	UPLOAD_START	upload_job	\N	\N	{"filename": "판매자료(반입포함).xlsx", "job_type": "voucher_sales_excel", "file_hash": "8c53b14b2445e7fa2addb55b4b2fe980436c166f597bd1ef03850e65cc0bd8e5"}	\N	\N	\N	2026-03-03 08:38:42.291013
2c73014f-d3f6-463a-bc92-c0b09a41db87	\N	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	COUNTERPARTY_BATCH_CREATE	counterparty	\N	\N	{"count": 95, "names": ["오에스티이씨에이치(홍대)", "균호 사장님", "광주(sj컴퍼니)", "폰가비(업스테어스)", "윈윈사장님", "수리실(작업)", "앤디", "옥션(대단한)", "홍이(박걸)", "W무역", "옥션", "허랑(IBS)", "폰박스", "오사장님", "박팀장", "콕딜", "홍부희 사장님", "요크헤이븐 코리아", "문승현 (피지)", "지덕"]}	\N	\N	\N	2026-03-03 08:38:57.834499
f35cdb77-760d-4d68-bd73-e3b3a9102946	\N	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	UPLOAD_CONFIRM	upload_job	c43a4227-25e4-49ec-aca6-052a258bcd58	\N	{"created": 360, "updated": 0, "change_requests": 0}	\N	\N	\N	2026-03-03 08:39:06.069634
\.


--
-- Data for Name: bank_import_jobs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.bank_import_jobs (id, file_path, original_filename, file_hash, bank_name, account_number, import_date_from, import_date_to, status, total_lines, matched_lines, confirmed_lines, error_message, created_by, created_at, completed_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: bank_import_lines; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.bank_import_lines (id, import_job_id, line_number, transaction_date, description, amount, balance_after, counterparty_name_raw, counterparty_id, status, match_confidence, duplicate_key, bank_reference, transaction_id, raw_data, created_at) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.branches (id, name, region, contact_info, memo, is_active, deleted_at, deleted_by, delete_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compare_list_models; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.compare_list_models (id, model_id, sort_order, created_at, added_by) FROM stdin;
\.


--
-- Data for Name: counterparties; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparties (id, name, code, counterparty_type, branch_id, contact_info, memo, is_active, created_at, updated_at) FROM stdin;
516733e4-e694-44bf-8add-090a239834ff	오에스티이씨에이치(홍대)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.602283	2026-03-03 08:38:57.602286
5cf21947-99ef-4cbc-b01b-7604e3c45dfd	균호 사장님	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.605871	2026-03-03 08:38:57.605873
741050b9-3c8a-4fc2-8d95-2498204228d7	광주(sj컴퍼니)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.610033	2026-03-03 08:38:57.610035
2bb880f2-a435-484a-9726-577e1634b6ee	폰가비(업스테어스)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.61287	2026-03-03 08:38:57.612872
58f1b10f-5ca4-46fe-a406-1f0bc3533667	윈윈사장님	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.615629	2026-03-03 08:38:57.615631
13aa1618-e174-46a0-9a3f-13c99a848bb3	수리실(작업)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.618375	2026-03-03 08:38:57.618377
72ca8edd-d551-4ec1-b56e-119ec94f4650	앤디	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.620956	2026-03-03 08:38:57.620958
1d4c8aec-c05b-4369-b4ec-c6fd1984097b	옥션(대단한)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.623469	2026-03-03 08:38:57.623471
d20fc7c5-529f-41c9-904d-19c1eb0efaf8	홍이(박걸)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.626042	2026-03-03 08:38:57.626044
3b8448cc-7f5d-4453-9528-ee8ad014b113	W무역	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.628524	2026-03-03 08:38:57.628525
9f5d79c6-e380-4e90-b15c-f4ad55260d94	옥션	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.630892	2026-03-03 08:38:57.630894
a8a3d02a-0a75-4282-90a8-30cc5fe498e7	허랑(IBS)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.633421	2026-03-03 08:38:57.633422
7eae8065-8201-4a14-8523-f3c2ab734ce3	폰박스	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.635813	2026-03-03 08:38:57.635815
3894796d-c426-46cc-adb5-3628b464657b	오사장님	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.638279	2026-03-03 08:38:57.63828
0db921d6-4add-4b3d-ad21-58bbd17844e1	박팀장	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.640755	2026-03-03 08:38:57.640756
a77fa567-0758-4a03-a67d-f3b22c3f4045	콕딜	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.643118	2026-03-03 08:38:57.64312
d9e4d59a-726e-4178-af2f-7780a62c8ff3	홍부희 사장님	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.645681	2026-03-03 08:38:57.645684
7db3adcd-ecaf-40d9-9e09-13c6dc53cc14	요크헤이븐 코리아	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.648239	2026-03-03 08:38:57.648241
a17e9781-114b-40eb-802c-d840251348d9	문승현 (피지)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.650666	2026-03-03 08:38:57.650668
dfc10db2-0295-4794-afb6-77ff8fbfd8d3	지덕	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.653142	2026-03-03 08:38:57.653143
8668793e-2e5d-4fc5-a504-983dc694313a	어기(몽골)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.655646	2026-03-03 08:38:57.655647
18bf6904-6745-49dd-995c-c74ae1cca540	권영환(외부)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.658122	2026-03-03 08:38:57.658124
bf127d8e-e428-40ff-af91-d676a9d6a23f	T딜	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.660574	2026-03-03 08:38:57.660576
1567a26e-599b-47e7-bd3c-55e435ff8d2d	필리핀(연합)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.662951	2026-03-03 08:38:57.662953
519e85f6-0e7a-4b16-bb79-4f15674ef834	토스쇼핑	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.666108	2026-03-03 08:38:57.66611
18b33efc-6a66-4bb8-8c91-75559797c118	지마켓 (대단한)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.668555	2026-03-03 08:38:57.668556
adc46688-90df-4d93-a5d4-1a34ceeae403	STK-PK	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.670874	2026-03-03 08:38:57.670876
539627f6-0004-412c-a8bc-ebc7e9bacd50	소미트헌(우즈백)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.673309	2026-03-03 08:38:57.67331
964e5f21-bec6-4158-a95d-3e380a12eb6e	네오홀딩스(오주석)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.675595	2026-03-03 08:38:57.675596
a9a42747-977a-4c68-a2f1-f4f03a811346	호두모바일	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.677974	2026-03-03 08:38:57.677976
9ac5678b-105f-4912-b08e-75e30f29aec5	미니	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.68037	2026-03-03 08:38:57.680372
c4ed6d88-ecf0-497d-bcf3-ae9370e8057b	인스코리아	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.682654	2026-03-03 08:38:57.682655
67b38c33-88a8-4c33-afcd-fa18220875ce	볼트테크	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.68508	2026-03-03 08:38:57.685081
81f09a0a-1e29-4017-aace-be235f9b8c88	에코트레이드	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.687517	2026-03-03 08:38:57.687519
bcb23087-0819-43b2-97cf-f9f4c33d21a1	산하울라(압둘라동생)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.689895	2026-03-03 08:38:57.689897
7ce77cb3-c864-4896-95b0-b71b8bfd5bdb	에이블리4910	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.692252	2026-03-03 08:38:57.692254
fb8a00d5-c7ff-4553-bda5-d33f31772db8	베트남 지사	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.694638	2026-03-03 08:38:57.694639
fa3774ae-dc33-4aae-9f10-3fcfd2ff3ade	엔터프라이즈(평택)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.697025	2026-03-03 08:38:57.697027
c3a020ac-224d-4ba1-acf3-c2c824eb5807	카카오쇼핑	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.699303	2026-03-03 08:38:57.699304
0dfae848-f45b-4eb8-92e1-053f06cb46e6	이브로힘(우즈백)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.70161	2026-03-03 08:38:57.701611
64673b02-2736-4a52-aabf-efb0c5410f9d	지마켓(대단한)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.703914	2026-03-03 08:38:57.703916
295052f8-3c8d-44f4-8a9d-57dcb9777ab7	에코폰 상암점	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.706255	2026-03-03 08:38:57.706256
45c13653-c3f1-4453-ab7b-f581e7b444de	에스텔	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.708662	2026-03-03 08:38:57.708664
5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	아정당	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.710968	2026-03-03 08:38:57.71097
7e52bf92-fcfc-448f-8bee-9e8514c03bb4	뉴퍼마켓(대단한)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.713449	2026-03-03 08:38:57.713451
f08cafdc-365e-4c67-b64d-7c7360bc238c	누랄리(키르기스탄)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.715759	2026-03-03 08:38:57.71576
c7bf6d4a-3730-4143-9d6d-88eb950ba168	애플박사	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.718118	2026-03-03 08:38:57.71812
9c66af2a-0eaa-40d6-a87c-5a4fe001c857	ANCOM(홍콩)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.720464	2026-03-03 08:38:57.720466
226dc0c8-617a-45ff-bc27-18ae398fc5fa	다원 성준	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.72275	2026-03-03 08:38:57.722751
dc950987-84c6-4a80-be79-d7354cb8f9bb	네이버스토어	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.725162	2026-03-03 08:38:57.725164
d5867d9d-07e6-4b06-872c-73d84b25ccc8	STK.카림	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.727423	2026-03-03 08:38:57.727424
f8f444b1-069e-4fd0-befa-6068f3c1f2b6	쿠팡(대단한)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.729769	2026-03-03 08:38:57.729771
0cb5faff-5f33-416a-9294-0aaed356494c	아프리카 중고폰	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.732061	2026-03-03 08:38:57.732063
e2ccce5a-62ae-4221-bb15-4bffdf86bd8f	레이컴	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.734444	2026-03-03 08:38:57.734445
82c17c05-e4d9-4c83-9dea-da7b1d177363	김하나	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.736735	2026-03-03 08:38:57.736737
5b94afc0-22df-4331-aef7-f2d5d3f15733	아부바크르	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.738997	2026-03-03 08:38:57.738998
fe435be4-ea07-4b52-8732-15279d1f47ba	김조아(우즈백)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.741332	2026-03-03 08:38:57.741333
cc9aa04d-07c7-4bb6-bd09-ed3dfd452816	베트남 중(수원)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.743628	2026-03-03 08:38:57.74363
082cc299-bc65-42c6-b8b4-ceb4c0ac7430	떠리몰	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.745923	2026-03-03 08:38:57.745924
011820fe-3424-4969-8264-84751e578ad7	바이라(몽골)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.748251	2026-03-03 08:38:57.748261
6eb1110b-8ec8-487c-9a82-e2442663d029	김태연(베트남)	\N	BOTH	\N	\N	\N	t	2026-03-03 07:40:32.897629	2026-03-03 07:40:32.897633
23c41e48-2784-4cd8-a920-ab87165b72bb	중고나라	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.750545	2026-03-03 08:38:57.750547
4e0c76d8-9c9f-4d72-bf05-eb8e17a56e06	HSH	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.752846	2026-03-03 08:38:57.752848
30573aa1-2438-46ab-a8c1-f93ef4303a94	살람	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.755218	2026-03-03 08:38:57.755219
e5ba134e-9970-4b16-adbd-ae9e22f8e024	추가금(온라인)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.757533	2026-03-03 08:38:57.757534
04be26d8-3adf-4bfe-9573-320e109c9ef7	11번가(대단한)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.759809	2026-03-03 08:38:57.75981
75a6e0de-b3a1-43f9-be9b-1e86c64112bb	이사장님	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.762215	2026-03-03 08:38:57.762217
61b6ebe7-0bfc-4e26-9aab-683c23d69a9d	베트남 홍손	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.764711	2026-03-03 08:38:57.764713
18b5ef55-910e-4504-b3bd-b6c96a2eb298	쿠팡(리플립)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.767033	2026-03-03 08:38:57.767035
5d46a0d1-11ac-4931-9582-e07495cb0eca	솝다(몽골)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.769444	2026-03-03 08:38:57.769445
0be3ba2e-83f7-4588-abde-25ceae9e6ee3	마블	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.771741	2026-03-03 08:38:57.771743
4be7a678-c8ea-49c8-aa70-bd60f0c317cb	아심(두바이)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.774165	2026-03-03 08:38:57.774167
87a77c6d-5d37-4392-9e20-409c2cc3b854	뉴퍼마켓(다원)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.776519	2026-03-03 08:38:57.776521
322b6247-12d9-4cdd-a655-555744148372	폰테이너	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.779579	2026-03-03 08:38:57.77958
abd00751-2371-4fe7-9d14-bf7e58cb6316	임태종(스든코퍼레이션)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.781922	2026-03-03 08:38:57.781924
9ceeda3a-520b-401c-bd0f-61f0bb6840f7	박걸	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.78435	2026-03-03 08:38:57.784352
5b7a1424-4208-45db-b515-36bf310b8d42	지마켓	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.786687	2026-03-03 08:38:57.786688
aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	오재	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.789336	2026-03-03 08:38:57.789338
d8752df9-aa5e-4e7b-a717-df2d2a95686f	리씽크	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.791646	2026-03-03 08:38:57.791647
82f57867-459c-40b8-845a-4d71229218a4	올웨이즈(다원)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.794041	2026-03-03 08:38:57.794043
47b01d71-a5e0-469c-8d48-835fe2a323b9	쿠팡(엘씨오씨)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.798396	2026-03-03 08:38:57.798398
58a69881-1175-411a-b9c3-a73984aa504e	마삽	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.800708	2026-03-03 08:38:57.80071
a4a4a6fc-6f9a-4f5f-9382-88ea5e0102d6	스마트M	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.802976	2026-03-03 08:38:57.802978
184b1cb6-5cf6-40c7-8e65-dc384e2da567	쿠팡	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.805385	2026-03-03 08:38:57.805386
e86090a3-7209-43b8-a149-c1acf99ed91f	11번가	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.807632	2026-03-03 08:38:57.807633
00dae90e-a6a3-4569-8a64-92c70bf34a4d	아이즈모바일	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.809994	2026-03-03 08:38:57.809996
923f7434-4e13-44f7-bc87-ed5c7a7dbf12	엔터프라이즈(당진)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.812389	2026-03-03 08:38:57.81239
0f07d7f9-a1d2-41a5-89cb-0e942fd7ed22	광주 팔구사구	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.81472	2026-03-03 08:38:57.814722
f30b1e3b-e380-49de-b846-9ce726b2bcca	다원	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.817013	2026-03-03 08:38:57.817015
6382e215-2506-4ff9-a0bd-babe31776f49	아이온코리아	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.819254	2026-03-03 08:38:57.819255
546b9fe5-ed44-47ab-ad21-2050f33efc23	네이버스토어(대단한)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.821556	2026-03-03 08:38:57.821557
b9132696-b6b9-4d5a-a959-659676233f24	아초	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.823944	2026-03-03 08:38:57.823945
772eee3f-b282-43a0-bede-1047ad139fcf	KREAM(금화)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.826324	2026-03-03 08:38:57.826326
5ac88854-845a-471c-a1d3-82673bb52489	자이드(미얀마)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.82864	2026-03-03 08:38:57.828641
196e3761-a30c-4af1-b443-33670b8c971c	리퍼마켓(B2B)	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.830923	2026-03-03 08:38:57.830925
8b759141-95bc-427b-a95c-75985ea71cf9	정엽 사장님	\N	BOTH	\N	\N	\N	t	2026-03-03 08:38:57.833332	2026-03-03 08:38:57.833333
\.


--
-- Data for Name: counterparty_aliases; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparty_aliases (id, counterparty_id, alias_name, created_by, created_at) FROM stdin;
d2c4f199-ad21-4f54-8fb3-857988e28174	516733e4-e694-44bf-8add-090a239834ff	오에스티이씨에이치(홍대)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.606865
59767b83-98e8-4d04-8bf9-a1545f52cfac	5cf21947-99ef-4cbc-b01b-7604e3c45dfd	균호 사장님	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.610516
44e1a620-d475-42ef-9d04-fb7a37f90dfe	741050b9-3c8a-4fc2-8d95-2498204228d7	광주(sj컴퍼니)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.613401
11674792-7c92-414f-9b8a-9cc3dad93f9f	2bb880f2-a435-484a-9726-577e1634b6ee	폰가비(업스테어스)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.616087
46bcce43-d695-42e8-a2e0-449bbbf8d4df	58f1b10f-5ca4-46fe-a406-1f0bc3533667	윈윈사장님	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.618826
698a49ac-5f58-472e-ad03-f79747a39a1a	13aa1618-e174-46a0-9a3f-13c99a848bb3	수리실(작업)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.621368
ff6614d4-345f-4a87-b394-b5fa7583ef4a	72ca8edd-d551-4ec1-b56e-119ec94f4650	앤디	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.623926
dc8a0490-0f06-4dff-8a60-296a9dc97830	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	옥션(대단한)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.626468
82d0f550-0a5f-42ca-ba84-a0f17979306f	d20fc7c5-529f-41c9-904d-19c1eb0efaf8	홍이(박걸)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.628939
4693fb66-6d03-404b-928a-e8f8233f42ac	3b8448cc-7f5d-4453-9528-ee8ad014b113	W무역	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.631305
7d1f1cac-f50e-4b7e-b6d8-c7778047d6ac	9f5d79c6-e380-4e90-b15c-f4ad55260d94	옥션	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.633833
095cd248-2dd9-4901-9c3b-8223550fce3f	a8a3d02a-0a75-4282-90a8-30cc5fe498e7	허랑(IBS)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.63629
90077896-4145-4430-8b6f-bf52d46a92b6	7eae8065-8201-4a14-8523-f3c2ab734ce3	폰박스	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.638698
709098be-178f-40c0-9be3-02e01210ea57	3894796d-c426-46cc-adb5-3628b464657b	오사장님	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.641167
5f5aaec2-fa7c-48dc-b68c-a7e500b0df1b	0db921d6-4add-4b3d-ad21-58bbd17844e1	박팀장	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.643634
f6397fae-a713-4eb5-96f7-4782c392a28c	a77fa567-0758-4a03-a67d-f3b22c3f4045	콕딜	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.646107
085b9600-f67f-4e42-9a54-be886af06e12	d9e4d59a-726e-4178-af2f-7780a62c8ff3	홍부희 사장님	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.648681
d392dfa0-59d4-4ae6-90b4-7ba2827f80b9	7db3adcd-ecaf-40d9-9e09-13c6dc53cc14	요크헤이븐 코리아	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.651083
570f4c85-3a55-47ca-aacf-0f4f8667af86	a17e9781-114b-40eb-802c-d840251348d9	문승현 (피지)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.653616
eff49323-9b9c-4a21-9a49-2974b3685912	dfc10db2-0295-4794-afb6-77ff8fbfd8d3	지덕	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.656066
c7ed55e8-b0f6-46ff-905e-5f057a736bff	8668793e-2e5d-4fc5-a504-983dc694313a	어기(몽골)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.658534
495faf80-5388-46bc-84ed-4c5e6be7f87a	18bf6904-6745-49dd-995c-c74ae1cca540	권영환(외부)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.66099
788c4b69-4976-4644-857a-026faee64b58	bf127d8e-e428-40ff-af91-d676a9d6a23f	T딜	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.664071
b4376cb2-251a-4f7c-a600-2419cfba25e5	1567a26e-599b-47e7-bd3c-55e435ff8d2d	필리핀(연합)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.666514
adbe2218-0914-4870-abe9-d031812b982c	519e85f6-0e7a-4b16-bb79-4f15674ef834	토스쇼핑	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.668966
0e0010d8-2bb8-496d-a7eb-d671b0fb39d2	18b33efc-6a66-4bb8-8c91-75559797c118	지마켓 (대단한)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.671275
0b1341c5-4697-408c-bdb4-ec3a6cb0440e	adc46688-90df-4d93-a5d4-1a34ceeae403	STK-PK	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.67371
bb7b9b58-a1c9-45bf-a0db-c5762dd4eff2	539627f6-0004-412c-a8bc-ebc7e9bacd50	소미트헌(우즈백)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.675993
30176809-6ca4-4541-81b5-e2db13567f84	964e5f21-bec6-4158-a95d-3e380a12eb6e	네오홀딩스(오주석)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.678406
ccefb2cb-43c1-4f1a-93fe-b2c32d5e6530	a9a42747-977a-4c68-a2f1-f4f03a811346	호두모바일	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.680786
bb4bc766-2384-4b84-b295-87fcf5878823	9ac5678b-105f-4912-b08e-75e30f29aec5	미니	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.683049
9cd1b573-da04-4ae9-9ac0-38962c2bb8f0	c4ed6d88-ecf0-497d-bcf3-ae9370e8057b	인스코리아	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.685481
e60e3d3e-d5a2-4d77-9bb6-4fde529cc156	67b38c33-88a8-4c33-afcd-fa18220875ce	볼트테크	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.687955
87abf7e1-bf01-4f9e-8f5c-83d640c95f45	81f09a0a-1e29-4017-aace-be235f9b8c88	에코트레이드	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.690297
49077f40-8a43-4be1-b039-eb94f63320b8	bcb23087-0819-43b2-97cf-f9f4c33d21a1	산하울라(압둘라동생)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.692669
bdd414e2-cdb2-4e45-91b3-5f2b98425a5e	7ce77cb3-c864-4896-95b0-b71b8bfd5bdb	에이블리4910	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.695041
0b5f3adf-4bd9-4c25-9bd9-a4d20a12ee53	fb8a00d5-c7ff-4553-bda5-d33f31772db8	베트남 지사	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.697424
348dec37-b885-4cd3-973e-a612e2cf8257	fa3774ae-dc33-4aae-9f10-3fcfd2ff3ade	엔터프라이즈(평택)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.6997
b2e9d9ca-47d7-418c-8dca-0d4206a16712	c3a020ac-224d-4ba1-acf3-c2c824eb5807	카카오쇼핑	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.702003
fa93cb2f-b656-48f1-8f3d-99b7d52b5fe8	0dfae848-f45b-4eb8-92e1-053f06cb46e6	이브로힘(우즈백)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.704389
a5c4588e-3e26-4c9c-89a1-64bbb0575666	64673b02-2736-4a52-aabf-efb0c5410f9d	지마켓(대단한)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.706665
0a8a3b0f-e2f1-4e33-b76f-c64abd492c76	295052f8-3c8d-44f4-8a9d-57dcb9777ab7	에코폰 상암점	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.709073
56895a4a-0b09-4320-8143-6bd229b172bc	45c13653-c3f1-4453-ab7b-f581e7b444de	에스텔	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.71137
001730e4-5521-4664-a171-5484c21c0127	5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	아정당	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.713852
92256060-f7f8-43e9-b8ef-6b5cc4eb629d	7e52bf92-fcfc-448f-8bee-9e8514c03bb4	뉴퍼마켓(대단한)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.716219
4822b4c8-0f22-4ccb-82d6-345b537ccd72	f08cafdc-365e-4c67-b64d-7c7360bc238c	누랄리(키르기스탄)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.718516
dc42d28e-7ffc-44b4-b026-4573ca6412e9	c7bf6d4a-3730-4143-9d6d-88eb950ba168	애플박사	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.720875
995d9b68-d7f1-4b42-8d01-0d9f916dd094	9c66af2a-0eaa-40d6-a87c-5a4fe001c857	ANCOM(홍콩)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.723145
f956a22a-4fd5-4951-8b9a-4af3dfb0c953	226dc0c8-617a-45ff-bc27-18ae398fc5fa	다원 성준	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.725559
edce5db8-603b-4520-9afa-ebf72e4fa97f	dc950987-84c6-4a80-be79-d7354cb8f9bb	네이버스토어	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.727818
26340187-e2d5-43a0-bd96-6d36662cfae6	d5867d9d-07e6-4b06-872c-73d84b25ccc8	STK.카림	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.730164
a6ea9c00-585c-4ca2-bbf8-cbf3fd8f6e33	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	쿠팡(대단한)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.732525
6591b072-a5a3-4353-a0bd-26ca98ae4237	0cb5faff-5f33-416a-9294-0aaed356494c	아프리카 중고폰	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.734852
b5d7b49b-bcf2-4ad8-8580-b0a95a7561a0	e2ccce5a-62ae-4221-bb15-4bffdf86bd8f	레이컴	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.737132
cbba44d8-cd05-473c-b904-d7aa4980ca7e	82c17c05-e4d9-4c83-9dea-da7b1d177363	김하나	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.739389
c863ec54-0bea-4291-9294-8f8a9a31a295	5b94afc0-22df-4331-aef7-f2d5d3f15733	아부바크르	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.741726
6aca4012-bc4f-46f2-9a17-1ad012438ec8	fe435be4-ea07-4b52-8732-15279d1f47ba	김조아(우즈백)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.74402
162b8937-e227-4682-afbd-cec59c8e0080	cc9aa04d-07c7-4bb6-bd09-ed3dfd452816	베트남 중(수원)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.746321
e49fbc2f-216d-4cea-8d48-22dc207b4328	082cc299-bc65-42c6-b8b4-ceb4c0ac7430	떠리몰	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.748686
d8973f31-a67c-414d-8e2c-40b771ef65f0	011820fe-3424-4969-8264-84751e578ad7	바이라(몽골)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.75094
36451bb5-112f-4c14-b747-b02a960f2007	6eb1110b-8ec8-487c-9a82-e2442663d029	김태연(베트남)	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:40:32.901558
4bd76fdd-9901-4367-8fcb-9689c194f206	23c41e48-2784-4cd8-a920-ab87165b72bb	중고나라	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.753296
f06d9986-7b0b-4651-8780-cb5e63984f68	4e0c76d8-9c9f-4d72-bf05-eb8e17a56e06	HSH	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.755612
1a9f5741-740c-4fce-bbd7-087e81ffe213	30573aa1-2438-46ab-a8c1-f93ef4303a94	살람	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.757933
50c5842e-3915-4baa-9405-5001ea9bd99a	e5ba134e-9970-4b16-adbd-ae9e22f8e024	추가금(온라인)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.760256
b1913611-f2c4-45ef-99da-21dacec9e228	04be26d8-3adf-4bfe-9573-320e109c9ef7	11번가(대단한)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.762613
5bb94ded-f903-44df-8924-33598e4a3c39	75a6e0de-b3a1-43f9-be9b-1e86c64112bb	이사장님	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.765121
ee15291c-27c9-4511-9f9d-ca817f8090fe	61b6ebe7-0bfc-4e26-9aab-683c23d69a9d	베트남 홍손	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.767436
cff094d8-1f8f-48f3-b7f6-434dc13892ce	18b5ef55-910e-4504-b3bd-b6c96a2eb298	쿠팡(리플립)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.769849
3a8a6b99-8897-44cc-b4d4-110faead338f	5d46a0d1-11ac-4931-9582-e07495cb0eca	솝다(몽골)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.772217
1ffc60c8-9798-4240-a2af-3121297dcffc	0be3ba2e-83f7-4588-abde-25ceae9e6ee3	마블	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.774569
d30833e2-b373-4ca0-819f-3cb7ba555f15	4be7a678-c8ea-49c8-aa70-bd60f0c317cb	아심(두바이)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.776923
69705483-ae00-426b-a559-2f54f8153e43	87a77c6d-5d37-4392-9e20-409c2cc3b854	뉴퍼마켓(다원)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.779988
c315008e-84f4-4f7a-9b85-ae6bc577fe10	322b6247-12d9-4cdd-a655-555744148372	폰테이너	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.782326
bca3b362-2f56-4926-94f3-6bf4d596218d	abd00751-2371-4fe7-9d14-bf7e58cb6316	임태종(스든코퍼레이션)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.784757
a2d379cd-9e44-4570-bc68-a42534f295e0	9ceeda3a-520b-401c-bd0f-61f0bb6840f7	박걸	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.787094
1fc4165c-12a0-41ef-aa8d-fc7f0d2be134	5b7a1424-4208-45db-b515-36bf310b8d42	지마켓	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.789743
79e17774-1737-49d7-a585-8af39b0b434d	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	오재	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.792044
08975f62-dc0d-4654-89d5-5431e550a6ec	d8752df9-aa5e-4e7b-a717-df2d2a95686f	리씽크	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.794441
490ce2cb-ce17-47df-92f8-7533e80355fb	82f57867-459c-40b8-845a-4d71229218a4	올웨이즈(다원)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.798812
02821c92-a208-4516-9529-81714f922bd8	47b01d71-a5e0-469c-8d48-835fe2a323b9	쿠팡(엘씨오씨)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.801103
28021400-91ee-4441-bf26-f3cb5f7c2e41	58a69881-1175-411a-b9c3-a73984aa504e	마삽	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.80346
28961f62-65e8-45f0-9a03-824039d3f564	a4a4a6fc-6f9a-4f5f-9382-88ea5e0102d6	스마트M	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.80578
c7a2b62d-e605-4ba0-908c-b14d7ace8371	184b1cb6-5cf6-40c7-8e65-dc384e2da567	쿠팡	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.808026
38a5136f-f895-40b9-a16c-009cae154c86	e86090a3-7209-43b8-a149-c1acf99ed91f	11번가	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.810459
c984b088-c454-4c8e-a0e5-e36082a8aa31	00dae90e-a6a3-4569-8a64-92c70bf34a4d	아이즈모바일	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.812787
cf01af11-47e0-4a88-8df4-f9c6164ad6c3	923f7434-4e13-44f7-bc87-ed5c7a7dbf12	엔터프라이즈(당진)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.815114
1b13a69f-1013-4d5b-92dc-48f229312bac	0f07d7f9-a1d2-41a5-89cb-0e942fd7ed22	광주 팔구사구	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.817408
f7471aa2-dc06-4b3c-b6da-6e3ebebc2da7	f30b1e3b-e380-49de-b846-9ce726b2bcca	다원	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.81966
670dd8ea-6806-43a1-8847-17296f163292	6382e215-2506-4ff9-a0bd-babe31776f49	아이온코리아	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.821953
ff9d5a48-908a-4a28-a0b9-9fb9a6430ef6	546b9fe5-ed44-47ab-ad21-2050f33efc23	네이버스토어(대단한)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.82443
053fb561-20f3-4071-b56f-01ffcf62b668	b9132696-b6b9-4d5a-a959-659676233f24	아초	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.826719
ceeeed14-233a-470b-9b96-5a88d216f7f6	772eee3f-b282-43a0-bede-1047ad139fcf	KREAM(금화)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.829049
76c37799-40a1-475f-9282-1461fa44e5c9	5ac88854-845a-471c-a1d3-82673bb52489	자이드(미얀마)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.831316
90e2d4eb-14f2-418c-8f27-e0490243c723	196e3761-a30c-4af1-b443-33670b8c971c	리퍼마켓(B2B)	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.833729
55dc6b03-a0d9-496e-a1b9-89433714a2f8	8b759141-95bc-427b-a95c-75985ea71cf9	정엽 사장님	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:38:57.842997
\.


--
-- Data for Name: counterparty_transactions; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.counterparty_transactions (id, counterparty_id, transaction_type, transaction_date, amount, allocated_amount, memo, source, bank_reference, bank_import_line_id, netting_record_id, status, created_by, created_at, updated_at) FROM stdin;
447106c6-516d-487b-8104-8613963b057b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-17	14450000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402527	2026-03-03 08:47:56.40253
e73ef390-4ba9-4bf7-b080-28f140421f6f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-17	14450000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402535	2026-03-03 08:47:56.402535
3d3b9b9e-cb1b-4161-a325-ad63549d30b8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	34820000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402539	2026-03-03 08:47:56.402539
0598c870-b132-4a05-b0fa-235b9e485fec	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	4260000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402542	2026-03-03 08:47:56.402542
2374d469-e05c-46d9-a27b-3e8b2aa92563	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-20	34820000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402546	2026-03-03 08:47:56.402546
69a301d1-0057-4294-98d0-2c1fc1331192	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-20	9760000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402549	2026-03-03 08:47:56.402549
b591ab8b-d259-4942-9886-9a4eaf488676	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	600000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402553	2026-03-03 08:47:56.402553
6047a68e-d881-4774-a269-aac3c778566b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	5500000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402556	2026-03-03 08:47:56.402556
76dea8e9-ef20-460e-b6dd-59fb88e883c4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	15000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40256	2026-03-03 08:47:56.40256
9a5d0aad-cdf1-4b6f-812e-331ca3c97720	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	22810000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402563	2026-03-03 08:47:56.402563
25efa271-0b69-4b44-a927-dbc5feddab5a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	9870000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402566	2026-03-03 08:47:56.402567
6b8484cc-b10d-4062-8796-5b09709855af	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	10230000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40257	2026-03-03 08:47:56.40257
8329ff4f-4e50-4135-972b-90f797271c3f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	990000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402573	2026-03-03 08:47:56.402573
cb2fc343-7638-4324-a4b2-6f57b0665d71	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	30310000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402576	2026-03-03 08:47:56.402577
d5f1a8de-6e40-4120-be71-757d033aa165	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-22	24660000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402579	2026-03-03 08:47:56.40258
37a383c8-f5f2-440f-9835-eccbd8564392	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	18040000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402583	2026-03-03 08:47:56.402583
057f21f3-48eb-4ef4-8f85-09155f650a14	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	310000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402586	2026-03-03 08:47:56.402586
21c80a35-7724-49ac-a822-5b4b695d6d08	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-23	5320000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402589	2026-03-03 08:47:56.40259
32a63ff7-6aaa-4149-84f7-1bec1570998e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-23	47010000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402592	2026-03-03 08:47:56.402593
022fb008-ab02-467b-bb53-d0c23d6c5aca	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-23	24990000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402596	2026-03-03 08:47:56.402596
c2c290c7-5420-4848-9990-2b6baf2afaa3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-23	2870000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402599	2026-03-03 08:47:56.402599
ebb98fbc-7f00-4a01-85ba-eca2bc521c0d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	47010000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402602	2026-03-03 08:47:56.402602
34d2cb09-2f31-4810-9416-a07140c4368e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	19120000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402605	2026-03-03 08:47:56.402606
854362bb-c369-4a1d-93a7-85ff1081fa81	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	50000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402609	2026-03-03 08:47:56.402609
58042661-c104-476b-8644-30bf076b14ef	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	8080000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402612	2026-03-03 08:47:56.402612
e5138d9c-770a-46b6-9a92-447f6b804641	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	6970000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402615	2026-03-03 08:47:56.402615
11f81b7d-7929-4fd8-94ac-ad383470b0bf	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	25270000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402618	2026-03-03 08:47:56.402619
4978436c-8fa4-40a6-a947-0986b252541a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	24060000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402621	2026-03-03 08:47:56.402622
c891e983-5e70-4b83-8e02-88fab9421628	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	10190000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402625	2026-03-03 08:47:56.402625
2ba01cc6-38db-4092-a810-acc892d4ee63	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	5080000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402628	2026-03-03 08:47:56.402628
ec850b2a-82c2-4d9a-bf84-46755f56513a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	10950000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402631	2026-03-03 08:47:56.402631
b83e1fb0-1162-46fc-8356-a472ae8b326f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	10190000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402634	2026-03-03 08:47:56.402635
51110086-31ce-40e8-af14-88afc3de0164	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-27	2035000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402638	2026-03-03 08:47:56.402638
3e850f42-8e4f-4003-a279-dcb82978c173	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-27	6030000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402641	2026-03-03 08:47:56.402641
590f3935-d72f-4686-9db4-7f5823d38f24	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-28	10150000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402644	2026-03-03 08:47:56.402644
900a06f6-84b1-46bb-8963-c74085bf04fe	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	6155000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402647	2026-03-03 08:47:56.402648
281dd195-33c5-40d5-9883-d7ab839cb45f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	10000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402651	2026-03-03 08:47:56.402652
e5be53c3-e525-4a7b-93ec-44d89f5f7b28	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	6925000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402655	2026-03-03 08:47:56.402655
8904c709-33ac-4c7d-899a-4985208a08f2	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-29	17945000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402658	2026-03-03 08:47:56.402658
fcf02d70-36ea-4c57-a7f2-e594f36490ff	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-29	4950000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402662	2026-03-03 08:47:56.402662
2ed31960-558e-42ab-8c08-d3024febf0bc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	920000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402665	2026-03-03 08:47:56.402665
c1cc4e02-0bd9-44a6-a8c0-580a2370e99d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	4950000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402669	2026-03-03 08:47:56.402669
a5a2ce54-dd73-4adf-8783-cb523dfcb9b4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	6560000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402672	2026-03-03 08:47:56.402673
b857720b-d582-4a38-b369-cdb69da21265	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	1120000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402676	2026-03-03 08:47:56.402676
f1522ab5-4635-45a9-854d-c8c2b8b70120	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	10000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402679	2026-03-03 08:47:56.402679
afb1c0c6-aba8-4cab-9389-002401b8afb7	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-30	11420000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402682	2026-03-03 08:47:56.402682
e9f2597e-1bce-4a26-8fbf-d7fe49498a9c	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	3740000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402685	2026-03-03 08:47:56.402686
c3cd8d23-f751-476f-a9e2-97661a1bdeeb	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	12420000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402689	2026-03-03 08:47:56.402689
ce537bfd-df7e-4384-a4fc-b2d34ba7ba0c	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	15000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402692	2026-03-03 08:47:56.402692
29c9b924-fec2-4792-9d87-b1692c3a82a5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-03	16025000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402695	2026-03-03 08:47:56.402695
a4fbb73c-cdb5-483b-a3b4-2321eae5c8ed	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-03	7720000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402698	2026-03-03 08:47:56.402699
d8aecdc7-1763-4c45-931f-7ef89f4d2285	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	1325000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402702	2026-03-03 08:47:56.402702
27c55e71-be35-438d-a84a-a3a834692039	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	8500000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402705	2026-03-03 08:47:56.402705
593e39dd-7517-4c79-86af-1086dffa35a9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	1500000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402708	2026-03-03 08:47:56.402709
5d50767b-5d0e-442d-bf55-4b8e4486ec94	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-04	11650000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402712	2026-03-03 08:47:56.402712
b1138900-3884-4342-a8c3-27a32116fee1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-04	17540000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402715	2026-03-03 08:47:56.402715
b7634fbe-9281-49db-84fb-4970691aac75	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	600000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402718	2026-03-03 08:47:56.402719
a2d9ae52-9b9e-455e-aa11-22375b686f61	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	2000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402722	2026-03-03 08:47:56.402722
7d30236f-1c05-49f6-a19b-3ce9bb35531b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	1120000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402725	2026-03-03 08:47:56.402725
314ee2f6-ff00-410a-9e5a-e7f294ff16ff	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	18000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402728	2026-03-03 08:47:56.402729
38b9e882-3330-423f-9dd2-40a52d2fa8ce	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402731	2026-03-03 08:47:56.402732
ffe02cd9-b65e-40ca-8dad-7505d7105bc7	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	7655000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402735	2026-03-03 08:47:56.402735
0fd807aa-985f-4185-892a-a9f841891a05	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	5150000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402738	2026-03-03 08:47:56.402738
57f29a16-b197-4638-9540-9398ad522c6e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	5660000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402741	2026-03-03 08:47:56.402741
42d19b95-5e71-4dc9-b686-ee0bc3565a0d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	15000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402744	2026-03-03 08:47:56.402745
6ded8b72-197e-44de-bbb8-2e8b706865fa	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	3450000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402747	2026-03-03 08:47:56.402748
da7727e2-beec-4795-9ef9-4054a16c391a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-06	20440000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402751	2026-03-03 08:47:56.402751
eda51a87-ffcc-44cf-87bf-4910b39c8ac8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-06	3320000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402754	2026-03-03 08:47:56.402754
92a377c6-0725-4a94-8d2f-568c565332d0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	2150000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402757	2026-03-03 08:47:56.402757
b0a7d1aa-6ea2-473a-8dbc-9406e2a95b70	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-07	24290000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40276	2026-03-03 08:47:56.402761
c4728ee7-e308-4230-9ce2-7ba30ef7d5a6	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-07	4705000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402763	2026-03-03 08:47:56.402764
c7f800f9-8b8f-4519-9b9d-76d9bd0ac835	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-07	9720000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402767	2026-03-03 08:47:56.402767
1f9c5f14-ac18-4c72-9216-022820cc4d55	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-07	1820000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40277	2026-03-03 08:47:56.40277
151cf313-9251-4f13-8f51-1980c5780fde	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	1020000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402773	2026-03-03 08:47:56.402773
579569e1-55e9-486d-bf1c-91ceee307a79	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-10	22110000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402776	2026-03-03 08:47:56.402777
db657280-6fdb-47a0-9eaa-08d7e9e12ab2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	19050000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40278	2026-03-03 08:47:56.40278
2bca329a-64b6-44de-b101-b5a569dc89a8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	21085000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402783	2026-03-03 08:47:56.402783
8750aded-edd8-4c81-b79e-51b1031c0ba9	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-11	6470000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402786	2026-03-03 08:47:56.402786
5756f9b9-5fdd-484f-a981-31ac300671aa	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-11	4000000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402789	2026-03-03 08:47:56.402789
7564bd5d-1a05-4f61-bf2b-38a4a677d7da	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-12	5835000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402792	2026-03-03 08:47:56.402793
cc414cdd-d8e6-4164-ad80-8b00cde8c3c1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-12	28925000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402795	2026-03-03 08:47:56.402796
b9851116-17ba-49d9-be49-0e021a9f1f16	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-13	18180000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402799	2026-03-03 08:47:56.402799
e4c8ccdf-f206-40ea-956e-fa5c75779f75	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-13	13505000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402802	2026-03-03 08:47:56.402803
004cb097-6f4a-45a5-97bc-369b95201bfd	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-13	1600000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402806	2026-03-03 08:47:56.402806
2bf6b566-30a4-43f3-969f-be0a270eb193	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-14	22910000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402809	2026-03-03 08:47:56.40281
afeb1c50-8677-454e-a0ef-c456193cb557	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-14	6485000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402812	2026-03-03 08:47:56.402813
d7e8cb6c-1235-4e2c-9d63-b79b108d996a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-14	32650000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402816	2026-03-03 08:47:56.402816
5370d7fa-7539-45f8-8db8-71c378daaaf0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-14	2275000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402819	2026-03-03 08:47:56.402819
eb9266e0-e146-4cd6-83d2-88359be04bf4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	26900000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402822	2026-03-03 08:47:56.402822
4bb734c8-6f98-45ea-962a-052e12a926ed	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	2610000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402825	2026-03-03 08:47:56.402826
7c5e7513-7b10-4409-a266-88dc0d82697a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-17	8390000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402828	2026-03-03 08:47:56.402829
6f6e3318-7f1c-4117-95d5-fac749698008	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	4840000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402832	2026-03-03 08:47:56.402832
047171af-379b-420b-aaa2-5bd33759310d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-18	7880000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402835	2026-03-03 08:47:56.402835
e532c22e-247a-4c28-8106-c266f4658239	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-18	7015000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402838	2026-03-03 08:47:56.402838
f45f8121-1ff5-4095-ba18-1b297200a515	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-18	260000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402841	2026-03-03 08:47:56.402841
0c326a24-6137-49c2-86d1-8aaba7188a46	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-19	14535000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402844	2026-03-03 08:47:56.402845
6a94abee-efe2-4247-acac-d8af80ceca72	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-20	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402847	2026-03-03 08:47:56.402848
e50eb4d7-8d14-49c6-b03b-5f42d67945cf	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	1040000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402851	2026-03-03 08:47:56.402851
faeab46d-0460-40f6-8a43-40b41cf5707a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	10000000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402854	2026-03-03 08:47:56.402854
e9bad622-64b4-45bb-83b9-582af09d0aba	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	6885000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402857	2026-03-03 08:47:56.402857
20fb7ad4-3de6-47b9-89e4-a753339f0189	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-20	2520000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40286	2026-03-03 08:47:56.40286
b7af3549-bee2-4798-ac70-dd02c8abee86	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-21	2850000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402863	2026-03-03 08:47:56.402864
752e2e1e-2313-4d9d-8c71-d3fb0d28e1f2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-24	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402867	2026-03-03 08:47:56.402867
ab96aa4f-f3b2-4c61-94b3-889a59588603	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-24	7025000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40287	2026-03-03 08:47:56.40287
e631e071-30a9-4298-a6b2-fdb3df6e97b1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-24	4180000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402873	2026-03-03 08:47:56.402873
a9117f9e-df77-490c-8c32-b1028080bc3f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-26	16840000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402876	2026-03-03 08:47:56.402877
1e409298-7ec1-4a20-9788-65210f203558	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-26	24185000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402879	2026-03-03 08:47:56.40288
844ed2b4-b9a8-4872-b448-41ad2165633a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-26	2750000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402883	2026-03-03 08:47:56.402883
d223e97d-6ada-4121-91ca-5f07e9302366	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	9990000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402886	2026-03-03 08:47:56.402886
b58a3cd7-169d-4b39-b104-e51ca6df6883	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	17310000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402889	2026-03-03 08:47:56.40289
eaa6d75c-9992-4c96-9f61-23c03d69547c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	7900000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402892	2026-03-03 08:47:56.402893
abb48a23-577e-48c9-b801-3e1c076ac1cf	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-27	2960000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402896	2026-03-03 08:47:56.402896
5176dd25-977f-49dd-a743-ffb8bd342326	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	12000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402899	2026-03-03 08:47:56.402899
afd4f112-0770-4e54-8001-cbf78e8b955c	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	24000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402902	2026-03-03 08:47:56.402902
60cf44a9-3f9e-426a-877c-6e2f70d2b4d8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	16000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402905	2026-03-03 08:47:56.402906
9e946d1f-d7fa-4ecd-b0b1-0b39d8533359	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-06	20440000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414198	2026-03-03 07:44:55.532009
1ebdabce-0262-4282-9a9a-50c99a619410	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	3450000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414195	2026-03-03 07:44:55.535167
3eb8ed9e-e79c-4e27-9361-56262f2d3c8a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	15000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414192	2026-03-03 07:44:55.537914
80093305-77e3-4d92-8fdc-ef81e29e19a3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	5660000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414189	2026-03-03 07:44:55.540613
a1fae3c1-fbf9-4bfb-b8fa-5bf0c3097bee	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	5150000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414186	2026-03-03 07:44:55.543272
eea2f471-4077-47d2-954d-700bf9b5ae49	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-05	7655000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414183	2026-03-03 07:44:55.54595
fc32f8de-30e5-4de2-9505-719fee48a59c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-28	1305000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402908	2026-03-03 08:47:56.402909
0f9ed952-a473-457d-9d3d-44f1ca67361b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	3775000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402912	2026-03-03 08:47:56.402912
0ff640f7-80cf-43a3-bc94-0d589b3120db	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-01	11130000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402915	2026-03-03 08:47:56.402915
2d10533a-4068-44fd-96d6-767422b8cf0e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-01	660000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402918	2026-03-03 08:47:56.402918
394f6ff6-584c-4860-9349-fa99d74d9471	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-04	17705000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402921	2026-03-03 08:47:56.402922
9875cdd0-0999-45b7-a13e-1e827fdcfdfc	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-08	425000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402924	2026-03-03 08:47:56.402925
f5c73483-796e-4766-9b75-25c286b64e9b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-08	1140000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402928	2026-03-03 08:47:56.402928
f997b955-aad5-4b65-9064-14b47ee610f2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-11	31000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402931	2026-03-03 08:47:56.402931
1138507f-4fe0-4850-918b-b659a96d0366	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-11	11340000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402934	2026-03-03 08:47:56.402935
314d9250-b522-4920-9599-20484c5b5c53	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-12	25000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402937	2026-03-03 08:47:56.402938
3b9a437a-2869-406e-8dd9-ed141c3d10b0	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-12	41240000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402941	2026-03-03 08:47:56.402941
271e848d-52fd-4a0e-b206-468be1338bfb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-12	2555000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402944	2026-03-03 08:47:56.402944
0ed68528-0d99-4174-9d44-8714d3bc9b02	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-15	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402947	2026-03-03 08:47:56.402947
e2483173-3d1a-4abb-a237-4cc56b03c961	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-15	2745000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40295	2026-03-03 08:47:56.402951
f7ff20ab-ff96-4536-8a90-00ec6d74d3eb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-15	11420000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402953	2026-03-03 08:47:56.402954
508da06d-0f53-4586-b0bc-c9c1bf7061a2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-15	4460000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402957	2026-03-03 08:47:56.402957
bfa7d8f3-6580-4c98-9cb1-addb2a56af46	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-17	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40296	2026-03-03 08:47:56.40296
f497f2de-0d36-4823-a880-83f453951c08	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	1205000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402963	2026-03-03 08:47:56.402963
c22fda24-9e24-4935-b37b-de5374b9d881	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	14460000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402966	2026-03-03 08:47:56.402966
6c39474b-16b0-41aa-bc15-0b03f34cd245	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	1975000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402969	2026-03-03 08:47:56.40297
1df8aeb7-b2eb-4375-83b2-b6cf343971b1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-17	1640000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402972	2026-03-03 08:47:56.402973
c225884f-6168-4210-b323-5d2e43f1b2c6	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-18	2495000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402976	2026-03-03 08:47:56.402976
2cc3c4e0-3856-4eaf-bc9e-488ea1e81c99	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-19	4360000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402979	2026-03-03 08:47:56.402979
f9e8fa3f-e912-4be3-930b-da3bc919d557	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-19	315000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402982	2026-03-03 08:47:56.402982
94d0e0ee-3555-43df-950c-de5f42145a1f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-22	10000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402985	2026-03-03 08:47:56.402986
c64961a6-0ee8-459f-acaa-d87a90a14a8d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-22	540000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402989	2026-03-03 08:47:56.402989
326077b5-1315-4737-8655-1574ef964171	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-22	5905000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402992	2026-03-03 08:47:56.402992
654b2d93-3f38-41ea-8063-536f91671719	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-23	4965000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402995	2026-03-03 08:47:56.402995
206f7022-7fc0-467b-9e21-e78fa498407d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-23	1080000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.402998	2026-03-03 08:47:56.402998
adad286b-0408-4956-8117-d1100d187988	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-24	550000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403001	2026-03-03 08:47:56.403001
c637721f-d42f-4cb4-aa0e-5511f6a6b10a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-26	25000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403004	2026-03-03 08:47:56.403005
b23516dc-9017-4a15-92a5-6410a4aabeee	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-26	2760000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403008	2026-03-03 08:47:56.403008
2d0e2f51-de79-4a71-97cd-172e60d12f5a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-26	280000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403011	2026-03-03 08:47:56.403011
13c23709-a61c-465d-a061-84086e2f72fe	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-29	21470000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403014	2026-03-03 08:47:56.403014
ae264bd6-9038-424f-871f-8d64df25011d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-29	105000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403018	2026-03-03 08:47:56.403018
6f5a690e-20e7-4848-b17c-e4a63c63a493	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-30	50000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403021	2026-03-03 08:47:56.403022
cd7ff514-5476-410f-a104-dcd2e247c734	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	32420000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403025	2026-03-03 08:47:56.403025
234b1592-4da3-44dc-bd52-aa57d83ada63	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	10860000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403028	2026-03-03 08:47:56.403028
a58747d7-0ee5-4fc1-a60c-66d4b5128ab0	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	1155000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403032	2026-03-03 08:47:56.403032
18bf4e0c-e3ee-4ed9-b9b7-1f0ed55c0620	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-05	2170000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403035	2026-03-03 08:47:56.403035
4c355934-855e-4c20-994e-393b7401ac17	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	25000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403038	2026-03-03 08:47:56.403039
c73d24b3-f4d3-4904-824d-55be623a6fb2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	4190000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403042	2026-03-03 08:47:56.403042
eaf18205-3815-4031-b966-53c9d082f1af	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	18030000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403045	2026-03-03 08:47:56.403045
e0dc669a-343c-42de-b61e-682518043e8b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	14090000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403048	2026-03-03 08:47:56.403049
543ce973-fbd3-41d0-97f1-b5faafc57f56	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	1985000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403052	2026-03-03 08:47:56.403052
2a6df234-043e-4164-8d4c-1245d322c445	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	6690000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403055	2026-03-03 08:47:56.403055
2f0eb026-4893-44bf-8c95-f9a34b2614dd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-09	2405000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414507	2026-03-03 07:44:52.893063
bc7206a9-91df-49be-a895-07a03eb5a0fd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-09	9005000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414504	2026-03-03 07:44:52.897823
543065fe-b88e-466e-9990-53128d5e89de	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-09	16440000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414501	2026-03-03 07:44:52.901198
9c86a968-8454-4920-8126-78a10cc668ca	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-08	310000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414498	2026-03-03 07:44:52.9044
e1a16fbf-b7ab-4b7c-8f26-ffd914f63a39	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-08	12780000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414495	2026-03-03 07:44:52.907682
73af3a2d-d254-446e-ba8d-8b75f04d8540	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	5000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414492	2026-03-03 07:44:52.911059
2e76d140-5e4d-4b10-831b-f1e23682b147	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	6690000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414488	2026-03-03 07:44:52.914193
d8f29d00-522b-46f5-9d97-b130cd1caf7f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	1985000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414485	2026-03-03 07:44:52.918102
a9aeed25-9525-4ba6-99d6-549395309224	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	14090000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414482	2026-03-03 07:44:52.921461
53845d49-f337-4dea-bf4d-9be745b1ee89	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-06	18030000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414479	2026-03-03 07:44:52.924577
3338890f-9c16-4c7f-9373-a26be8127ba9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	4190000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414476	2026-03-03 07:44:52.927557
99dd07df-19f8-4a86-bb97-0dabd08ab99e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414473	2026-03-03 07:44:52.930513
857a9441-e892-47b8-b070-6051076475c4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-05	2170000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41447	2026-03-03 07:44:52.933415
3eb68f3d-52ba-44cf-95db-c9df0944d52e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	1155000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414467	2026-03-03 07:44:52.936216
0fc3a233-c210-487c-9346-bea15e7f6cd4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-06	5000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403058	2026-03-03 08:47:56.403059
2b823d1a-1eaf-4885-b64d-dbe97d43ca51	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-08	12780000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403061	2026-03-03 08:47:56.403062
f616d11f-76f9-4083-8d23-c50de3b08bdc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-08	310000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403065	2026-03-03 08:47:56.403065
33cbd84f-e02a-49b2-a89c-3181e0f1982b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-09	16440000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403068	2026-03-03 08:47:56.403068
aab77864-d0e6-4b27-ad84-06964f0940ec	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-09	9005000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403071	2026-03-03 08:47:56.403072
fbf53ea9-a611-4660-a242-a869440fc4c8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-09	2405000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403074	2026-03-03 08:47:56.403075
53f563a5-83b4-4304-a7bd-a32b64f2eaa0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-09	2100000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403078	2026-03-03 08:47:56.403078
dea80e2b-97ef-457a-ab25-b309ad1e1d56	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-12	25000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403081	2026-03-03 08:47:56.403081
47d80e7a-c469-4221-919c-eabe7b6bec48	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-12	4135000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403084	2026-03-03 08:47:56.403085
d0150d87-a406-4d0d-b275-305504eff7d7	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-12	880000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403088	2026-03-03 08:47:56.403088
b37f9de2-ae49-449d-82d9-6f452e60da2e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	10945000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403091	2026-03-03 08:47:56.403091
2a776b22-6444-4790-8bbe-337aa0a0cad1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	6405000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403094	2026-03-03 08:47:56.403094
2f5d288e-41c0-4f66-9a45-2e5ff73f5b7b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	4920000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403097	2026-03-03 08:47:56.403098
aec77b7b-7236-4216-8362-f7194a0f8ebc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-13	1855000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.4031	2026-03-03 08:47:56.403101
e2788c52-dac0-45b2-b87f-79557d7562b0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-14	17550000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403104	2026-03-03 08:47:56.403104
80448e47-cba9-434b-97ae-0b0ade93755a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	1720000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403107	2026-03-03 08:47:56.403107
397dbc7a-d155-4679-a37b-eed0734651a5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	750000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40311	2026-03-03 08:47:56.40311
261e2286-9977-4541-8de6-f0db5aab943f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	7610000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403113	2026-03-03 08:47:56.403114
0e00a132-b082-44de-823f-86979246da04	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-14	4770000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403116	2026-03-03 08:47:56.403117
dabaf8f4-a056-4cf6-9f9b-be46cf20a485	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-15	375000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40312	2026-03-03 08:47:56.40312
12dec9a6-e124-40bf-a978-a50058b583c1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-15	5000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403123	2026-03-03 08:47:56.403123
dc074c4e-c417-478b-b0a4-feab42f72558	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-15	23385000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403126	2026-03-03 08:47:56.403127
f5f3d9ed-9fcf-4aaf-a87c-ddeaf29759db	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-15	2110000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403129	2026-03-03 08:47:56.40313
8d71f989-f400-444b-81fe-9db99e082700	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-16	32000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403132	2026-03-03 08:47:56.403133
f80acf88-79b4-4e19-9a30-8e0e4938ee3a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-16	18515000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403136	2026-03-03 08:47:56.403136
3b76fcdb-4cdb-4f06-9a50-3a76b7dd8a7b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-16	3445000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403139	2026-03-03 08:47:56.403139
0f25b51c-4cc3-4f53-9ec9-3e2d35a7e685	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	18700000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403142	2026-03-03 08:47:56.403142
fb993214-fcca-4a69-bac0-f534b3d52359	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	4050000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403145	2026-03-03 08:47:56.403146
f578fa5d-8958-4b82-a131-286197136db6	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	3445000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403149	2026-03-03 08:47:56.403149
0985844c-66da-4176-aff8-0264e6f473da	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	33000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403152	2026-03-03 08:47:56.403152
c79041c1-2d65-4bfd-9a5c-094ab33a2959	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	23520000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403209	2026-03-03 08:47:56.40321
6865721f-818b-4d45-8f10-bd33bff3a92a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	4730000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403215	2026-03-03 08:47:56.403215
434a17d3-e73b-460b-b764-a2a22722d701	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	121000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403221	2026-03-03 08:47:56.403221
1dd9c15c-ebb5-406f-a1d6-23a059e9b642	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	32060000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403226	2026-03-03 08:47:56.403227
b0dcffb9-5749-492c-91d6-ddc5abc388c3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	12045000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403232	2026-03-03 08:47:56.403233
3ec2d8cf-afc3-45b9-815c-72af2dbe7187	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-21	40000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403238	2026-03-03 08:47:56.403239
5006977c-3c5a-4d37-a2d1-de2f4d587d7e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	17435000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403244	2026-03-03 08:47:56.403245
f492ddf8-9b22-4de3-8989-710ec07549be	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	7730000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40325	2026-03-03 08:47:56.403251
a74f7550-65a2-47fd-9ef4-aa82114dbf03	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	570000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403256	2026-03-03 08:47:56.403256
11338fca-335c-4ab7-99d4-9eb4516b622f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	12830000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403262	2026-03-03 08:47:56.403262
e26b19f2-77c1-47b3-80f5-86f3a1cb4ea9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-21	375000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403268	2026-03-03 08:47:56.403268
f56f0cad-e785-4c3c-b1a4-d064282a9625	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-22	35000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403273	2026-03-03 08:47:56.403274
b1817845-826a-4537-aba3-878108acedee	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	13715000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403279	2026-03-03 08:47:56.403279
a3478cfb-1154-4d67-a368-1e310cfe2779	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	22400000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403284	2026-03-03 08:47:56.403284
199725ed-f49f-4def-b085-55a73d8e2069	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	4479000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403289	2026-03-03 08:47:56.403289
4ca5e5fd-ee79-4eb6-8406-06023c2a63e9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-23	75000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403294	2026-03-03 08:47:56.403294
6061ad1e-32d9-4c49-af21-e6b70a3c48df	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	925000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403298	2026-03-03 08:47:56.403299
9a74c2cd-c69b-45a5-b0c8-2f2fd2bb1520	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	28240000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403304	2026-03-03 08:47:56.403304
c2499d43-86ad-45a3-92f0-8ba3bd6366c1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	9435000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403309	2026-03-03 08:47:56.403309
7517ffee-fd04-4ab5-aac4-687904134c60	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	7310000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403314	2026-03-03 08:47:56.403314
e58dff41-0721-43e5-b176-d3f8091f7095	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-23	4375000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403319	2026-03-03 08:47:56.40332
b64aae9f-fb1a-47d2-bcc0-a2ec546cf94d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-27	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403324	2026-03-03 08:47:56.403325
4d451674-82c4-4326-bd0c-3923a8ea541e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	910000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403329	2026-03-03 08:47:56.40333
5316c73a-3cee-4627-9a88-01b4dc439a95	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	25495000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403335	2026-03-03 08:47:56.403335
2d8e7efd-7ae0-402b-b13b-ecd3871a3fa1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	15310000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40334	2026-03-03 08:47:56.40334
fceb748d-75e2-46f5-b0db-c3ae94496616	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	7450000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403345	2026-03-03 08:47:56.403346
b620ce76-49cf-49a7-a9f2-4c7d3fc790d1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-27	2005000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40335	2026-03-03 08:47:56.403351
ac8bccb5-5dd8-4165-9d51-2d7cec104cde	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	30000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403355	2026-03-03 08:47:56.403356
30c42eab-322d-44cf-8148-99f01dce843c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-28	485000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403361	2026-03-03 08:47:56.403361
47a9d376-c095-4ad8-8ec6-f9976faab139	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	4350000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403366	2026-03-03 08:47:56.403367
f78714cc-4b67-4e80-9ac1-9732069dc666	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	8000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403371	2026-03-03 08:47:56.403372
23ab0524-7309-47ef-ad9f-0fe76833ef62	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	635000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40338	2026-03-03 08:47:56.40338
827916dc-f0b3-4c28-b19d-c9d4158a6d03	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	17945000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403394	2026-03-03 08:47:56.403394
8b59eb80-9ac0-4cc4-a546-0523a36e6145	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	10470000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403397	2026-03-03 08:47:56.403398
f3e7ac8c-e505-472f-b1aa-e230de486831	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-30	16500000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403401	2026-03-03 08:47:56.403402
0a7981a7-32cd-4e49-a3c0-b4e3c53842b1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	1230000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403405	2026-03-03 08:47:56.403405
013e3b21-d10a-46f7-828a-c6e4843eae3d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	25430000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403409	2026-03-03 08:47:56.403409
da698d85-275a-455e-b18d-e9a9f1e12fd7	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	3885000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403412	2026-03-03 08:47:56.403412
5e6ec45c-0b59-4ec8-9b76-2aba58eb54d2	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	4040000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403415	2026-03-03 08:47:56.403415
81d5f2a1-ab30-47de-b789-9742b43d12e0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-30	2270000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403418	2026-03-03 08:47:56.403419
73226541-f590-4bb5-b564-d2baa2e11dca	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-02	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403422	2026-03-03 08:47:56.403422
141a95af-d7b3-4b6c-8b04-9b4de497b859	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-02	12795000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403425	2026-03-03 08:47:56.403425
4677df83-7a92-45c4-8e54-d43f7541b2aa	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-02	2190000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403428	2026-03-03 08:47:56.403428
d1ca31e5-cd4f-4cc6-b796-f16d0d4f1d84	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-02	205000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403431	2026-03-03 08:47:56.403431
d9e5dee9-72bb-4290-92b8-8c019979c57d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-03	33000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403434	2026-03-03 08:47:56.403435
789db6bd-bb1f-4a2e-8b4e-3a51c5c8ad76	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-03	15740000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403437	2026-03-03 08:47:56.403438
e0e0678c-f60c-46e7-863c-a28bcafffed0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-03	950000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403441	2026-03-03 08:47:56.403441
879bb843-1fa6-4a4e-9401-466da5bcd82d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-04	24460000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403444	2026-03-03 08:47:56.403445
3180e2ae-9c27-412b-90c0-b529e39a6808	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-04	14575000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403447	2026-03-03 08:47:56.403448
13bf92c1-fc2f-4169-8e4a-3411bbd361b0	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-04	18810000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403451	2026-03-03 08:47:56.403451
3b9bc997-5b81-49b5-ae62-f684448e6407	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-04	4140000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403454	2026-03-03 08:47:56.403454
bb3f1cf4-07f7-48c9-99cb-22f34127aba9	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	645000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403457	2026-03-03 08:47:56.403457
7990c7d1-13ee-40c7-9aa8-e0c05bef99a1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	3555000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40346	2026-03-03 08:47:56.403461
5380d19a-e3d5-4ac8-8515-3983579dda1e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	14985000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403464	2026-03-03 08:47:56.403464
5938b750-2abe-437d-9607-47cf8102ac1f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	8290000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403467	2026-03-03 08:47:56.403467
adaecc16-b527-41df-b374-a03dc6d7f988	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-06	42000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40347	2026-03-03 08:47:56.40347
c406667e-e67d-4a72-96aa-3db5ed1caeed	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-19	21008000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414821	2026-03-03 07:44:49.427324
bc0dd140-d0b7-451f-9e5b-03742bbb2a58	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-11	1500000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414817	2026-03-03 07:44:49.440792
a7b062fa-1ebb-46ee-8a48-546f5e7b1584	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	1060000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414814	2026-03-03 07:44:49.444753
2b5cbac1-fe93-4e79-8a12-0583a6e19de0	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	13250000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414811	2026-03-03 07:44:49.447994
97bd2a35-c6fa-457c-be9f-c47634362001	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	1500000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414808	2026-03-03 07:44:49.451056
3eb6eeee-0bd9-48ab-8527-c66aaa742e98	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-11	39050000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414805	2026-03-03 07:44:49.454155
98d3b9a8-251c-4052-b0f0-5c27da364893	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-10	40000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414802	2026-03-03 07:44:49.457042
2a41db1a-85a0-4a4a-bc69-3bc5d53312ed	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	14010000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414799	2026-03-03 07:44:49.459649
ada72044-f874-416e-af3e-59b74285c16f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	23245000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414796	2026-03-03 07:44:49.462261
371481d2-d5b8-476e-bda9-bb0a1a5e7a8b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	14660000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414792	2026-03-03 07:44:49.465251
8086c5e8-2f1b-48eb-af24-c75998dc1cd3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-10	4230000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414789	2026-03-03 07:44:49.467851
b6df9bdf-ede5-48d4-b632-a868c3bfc98a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-09	5010000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414786	2026-03-03 07:44:49.470563
40309681-1e95-4421-99ff-fdc91984d5c7	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	9275000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414783	2026-03-03 07:44:49.473233
7e320f59-d172-4f78-99f1-3b56078cbf2a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	8730000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41478	2026-03-03 07:44:49.475821
4864e729-a57d-48bf-b17b-7197ddd5fa1a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	1160000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414777	2026-03-03 07:44:49.478364
583b40c1-3d2b-492f-9848-a15313fa0631	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-09	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414774	2026-03-03 07:44:49.480942
0fc2b0c2-7bf3-4deb-b8dd-041cd8ede734	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-06	2575000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414771	2026-03-03 07:44:49.483615
0b1f888c-6ef1-4100-bd11-bf902693bc26	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	12085000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414767	2026-03-03 07:44:49.486227
77be9797-9148-495a-b81f-4fdc370ce15b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	29070000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414764	2026-03-03 07:44:49.489178
b754cd37-0652-4643-82ca-08022db459a3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	9865000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414761	2026-03-03 07:44:49.491794
f1e48e21-4518-44ad-90c4-39550d79a2f1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-06	42000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414758	2026-03-03 07:44:49.49452
18751b82-e01d-450b-8c4b-1041c4f08c4c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	8290000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414755	2026-03-03 07:44:49.497135
7b086a5e-9fcc-490e-9d4b-07a5938f1177	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	14985000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414752	2026-03-03 07:44:49.499708
a15fd851-fce9-4926-8ac8-59e7286859bb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	3555000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414749	2026-03-03 07:44:49.502829
dac232a4-00a7-4ec2-bf15-5bcc1d87a7bc	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-05	645000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414746	2026-03-03 07:44:49.505998
a3f410ec-95cf-435e-925b-541f407842e2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-04	4140000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414743	2026-03-03 07:44:49.508749
10deaee0-af53-4e50-abdd-4ed40fe7de19	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-04	18810000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414739	2026-03-03 07:44:49.511294
ee220d9b-b0ca-439f-8f3c-472b72eec21c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-04	14575000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414736	2026-03-03 07:44:49.513963
65f64ac0-5229-443c-a3f5-96f58f3719cc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-04	24460000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414733	2026-03-03 07:44:49.516551
a438e7f5-ba20-40a0-bbd0-eb38c01a42d8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-03	950000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41473	2026-03-03 07:44:49.519099
bbb090c8-0746-4a19-9f0a-4ea1bb6529ef	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-03	15740000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414727	2026-03-03 07:44:49.521752
2ae07bc8-c071-45ca-89b0-315f397e092f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-03	33000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414724	2026-03-03 07:44:49.524572
76fabc38-e3a3-4c8e-a81e-a6d97e5be914	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-02	205000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414721	2026-03-03 07:44:49.527283
e2a0cbc0-e846-437f-8c48-f748d290c676	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-02	2190000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414718	2026-03-03 07:44:49.529979
c81efe09-6fd8-47b0-89b6-3fb5b260da7c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-02	12795000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414715	2026-03-03 07:44:49.533817
8b7fc284-5d2d-4f8b-a44c-5a0d38c3b22b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-02	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414711	2026-03-03 07:44:49.536739
30b1d2a7-680b-4c0b-bf30-8378506f3e1e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-30	2270000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414708	2026-03-03 07:44:49.539422
2f1e30c4-efff-4f0d-90a9-c03ecdf67118	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	4040000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414705	2026-03-03 07:44:49.542868
51b093b6-fa9e-48ed-b782-c9b43fde3cb9	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	3885000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414702	2026-03-03 07:44:49.545725
cbba7745-8fdb-47c6-90eb-10c68f937f1c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	25430000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414698	2026-03-03 07:44:49.548549
d44f39c5-f3d4-40b6-96ab-24b0d2c627d3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-30	1230000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414695	2026-03-03 07:44:49.551324
272b8a4e-88e9-4955-a770-9cf8689c31bb	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-30	16500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414692	2026-03-03 07:44:49.554623
1b0a15e0-fb90-4378-a957-2c21a9b5a56e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	10470000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414689	2026-03-03 07:44:49.557572
00fe356c-1c55-4249-8035-85b17b0d4c78	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	17945000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414686	2026-03-03 07:44:49.560243
aadf283d-c3b6-4e52-afce-ead44093141b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-29	635000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414683	2026-03-03 07:44:49.562853
e2853045-bbbc-4c12-9885-fdfd53ac89c1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	8000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41468	2026-03-03 07:44:49.565753
b62b7c47-2d07-4fe7-b908-9ed25a0977b1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	4350000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414676	2026-03-03 07:44:49.568383
c644a701-f243-47df-8a36-6fd6607aa203	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-28	485000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414673	2026-03-03 07:44:49.57097
3255e802-b01d-42ed-8740-b56f9db39108	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-28	30000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41467	2026-03-03 07:44:49.573616
82e5281f-0c7f-40eb-8bb6-9a215581621f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-27	2005000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414667	2026-03-03 07:44:49.576952
dfccc409-f15b-41c4-9a98-ce9b06f0437f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	7450000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414664	2026-03-03 07:44:49.579856
4f004a72-215d-4c81-838a-d8173535d325	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	15310000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414661	2026-03-03 07:44:49.58248
804807e2-6f70-4260-b6fa-5b65426effaa	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	25495000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414657	2026-03-03 07:44:49.58519
19d4c0e0-5723-4e9e-9165-45b8298e76ba	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-27	910000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414654	2026-03-03 07:44:49.587781
a5bcb51d-5318-46ee-8885-25028c9f1c35	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-27	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414651	2026-03-03 07:44:49.590674
478c7027-533e-4b3d-991f-8bcbdbcd61da	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-23	4375000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414648	2026-03-03 07:44:49.593364
2eadb8ac-a712-40b0-a5df-8caaeccd2966	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	7310000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414645	2026-03-03 07:44:49.59592
26b6c077-0b72-4a68-bd12-651dc3759441	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	9435000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414641	2026-03-03 07:44:49.598518
375dbbeb-bafb-4410-a8e8-2fbde5b1bf66	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	28240000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414638	2026-03-03 07:44:49.601101
3262d380-17cf-4b49-b894-073288c1cee2	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-23	925000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414635	2026-03-03 07:44:49.603853
4eb377e8-719a-407d-bd99-277195002604	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-23	75000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414632	2026-03-03 07:44:49.606536
0b4cf43c-2c0b-45bb-bc2c-c56acb0885ad	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	4479000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414629	2026-03-03 07:44:49.609184
4192b9a3-7afa-4e4c-be17-410e366543b5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	22400000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414626	2026-03-03 07:44:49.612668
5d9bdf40-5638-455e-add9-f8c980897983	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-22	13715000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414623	2026-03-03 07:44:49.615487
7e877be3-82cc-4e2d-b485-83758307fa69	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-22	35000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414619	2026-03-03 07:44:49.618178
2af6d3b5-072f-4743-badd-e79a9e4c41b3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-21	375000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414616	2026-03-03 07:44:49.620904
189a5397-2322-4bf7-be53-e72ed18c071e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	12830000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414613	2026-03-03 07:44:49.623623
edcfe955-ab65-44c5-b324-1fdf55c0dbce	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	570000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41461	2026-03-03 07:44:49.626533
3019601b-e066-4917-8a56-fd8ed6a9d8ef	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	7730000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414607	2026-03-03 07:44:49.629344
32a89a0a-67bf-415f-abbc-c21e36f4a532	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-21	17435000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414604	2026-03-03 07:44:49.632052
294b778b-4745-4e5a-adf3-5439571b6d4c	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-21	40000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414601	2026-03-03 07:44:49.634901
9a610d72-25a7-482d-afa5-c44afadba0a5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	12045000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414597	2026-03-03 07:44:49.637653
e27de8f8-3641-49ca-9606-b0d131df906a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	32060000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414594	2026-03-03 07:44:49.640404
2c485c0e-b58f-4595-9c5a-1fd7d09e8adb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-20	121000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414591	2026-03-03 07:44:49.643085
15264239-7109-4da8-8b1c-6e407c2f70d8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	4730000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414588	2026-03-03 07:44:49.645917
96697a3a-b4ca-427e-bc30-7a3b44c4d15e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	23520000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414585	2026-03-03 07:44:49.648972
0b0273f2-9f1a-4556-9c77-07dc5ed7d736	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-20	33000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414582	2026-03-03 07:44:49.651729
602d68c5-6a98-48cc-822c-195ec448eb10	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	3445000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414579	2026-03-03 07:44:49.654623
91f339fc-513a-46ae-87d5-cf21d89c2b9a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	4050000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414576	2026-03-03 07:44:49.65744
df118e93-ceaf-4bf9-b108-ef8363b41278	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-19	18700000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414573	2026-03-03 07:44:49.660233
0851e8d9-aab6-4c26-9de3-e7b21b71183d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-16	3445000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41457	2026-03-03 07:44:49.663326
9e09c268-51e3-48ef-b6d5-adb02df3ac4d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-16	18515000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414566	2026-03-03 07:44:49.666328
abe2e609-bd4e-4cbf-bbde-ceabd7c23758	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-16	32000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414563	2026-03-03 07:44:49.669047
c75950d6-84c0-40d0-a203-78acc136387b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-15	2110000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41456	2026-03-03 07:44:49.671819
b0f1b0ff-ecfa-46f1-807f-9c7d152f0149	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-15	23385000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414557	2026-03-03 07:44:49.674714
eb938bb0-fd86-45e6-a7db-b60be563c837	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-15	5000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414554	2026-03-03 07:44:49.67757
91d8b879-3424-4123-8210-07fa0be3e097	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-15	375000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414551	2026-03-03 07:44:49.680416
3fd752da-74ae-4cfe-a78e-ac52739a0bc9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-14	4770000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414548	2026-03-03 07:44:49.683861
f3f61b64-0602-4fe5-bd8a-ce06b6d0d019	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	7610000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414545	2026-03-03 07:44:49.686596
21c19e8e-2506-41a0-b725-72eac8e73b00	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	750000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414542	2026-03-03 07:44:49.689359
556745bc-effb-4af1-8e2e-78f7d8136b90	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-14	1720000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414539	2026-03-03 07:44:49.692229
b3e696cd-1b11-4e0d-b9b2-861c3ce7a69d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-14	17550000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414536	2026-03-03 07:44:49.694993
e109b9e2-8eb2-4e54-bc2c-e585553cf69d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-13	1855000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414532	2026-03-03 07:44:49.697792
e4668b48-a12b-4a15-a129-1111b519be16	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	4920000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414529	2026-03-03 07:44:49.700505
0bd4f8d9-8102-4ca0-80f0-435e57b822f8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	6405000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414526	2026-03-03 07:44:49.703234
b2018489-d6ab-4e74-bbcd-a0558e198164	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-13	10945000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414523	2026-03-03 07:44:49.706031
adf08477-38c8-4374-98bf-48ed41a372b5	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-12	880000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41452	2026-03-03 07:44:49.708936
1b311e49-8592-4bf4-b79b-fa08c36305ff	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-12	4135000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414517	2026-03-03 07:44:49.7116
5a3d53c6-d827-43be-a923-aa7980968ff1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-12	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414514	2026-03-03 07:44:49.714337
7ccaa215-2d97-46fb-815e-e179b65754e4	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-01-09	2100000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414511	2026-03-03 07:44:49.717172
ba8e7b80-2718-416d-8b64-8cb77c3e64b3	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	10860000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414464	2026-03-03 07:44:52.938953
4ca7c60a-897d-4777-828d-834345b848bd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-01-05	32420000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414461	2026-03-03 07:44:52.941784
a5285639-f4aa-4d8f-be6e-36b91ae21b6f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-30	50000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414458	2026-03-03 07:44:52.944665
91305689-49f2-476a-939d-d7865e5d0798	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-29	105000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414455	2026-03-03 07:44:52.947325
e20fb899-0962-478b-8023-2f6dfc1c7cc4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-29	21470000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414452	2026-03-03 07:44:52.94998
a34ff496-dbf2-482c-9d00-49d18c50004d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-26	280000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414448	2026-03-03 07:44:52.95262
cf30b852-6026-43d7-a2a5-090b08ddbfc5	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-26	2760000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414445	2026-03-03 07:44:52.955206
f7bfd3e9-20f8-4f05-b1da-0a899b6d02f2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-26	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414442	2026-03-03 07:44:52.957864
73461c78-07c0-4009-96a7-d27ce3aeb188	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-24	550000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414439	2026-03-03 07:44:52.960499
48f3be13-5989-4843-9f35-77790674eacc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-23	1080000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414436	2026-03-03 07:44:52.963058
e4328190-d15d-465d-9b3d-e6e533e90884	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-23	4965000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414433	2026-03-03 07:44:52.965762
3ea16246-2dd0-4575-8077-4a4844273df8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-22	5905000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41443	2026-03-03 07:44:52.968396
62bcabc0-5d23-4f49-9f83-c2151757f297	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-22	540000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414427	2026-03-03 07:44:52.971103
c434f9cb-9382-40f4-9c46-d9f24a2c6702	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-22	10000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414424	2026-03-03 07:44:52.973864
3c351e4d-b662-4c6b-8ea7-9288b6234a34	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-19	315000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414421	2026-03-03 07:44:52.976701
74ff8083-824e-42ed-9dab-e30f160d1daf	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-19	4360000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414417	2026-03-03 07:44:52.979356
1ef97430-ab74-4463-b419-b390a5e5b65d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-18	2495000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414414	2026-03-03 07:44:52.982119
3f9dbbff-8675-444d-be14-bb53db9ee6ad	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-17	1640000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414411	2026-03-03 07:44:52.984934
0d901ded-bdd4-4944-88dc-f0d7838dad98	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	1975000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414408	2026-03-03 07:44:52.98772
2531d993-955c-4569-8578-e9fa558dadeb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	14460000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414405	2026-03-03 07:44:52.990388
1bad8b90-47f2-479f-acb0-f6cbb42956ce	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-17	1205000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414402	2026-03-03 07:44:52.993894
e056e63a-e69a-47d7-911c-442649c0e701	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-17	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414399	2026-03-03 07:44:52.996763
feceb418-72b1-4c77-9868-87535ab1d015	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-15	4460000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414396	2026-03-03 07:44:52.999483
3bccc754-23b0-40dc-bb1c-1f7f6adaa02f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-15	11420000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414393	2026-03-03 07:44:53.002287
86265afe-e2bc-481d-bb14-7713dfbb5264	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-15	2745000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41439	2026-03-03 07:44:53.00502
8181c6a2-1cc2-4c72-89e1-e7a463abd45f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-15	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414387	2026-03-03 07:44:53.007691
ed42bd0e-e33e-4ee6-862b-a1215bea0313	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-12	2555000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414384	2026-03-03 07:44:53.010503
e9603bbc-d856-4cb0-8219-4810741c7297	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-12	41240000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41438	2026-03-03 07:44:53.013549
b85b22e1-f496-4c69-801c-8224d8370441	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-12	25000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414377	2026-03-03 07:44:53.016325
5e5fcdfe-c971-458b-8231-c776c2759283	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-11	11340000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414374	2026-03-03 07:44:53.019006
5fa16c99-3ff7-4744-8f9f-27d04b7e3285	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-11	31000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414371	2026-03-03 07:44:53.021746
1ef789e7-d756-4535-908b-df25caa8ccd2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-08	1140000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414368	2026-03-03 07:44:53.02452
6d2363b7-27a2-4cc0-8d74-0c402f8785dc	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-08	425000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414365	2026-03-03 07:44:53.027158
4c8a1595-853d-4c0a-964b-a4de94e6b2bf	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-04	17705000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414362	2026-03-03 07:44:53.029971
4bdf699c-7eab-4bbc-ba5e-ac19169800ed	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-12-01	660000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414359	2026-03-03 07:44:53.032738
be292b95-cf35-49dd-81a2-adfcf1d85017	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-12-01	11130000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414356	2026-03-03 07:44:53.035574
109bc7d8-edaa-4948-b57a-4ebadaeedaf1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	3775000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414353	2026-03-03 07:44:53.03835
5fe9117d-46b8-4513-b17e-bb6a3158a0f8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-28	1305000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41435	2026-03-03 07:44:53.041153
ac0cb523-a402-4ff7-95aa-ccca627765d3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	16000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414347	2026-03-03 07:44:53.044013
b8739bbd-0f11-4e58-8566-a084130c4404	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	24000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414344	2026-03-03 07:44:53.046785
6d91b589-6206-4bbe-8a76-8fb3acd7f358	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-28	12000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41434	2026-03-03 07:44:53.049641
fd256662-bc2b-4728-b857-4096982c394f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-27	2960000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414337	2026-03-03 07:44:53.052556
2835d476-c297-4aae-ab1c-b6fbd56ace04	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	7900000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414334	2026-03-03 07:44:53.055347
abe24b8f-09ec-457f-a68e-903daaa6a8f0	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	17310000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414331	2026-03-03 07:44:53.058071
d6e51681-a526-41bd-b544-558d70b1dc6a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-27	9990000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414328	2026-03-03 07:44:53.060845
a8f3e41e-90cf-4dd4-958b-b227aa374b08	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-26	2750000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414325	2026-03-03 07:44:53.064478
e9d052a0-221a-4904-8a41-f1aeaf409d68	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-26	24185000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414322	2026-03-03 07:44:53.067275
47946396-dc2f-4382-ac07-bc00b0acf7c2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-26	16840000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414319	2026-03-03 07:44:53.070103
d571ac2a-d6ce-470d-8d86-e63751677172	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-24	4180000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414316	2026-03-03 07:44:53.072864
8b171a40-1a17-4a06-b1f0-ebf5f7160f44	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-24	7025000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414313	2026-03-03 07:44:53.075617
6ed1135b-30a7-441b-b90d-76dd148ed7fa	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-24	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41431	2026-03-03 07:44:53.078455
54ab9b1f-8d4d-4a32-8505-053780676c2b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-21	2850000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414306	2026-03-03 07:44:53.081361
f4aa653e-145d-4e00-83e6-b268fca48ef6	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-20	2520000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414303	2026-03-03 07:44:53.085002
9f3b5656-77e4-4079-a29c-6c1ffb036530	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	6885000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.4143	2026-03-03 07:44:53.088231
de73bfab-1f29-450e-b641-a93aa2e2946c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	10000000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414297	2026-03-03 07:44:53.090973
46970588-ef7f-4555-bf89-a5b41d233034	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-20	1040000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414294	2026-03-03 07:44:53.093851
e891dd40-5801-4953-8c67-f08e4ad257d9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-20	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414291	2026-03-03 07:44:53.096556
39b7c274-9070-4d8a-950e-ff4b7e9e5460	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-19	14535000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414288	2026-03-03 07:44:53.099266
5a889bbd-b2a4-43d1-8436-b2a8f5ad45bd	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-18	260000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414285	2026-03-03 07:44:53.102024
736a6e02-3e57-479a-a47b-41e692b1cf05	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-18	7015000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414282	2026-03-03 07:44:53.104897
87cb846a-9a42-4c2e-87ca-56aba390e4f7	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-18	7880000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414279	2026-03-03 07:44:53.107708
4bb045ab-8827-49e1-920e-2c7d17dcf3b2	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	4840000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414276	2026-03-03 07:44:53.110533
6ba7d575-f2ed-4217-8f0d-d88f6e6d0722	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-17	8390000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414273	2026-03-03 07:44:53.114458
8c89d68c-14b9-4225-b9d8-f5c4b23744fc	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	2610000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41427	2026-03-03 07:44:53.117236
5d3c1609-a258-4f6c-be30-13542f95baec	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-17	26900000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414267	2026-03-03 07:44:53.119874
5f525df4-5a3b-4abb-a035-cec38f3c0df7	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-14	2275000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414263	2026-03-03 07:44:53.1227
a4714bc0-1400-4549-bd2b-6d9748e4da6e	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-14	32650000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41426	2026-03-03 07:44:53.125442
bfb2af2d-2988-4a35-b8d5-d81d7895e153	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-14	6485000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414257	2026-03-03 07:44:53.128071
bc41b0c6-50f0-4a0d-8d03-5f3efba7da1e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-14	22910000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414254	2026-03-03 07:44:53.130833
3cf368e1-ba7d-4178-a76f-4af29ed79db8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-13	1600000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414251	2026-03-03 07:44:53.13364
b7a5bcf7-3cf4-4ae7-9419-a20916227324	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-13	13505000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414248	2026-03-03 07:44:53.136371
89d92c59-3227-4da8-a329-49fa2b2376ae	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-13	18180000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414245	2026-03-03 07:44:53.139014
0c3e7211-4ca0-4411-8b11-95098cec2b48	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-12	28925000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414242	2026-03-03 07:44:53.141751
f209a362-fe93-4114-83fd-b420a0ac72c1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-12	5835000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414239	2026-03-03 07:44:53.14456
a112c0b4-73d1-44f0-b093-8ee8e6b6ea6a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-11	4000000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414236	2026-03-03 07:44:53.148093
fdcbe5f6-8c22-4c29-99af-4c22cbd6850c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-11	6470000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414232	2026-03-03 07:44:53.150796
b9d4f2ea-1618-4c8c-b8bc-64a3dd7e81b7	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	21085000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414229	2026-03-03 07:44:53.153469
8f10f186-7422-41bb-a98a-e2c8b957a0db	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	19050000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414226	2026-03-03 07:44:53.156036
7a8c8d46-1fec-485f-b716-d9ee13a384c9	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-10	22110000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414223	2026-03-03 07:44:53.158715
d3488eb7-7ba7-4788-ba89-67684d9977a3	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-10	1020000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41422	2026-03-03 07:44:53.161367
350e1857-d840-4f15-b70f-ac3d0b432fb5	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-07	1820000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414217	2026-03-03 07:44:53.164013
1776aa0a-8f48-4892-9265-e2cfaaa6fcbf	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-07	9720000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414214	2026-03-03 07:44:53.166688
3eeba075-18ae-40cd-a06a-7b82685421c4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-07	4705000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414211	2026-03-03 07:44:53.169392
8bc8a9ce-cd80-442a-a861-59e28f17db2c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-07	24290000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414208	2026-03-03 07:44:53.171929
e7c7a5a2-d933-433f-9782-d10d581ba37e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-06	2150000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414205	2026-03-03 07:44:53.174597
8069c760-ae88-4f61-8934-97a2bb292f7f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-06	3320000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414201	2026-03-03 07:44:53.177209
2e7e5026-dacd-44fc-b615-2d3d5346fd72	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	9865000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403475	2026-03-03 08:47:56.403475
9e50d6dc-99b8-429e-9f7d-faaa2c6dc29d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	29070000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403478	2026-03-03 08:47:56.403479
d83dabc0-c5e0-4e64-95bb-e3293b6e93fc	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-06	12085000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403482	2026-03-03 08:47:56.403482
c197cf9e-28ac-4b41-b398-3a23880fb93a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-06	2575000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403485	2026-03-03 08:47:56.403486
9ff2c320-4d96-4f0b-85d2-af000fbcc129	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-09	20000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403488	2026-03-03 08:47:56.403489
577e5d19-67d2-4a03-a6aa-e2da964e7f79	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	1160000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403492	2026-03-03 08:47:56.403492
c8147f87-9d10-4c3a-aff9-dab30d79d1b9	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	8730000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403495	2026-03-03 08:47:56.403495
11c50493-118c-4b48-afc4-f2d50a4105ab	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-09	9275000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403498	2026-03-03 08:47:56.403498
fb0f1241-79ab-46b4-b6be-ad718a97f495	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-09	5010000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403501	2026-03-03 08:47:56.403502
81cce681-a2c2-4832-b7b8-b97b33d87b85	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-10	4230000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403504	2026-03-03 08:47:56.403505
aadcc5b2-3041-4688-9ebc-978fe75fb37b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	14660000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403508	2026-03-03 08:47:56.403508
9ac51efc-7665-4404-9cee-a4bdc56b8051	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	23245000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403511	2026-03-03 08:47:56.403511
03be88cb-db3c-4514-a60b-731854184c56	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-10	14010000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403514	2026-03-03 08:47:56.403515
6bd016f6-c479-49c4-b646-d3792c65cf39	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-10	40000000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403518	2026-03-03 08:47:56.403518
ce07e44e-e3c1-4d10-abfc-bdb3aa6eda4e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-11	39050000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403521	2026-03-03 08:47:56.403521
d5bd410e-98d2-4453-9136-0f5e1a098ceb	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	1500000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403524	2026-03-03 08:47:56.403524
0628d0c6-b597-48bf-a885-cf86c9b1731b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	13250000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403527	2026-03-03 08:47:56.403528
a5791814-d91d-43a1-a5dd-a14d6c837649	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2026-02-11	1060000.00	0.00	판매	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.40353	2026-03-03 08:47:56.403531
cf30501a-8f49-44bb-b659-3ba371074f63	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-11	1500000.00	0.00	반입	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403534	2026-03-03 08:47:56.403534
d4ce4d6b-3cf2-4e5e-b4fb-fb86d34918a0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2026-02-19	21008000.00	0.00	현금	MANUAL	\N	\N	\N	PENDING	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:47:56.403537	2026-03-03 08:47:56.403537
19e4187a-3a5c-475d-8dd1-3420dc6b3c7c	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	20000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41418	2026-03-03 07:44:55.548621
60debd86-32f6-43b7-a2ec-6b1e11e3b963	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	18000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414177	2026-03-03 07:44:55.551289
ce2359e0-3da1-429c-aa3b-ebdbe33be337	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-05	1120000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414174	2026-03-03 07:44:55.554076
80d8da65-7ebb-4df1-8b97-492493fb0567	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	2000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41417	2026-03-03 07:44:55.557537
20979edb-8aaf-4341-942a-6b5ce413b7d6	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	600000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414167	2026-03-03 07:44:55.560108
8f289eaa-648b-44e7-9854-967a3e24566f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-04	17540000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414152	2026-03-03 07:44:55.562744
b4895376-0424-488b-b35e-a7764134c295	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-04	11650000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414148	2026-03-03 07:44:55.565379
cdc8cecc-1c75-42f8-b4b8-d42bb62e0d13	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	1500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414145	2026-03-03 07:44:55.567943
bce29dc0-32c9-42de-bf0a-23bb1860ba7a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-04	8500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414141	2026-03-03 07:44:55.570449
048e9ccf-0bd2-48d7-8b61-d98a503a62b5	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	1325000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414137	2026-03-03 07:44:55.572993
bb56a7e9-edd2-4f66-9e97-6163a0e2186a	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-03	7720000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414134	2026-03-03 07:44:55.575524
ad387181-4e53-425e-97b0-9ffefa2023be	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-11-03	16025000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414131	2026-03-03 07:44:55.578041
bfa83ed8-eb76-46a0-a513-e627f4e3f114	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	15000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414128	2026-03-03 07:44:55.58056
932dd910-2b21-424a-a0ad-8b8d447ad8bd	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-11-03	12420000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414124	2026-03-03 07:44:55.583009
93afb183-18c2-409f-a423-6528d68adcd9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	3740000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414121	2026-03-03 07:44:55.585603
0ec7350c-7dc1-482a-90b6-d58d098871b8	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-30	11420000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414118	2026-03-03 07:44:55.588077
89ae0527-63cf-4a4e-a1d8-7b29f2a1b587	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	10000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414115	2026-03-03 07:44:55.590578
0c9fad9d-ffac-4532-b5bf-e30d8b576f8b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	1120000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414112	2026-03-03 07:44:55.59329
acd0a66e-449c-4524-a698-9d7b1aab942b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	6560000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414108	2026-03-03 07:44:55.595712
6f3ed7d4-1683-4072-8108-07ade22f8151	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-30	4950000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414105	2026-03-03 07:44:55.598197
65a1f4db-fc99-4a47-bb4b-074a11cd6906	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	920000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414102	2026-03-03 07:44:55.600641
068037f2-c422-4444-8790-a416c9b8cb5c	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-29	4950000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414099	2026-03-03 07:44:55.60327
8f8068d8-b8f5-4f30-a53b-6a15dab6af48	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-29	17945000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414095	2026-03-03 07:44:55.605733
32e1c07c-c22d-4f13-a1ef-a25b9a62bf4b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	6925000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414092	2026-03-03 07:44:55.608199
56e0e936-16b8-4c79-acba-b1cf3865a048	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	10000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414089	2026-03-03 07:44:55.610615
93459bdc-d6bb-4f8f-894c-c315c0a9700b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-29	6155000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414085	2026-03-03 07:44:55.613258
f159642f-34e5-4e5f-8cc8-306c47a0c6e2	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-28	10150000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414082	2026-03-03 07:44:55.61573
25669357-8856-4a9a-b65e-f81502f4d958	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-27	6030000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414079	2026-03-03 07:44:55.618214
1729b5f6-eb46-4295-a395-dfb7514e97fd	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-27	2035000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414075	2026-03-03 07:44:55.621493
cf28b119-79f9-4b4d-a61b-a50a5d540bfb	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	10190000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414072	2026-03-03 07:44:55.624085
a1c2c99d-3280-48f0-872a-dc18b347e31f	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	10950000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414069	2026-03-03 07:44:55.626671
e1fc1035-e6b1-4ca2-8f5a-7f96a1ad3ad6	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	5080000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414066	2026-03-03 07:44:55.629215
ccb9ecea-f12c-480c-bc99-8645be0dbe35	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	10190000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414062	2026-03-03 07:44:55.631684
2cd6a530-aae9-433e-9bc9-b73c0a99e503	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	24060000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414059	2026-03-03 07:44:55.634252
6e6aa5ea-3be6-412e-8c4b-b06dee33327d	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	25270000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414056	2026-03-03 07:44:55.636777
d364bc19-7d68-4ca5-a3f3-571575619c42	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	6970000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414053	2026-03-03 07:44:55.639264
ef63c971-2c6c-4baf-a32c-4fc5e6a64153	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-24	8080000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414049	2026-03-03 07:44:55.641782
c56cb135-3c7b-4d92-9ff3-307ceb5eb102	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	50000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414046	2026-03-03 07:44:55.644319
dcc7944d-cf48-4f02-bff8-68c031784ab0	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	19120000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414043	2026-03-03 07:44:55.646858
c2c9f587-53a6-4e4c-a4f4-211a75488fd8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-24	47010000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414039	2026-03-03 07:44:55.649383
ac8234fd-781e-4cdb-99ef-eabbb7c19c05	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-23	2870000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414036	2026-03-03 07:44:55.651819
ce899d99-ccc3-4f62-9f3c-6d459998d170	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-23	24990000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414033	2026-03-03 07:44:55.654366
580d324e-dbd7-4a23-ba16-fdf6d25687f4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-23	47010000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414029	2026-03-03 07:44:55.656829
ba516449-fd29-4264-af12-9b9ac3a64b1b	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-23	5320000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414026	2026-03-03 07:44:55.65927
092a075c-dbb7-488a-96cc-82d379a8ee6d	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	310000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414023	2026-03-03 07:44:55.661768
fb1d4b4e-44f9-42b5-93af-480fa5d79e04	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	18040000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414019	2026-03-03 07:44:55.664448
b7c33e53-036d-4eb4-af58-a8f839e91ee4	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-22	24660000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414016	2026-03-03 07:44:55.667005
e2311bd0-55dd-496c-b4a7-a893ac8d1f7a	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-22	30310000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414013	2026-03-03 07:44:55.669581
ad8c15e0-02f8-4549-8179-83c562b526e1	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	990000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.41401	2026-03-03 07:44:55.672256
433c59f5-7f9c-4ef1-942b-0b963b420a1f	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	10230000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414006	2026-03-03 07:44:55.674942
677fdf5f-ee97-4712-af38-4d35754dd6d1	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	9870000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.414003	2026-03-03 07:44:55.67752
43e45027-9351-44c9-807d-d48b20354337	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-21	22810000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413999	2026-03-03 07:44:55.680066
50775f85-2ec6-4700-b3bd-b34cef630509	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	15000000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413996	2026-03-03 07:44:55.682793
6d85b99f-51ac-4c88-b317-a6748b787b03	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-21	5500000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413993	2026-03-03 07:44:55.685442
85fc5b10-aed7-4961-9b4b-7648df6bdca9	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	600000.00	0.00	반입	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413988	2026-03-03 07:44:55.688775
29576ca7-da0c-4cc6-a15b-a6d2fe59b899	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-20	9760000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413984	2026-03-03 07:44:55.691375
b32dd438-5102-462d-ba55-b925e7f75a0b	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-20	34820000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413981	2026-03-03 07:44:55.694026
9fbd7549-175a-4439-8c55-61907808dcc8	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	4260000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413977	2026-03-03 07:44:55.696613
e482593b-a7b0-4d1a-94a8-e607e72a1462	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-20	34820000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413974	2026-03-03 07:44:55.699144
dab505b6-c04d-4b01-b897-3c2ccb1a5535	6eb1110b-8ec8-487c-9a82-e2442663d029	WITHDRAWAL	2025-10-17	14450000.00	0.00	판매	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413967	2026-03-03 07:44:55.701697
9c8905cc-dce6-4cac-8c35-46cde758588e	6eb1110b-8ec8-487c-9a82-e2442663d029	DEPOSIT	2025-10-17	14450000.00	0.00	현금	MANUAL	\N	\N	\N	CANCELLED	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	2026-03-03 07:42:45.413958	2026-03-03 07:44:55.704415
\.


--
-- Data for Name: deduction_items; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.deduction_items (id, name, description, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deduction_levels; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.deduction_levels (id, item_id, name, amount, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grade_prices; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.grade_prices (id, model_id, grade_id, price, applied_at, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.grades (id, name, description, sort_order, is_active, is_default, created_at, updated_at) FROM stdin;
2a408257-9c92-4c71-8161-5b8d12ba89c4	A+	\N	1	t	t	2026-03-03 03:45:43.512188	2026-03-03 03:45:43.512192
cee2cf94-10c3-4cfb-ba33-093500fe8266	A	\N	2	t	f	2026-03-03 03:45:43.5122	2026-03-03 03:45:43.512201
d62bfa81-f6a5-49ce-b693-f081789525e2	A-	\N	3	t	f	2026-03-03 03:45:43.512214	2026-03-03 03:45:43.512215
fe3ef5d5-8193-4e4b-8946-227697cbed37	B+	\N	4	t	f	2026-03-03 03:45:43.512222	2026-03-03 03:45:43.512223
06c732cb-6284-4f5a-8140-28bebfddae6f	B	\N	5	t	f	2026-03-03 03:45:43.512229	2026-03-03 03:45:43.51223
dff67739-90ae-495e-bab3-e87a88d13231	B-	\N	6	t	f	2026-03-03 03:45:43.512236	2026-03-03 03:45:43.512237
d4238379-0c8c-40a4-9396-204a20461e32	C	\N	7	t	f	2026-03-03 03:45:43.512244	2026-03-03 03:45:43.512245
f76baec2-2729-4985-b1cc-caa270c24c53	수출	\N	8	t	f	2026-03-03 03:45:43.51225	2026-03-03 03:45:43.512251
71dd1488-5b06-4eec-bc1c-80d11b7c76bf	기타	\N	9	t	f	2026-03-03 03:45:43.512257	2026-03-03 03:45:43.512257
\.


--
-- Data for Name: hq_price_applies; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.hq_price_applies (id, upload_job_id, version, memo, applied_count, price_changes, applied_by, applied_at, is_current) FROM stdin;
\.


--
-- Data for Name: hq_price_apply_locks; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.hq_price_apply_locks (id, is_locked, locked_by, locked_at, lock_reason) FROM stdin;
\.


--
-- Data for Name: netting_records; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.netting_records (id, counterparty_id, netting_date, netting_amount, status, memo, created_by, confirmed_by, confirmed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: netting_voucher_links; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.netting_voucher_links (id, netting_record_id, voucher_id, netted_amount, created_at) FROM stdin;
\.


--
-- Data for Name: partner_mappings; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partner_mappings (id, partner_id, model_id, partner_expression, confidence, is_manual, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: partner_prices; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partner_prices (id, partner_id, model_id, grade_id, price, uploaded_at, upload_job_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.partners (id, name, region, contact_info, memo, branch_id, is_active, deleted_at, deleted_by, delete_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.payments (id, voucher_id, payment_date, amount, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: period_locks; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.period_locks (id, year_month, status, locked_voucher_count, locked_at, locked_by, unlocked_at, unlocked_by, memo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.receipts (id, voucher_id, receipt_date, amount, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: ssot_models; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.ssot_models (id, model_key, model_code, device_type, manufacturer, series, model_name, storage_gb, connectivity, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_allocations; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.transaction_allocations (id, transaction_id, voucher_id, allocated_amount, allocation_order, memo, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: upload_jobs; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.upload_jobs (id, job_type, status, progress, file_path, original_filename, file_hash, partner_id, created_by, result_summary, error_message, is_reviewed, is_confirmed, is_applied, created_at, started_at, completed_at, confirmed_at, applied_at) FROM stdin;
c43a4227-25e4-49ec-aca6-052a258bcd58	VOUCHER_SALES_EXCEL	SUCCEEDED	100	uploads/settlement/48f2d80d-d3fa-4dfd-a75c-0ee6ace45bf6.xlsx	판매자료(반입포함).xlsx	8c53b14b2445e7fa2addb55b4b2fe980436c166f597bd1ef03850e65cc0bd8e5	\N	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	{"confirmed": {"created": 360, "skipped": 1, "updated": 0, "change_requests": 0}, "new_count": 360, "total_rows": 361, "error_count": 0, "locked_count": 0, "update_count": 0, "conflict_count": 0, "excluded_count": 1, "unmatched_count": 0, "unmatched_names": [], "column_mapping_used": {"memo": "비고", "profit": "손익", "as_cost": "A/S비용", "quantity": "수량", "avg_margin": "평균마진", "trade_date": "판매일", "profit_rate": "수익율", "sale_amount": "판매금액", "purchase_cost": "매입원가", "sale_deduction": "판매차감", "voucher_number": "번호", "actual_sale_price": "실판매가", "counterparty_name": "판매처", "purchase_deduction": "매입차감", "actual_purchase_price": "실매입가"}, "header_row_detected": 1}	\N	f	t	f	2026-03-03 08:38:42.306838	2026-03-03 08:38:44.139686	2026-03-03 08:38:44.855841	2026-03-03 08:39:06.059426	\N
09ac4801-1570-491f-b4b3-67c0e3773601	VOUCHER_SALES_EXCEL	SUCCEEDED	100	uploads/settlement/725ebb83-aff8-483b-9d5d-79c439bf7023.xlsx	판매자료(반입포함).xlsx	8c53b14b2445e7fa2addb55b4b2fe980436c166f597bd1ef03850e65cc0bd8e5	\N	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	{"new_count": 0, "total_rows": 361, "error_count": 0, "locked_count": 0, "update_count": 0, "conflict_count": 0, "excluded_count": 1, "unmatched_count": 360, "unmatched_names": ["엔터프라이즈(평택)", "아이온코리아", "윈윈사장님", "네오홀딩스(오주석)", "아프리카 중고폰", "에스텔", "허랑(IBS)", "누랄리(키르기스탄)", "균호 사장님", "필리핀(연합)", "베트남 중(수원)", "이브로힘(우즈백)", "소미트헌(우즈백)", "네이버스토어", "리퍼마켓(B2B)", "추가금(온라인)", "에코트레이드", "산하울라(압둘라동생)", "오재", "김하나", "옥션", "베트남 지사", "엔터프라이즈(당진)", "박팀장", "아심(두바이)", "문승현 (피지)", "광주 팔구사구", "베트남 홍손", "볼트테크", "다원", "중고나라", "HSH", "레이컴", "광주(sj컴퍼니)", "지덕", "다원 성준", "오에스티이씨에이치(홍대)", "쿠팡(대단한)", "뉴퍼마켓(대단한)", "폰테이너", "애플박사", "아초", "마삽", "앤디", "올웨이즈(다원)", "오사장님", "요크헤이븐 코리아", "11번가", "박걸", "어기(몽골)", "아정당", "W무역", "옥션(대단한)", "ANCOM(홍콩)", "STK-PK", "호두모바일", "에이블리4910", "자이드(미얀마)", "리씽크", "수리실(작업)", "김태연(베트남)", "폰가비(업스테어스)", "쿠팡(엘씨오씨)", "카카오쇼핑", "지마켓 (대단한)", "바이라(몽골)", "권영환(외부)", "솝다(몽골)", "미니", "이사장님", "김조아(우즈백)", "콕딜", "KREAM(금화)", "아부바크르", "떠리몰", "토스쇼핑", "마블", "지마켓(대단한)", "임태종(스든코퍼레이션)", "폰박스", "쿠팡(리플립)", "홍이(박걸)", "살람", "쿠팡", "11번가(대단한)", "스마트M", "인스코리아", "정엽 사장님", "뉴퍼마켓(다원)", "에코폰 상암점", "홍부희 사장님", "아이즈모바일", "네이버스토어(대단한)", "지마켓", "T딜", "STK.카림"], "column_mapping_used": {"memo": "비고", "profit": "손익", "as_cost": "A/S비용", "quantity": "수량", "avg_margin": "평균마진", "trade_date": "판매일", "profit_rate": "수익율", "sale_amount": "판매금액", "purchase_cost": "매입원가", "sale_deduction": "판매차감", "voucher_number": "번호", "actual_sale_price": "실판매가", "counterparty_name": "판매처", "purchase_deduction": "매입차감", "actual_purchase_price": "실매입가"}, "header_row_detected": 1}	\N	f	f	f	2026-03-03 07:28:27.141151	2026-03-03 07:28:31.345877	2026-03-03 07:28:32.208039	\N	\N
\.


--
-- Data for Name: upload_templates; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.upload_templates (id, name, voucher_type, column_mapping, skip_columns, is_default, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_counterparty_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_counterparty_favorites (id, user_id, counterparty_id, created_at) FROM stdin;
2004750b-8cc9-4d94-a0a7-0d587a628e11	2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	6eb1110b-8ec8-487c-9a82-e2442663d029	2026-03-03 07:42:53.97478
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_favorites (id, user_id, model_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_list_items; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_list_items (id, list_id, model_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_lists; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_lists (id, user_id, name, description, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_partner_favorites; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.user_partner_favorites (id, user_id, partner_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at, last_login_at) FROM stdin;
0445d86e-f791-4dad-baec-5f91deb57adc	admin@example.com	$2b$12$jc7/bU1kF5FqQsHjpAhq4Okl3V4I1r0ruJTS6b9.0HfbqRyNBYmwS	관리자	ADMIN	t	2026-03-03 03:45:43.501654	2026-03-03 05:30:35.693239	2026-03-03 05:30:35.692523
2c4e5aa1-bb2d-4b77-9813-2d4dbed6111d	skp10216@gmail.com	$2b$12$i8FkV7NUIgdc2Hm1rnEdvuBERh6aHr0qd5W1AQt.io.KR6rvUKMWK	skp10216	ADMIN	t	2026-03-03 05:30:36.011157	2026-03-03 07:29:36.538107	2026-03-03 07:29:36.537364
d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	oys@dwt.kr	$2b$12$ckjUh36vsc7pjppgzKB4BOWpEay.dBb43P8SCLWNPEb5vtehg.38a	오유선	ADMIN	t	2026-03-03 07:36:59.756935	2026-03-03 08:38:01.606361	2026-03-03 08:38:01.604443
\.


--
-- Data for Name: voucher_change_requests; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.voucher_change_requests (id, voucher_id, upload_job_id, before_data, after_data, diff_summary, status, reviewed_by, review_memo, created_at, reviewed_at) FROM stdin;
\.


--
-- Data for Name: vouchers; Type: TABLE DATA; Schema: public; Owner: dwt_user
--

COPY public.vouchers (id, trade_date, counterparty_id, voucher_number, voucher_type, quantity, total_amount, purchase_cost, actual_purchase_price, deduction_amount, avg_unit_price, upm_settlement_status, payment_info, purchase_deduction, as_cost, sale_amount, sale_deduction, actual_sale_price, profit, profit_rate, avg_margin, is_adjustment, adjustment_type, original_voucher_id, adjustment_reason, settlement_status, payment_status, memo, upload_job_id, created_by, created_at, updated_at) FROM stdin;
dc38826b-1554-4ac5-ab32-4add3bc90d83	2026-02-01	23c41e48-2784-4cd8-a920-ab87165b72bb	3	SALES	41	11200000.00	10547000.00	10716000.00	\N	\N	\N	\N	169000.00	\N	13200000.00	\N	11200000.00	484000.00	4.52	11805.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082741	2026-03-03 08:39:06.082744
f6a3694e-2c43-435c-b629-8d9deb9333cc	2026-02-02	5d46a0d1-11ac-4931-9582-e07495cb0eca	28	SALES	8	1715000.00	1596000.00	1591000.00	\N	\N	\N	\N	-5000.00	\N	1715000.00	\N	1715000.00	124000.00	7.79	15500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082749	2026-03-03 08:39:06.082749
470d0a80-1e80-46e1-a3db-ced9758f3b5c	2026-02-02	adc46688-90df-4d93-a5d4-1a34ceeae403	30	SALES	127	54279500.00	45033000.00	51106000.00	\N	\N	\N	\N	6073000.00	\N	54869500.00	-590000.00	54279500.00	3173500.00	6.21	24988.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082753	2026-03-03 08:39:06.082753
3b1ad341-efd6-4c7f-88b8-b679476d19d6	2026-02-02	adc46688-90df-4d93-a5d4-1a34ceeae403	35	SALES	5	3450000.00	2854000.00	3264000.00	\N	\N	\N	\N	-60000.00	470000.00	3520000.00	-70000.00	3450000.00	186000.00	5.70	37200.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082757	2026-03-03 08:39:06.082757
3c96dc96-3409-474c-a469-b188cfb48b2c	2026-02-02	adc46688-90df-4d93-a5d4-1a34ceeae403	36	SALES	25	16450000.00	13777000.00	15802000.00	\N	\N	\N	\N	2025000.00	\N	16700000.00	-250000.00	16450000.00	648000.00	4.10	25920.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082761	2026-03-03 08:39:06.082761
0ba04332-e05f-4b5c-b39b-97c618bedfe0	2026-02-02	adc46688-90df-4d93-a5d4-1a34ceeae403	37	SALES	21	3705000.00	3426000.00	3575000.00	\N	\N	\N	\N	149000.00	\N	3705000.00	\N	3705000.00	130000.00	3.64	6190.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082764	2026-03-03 08:39:06.082765
353c6f33-03b2-46be-a363-2cea8b4f8e07	2026-02-02	a4a4a6fc-6f9a-4f5f-9382-88ea5e0102d6	38	SALES	22	7695000.00	5923000.00	7303000.00	\N	\N	\N	\N	1370000.00	10000.00	7695000.00	\N	7695000.00	392000.00	5.37	17818.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082768	2026-03-03 08:39:06.082769
4fe41047-9663-4624-939a-c8c07bf5be25	2026-02-02	fb8a00d5-c7ff-4553-bda5-d33f31772db8	39	SALES	55	16830000.00	16327000.00	16899000.00	\N	\N	\N	\N	532000.00	40000.00	16830000.00	\N	16830000.00	-69000.00	-0.41	-1255.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082772	2026-03-03 08:39:06.082773
8f71bb1e-1a6e-42b7-a633-55db6337c9fc	2026-02-02	7db3adcd-ecaf-40d9-9e09-13c6dc53cc14	46	SALES	21	9410000.00	8566000.00	8961000.00	\N	\N	\N	\N	325000.00	70000.00	9410000.00	\N	9410000.00	449000.00	5.01	21381.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082776	2026-03-03 08:39:06.082776
3c98675d-7d90-4483-8b57-a323121517d8	2026-02-02	adc46688-90df-4d93-a5d4-1a34ceeae403	53	SALES	1	1000000.00	1000000.00	1000000.00	\N	\N	\N	\N	\N	\N	1000000.00	\N	1000000.00	\N	\N	\N	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08278	2026-03-03 08:39:06.08278
343d0292-a921-4a2e-8b32-6bdc1f33b93a	2026-02-02	6eb1110b-8ec8-487c-9a82-e2442663d029	60	SALES	39	12795000.00	11958000.00	12066000.00	\N	\N	\N	\N	88000.00	20000.00	12795000.00	\N	12795000.00	729000.00	6.04	18692.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082784	2026-03-03 08:39:06.082784
6468d344-3cb7-4fc0-adf3-d5e018d16334	2026-02-02	6eb1110b-8ec8-487c-9a82-e2442663d029	71	SALES	9	2190000.00	1639000.00	2080000.00	\N	\N	\N	\N	441000.00	\N	2190000.00	\N	2190000.00	110000.00	5.29	12222.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082787	2026-03-03 08:39:06.082788
3df84d15-563e-4170-b7f0-8bce72c39913	2026-02-02	18b33efc-6a66-4bb8-8c91-75559797c118	83	SALES	13	3202121.00	2752000.00	2787000.00	\N	\N	\N	\N	35000.00	\N	3202121.00	\N	3202121.00	415121.00	14.89	31932.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082791	2026-03-03 08:39:06.082791
8261f38b-2691-4814-8776-92cafc791a31	2026-02-02	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	85	SALES	13	2189235.00	1510000.00	1592000.00	\N	\N	\N	\N	82000.00	\N	2189235.00	\N	2189235.00	597235.00	37.51	45941.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082795	2026-03-03 08:39:06.082795
f571f4dd-81cb-4520-883b-4e5fa8775957	2026-02-02	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	86	SALES	2	380924.00	313000.00	370000.00	\N	\N	\N	\N	57000.00	\N	380924.00	\N	380924.00	10924.00	2.95	5462.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082799	2026-03-03 08:39:06.082799
f7c2c73f-266e-4f6a-9f30-e72c08c21cec	2026-02-02	04be26d8-3adf-4bfe-9573-320e109c9ef7	88	SALES	1	214545.00	151000.00	171000.00	\N	\N	\N	\N	20000.00	\N	214545.00	\N	214545.00	43545.00	25.46	43545.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082802	2026-03-03 08:39:06.082803
a134e7a8-2299-4679-be15-5c942e2a1956	2026-02-02	546b9fe5-ed44-47ab-ad21-2050f33efc23	89	SALES	1	202868.00	144000.00	119000.00	\N	\N	\N	\N	-25000.00	\N	202868.00	\N	202868.00	83868.00	70.48	83868.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082806	2026-03-03 08:39:06.082806
c9060ded-b793-4a41-9ef4-4167aa2488ca	2026-02-02	18b5ef55-910e-4504-b3bd-b6c96a2eb298	91	SALES	4	2139229.00	1782000.00	1782000.00	\N	\N	\N	\N	\N	\N	2139229.00	\N	2139229.00	357229.00	20.05	89307.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08281	2026-03-03 08:39:06.08281
4c8f5693-a0bd-4912-b269-28faadb0e915	2026-02-02	184b1cb6-5cf6-40c7-8e65-dc384e2da567	92	SALES	48	6834155.00	4899390.00	5593390.00	\N	\N	\N	\N	694000.00	\N	6834155.00	\N	6834155.00	1240765.00	22.18	25849.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082814	2026-03-03 08:39:06.082814
d8ee7604-43f8-4179-9df9-f179ae649411	2026-02-02	bf127d8e-e428-40ff-af91-d676a9d6a23f	94	SALES	22	8356909.00	7712408.00	7902408.00	\N	\N	\N	\N	180000.00	10000.00	8356909.00	\N	8356909.00	454501.00	5.75	20659.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082817	2026-03-03 08:39:06.082818
bfef1364-63a9-4dc1-a0bf-0297592fcdfd	2026-02-02	082cc299-bc65-42c6-b8b4-ceb4c0ac7430	97	SALES	1	339982.00	245000.00	245000.00	\N	\N	\N	\N	\N	\N	339982.00	\N	339982.00	94982.00	38.77	94982.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082821	2026-03-03 08:39:06.082821
e4fd026b-c38f-4efd-868e-f7e487dd1c2c	2026-02-02	c3a020ac-224d-4ba1-acf3-c2c824eb5807	99	SALES	1	189796.00	140000.00	140000.00	\N	\N	\N	\N	\N	\N	189796.00	\N	189796.00	49796.00	35.57	49796.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082825	2026-03-03 08:39:06.082825
e3626c7d-7f3c-487d-a7d1-4b41b0871754	2026-02-02	87a77c6d-5d37-4392-9e20-409c2cc3b854	100	SALES	10	4476207.00	4704112.00	4924112.00	\N	\N	\N	\N	200000.00	20000.00	4476207.00	\N	4476207.00	-447905.00	-9.10	-44791.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082828	2026-03-03 08:39:06.082829
76a74788-5e61-4b94-9026-36ba2ef77db1	2026-02-02	5b7a1424-4208-45db-b515-36bf310b8d42	103	SALES	5	277004.00	245635.00	245635.00	\N	\N	\N	\N	\N	\N	277004.00	\N	277004.00	31369.00	12.77	6274.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082832	2026-03-03 08:39:06.082832
0f25381b-5c22-413e-8b7d-7ab9d5d2bbe1	2026-02-02	e86090a3-7209-43b8-a149-c1acf99ed91f	104	SALES	1	65705.00	54727.00	54727.00	\N	\N	\N	\N	\N	\N	65705.00	\N	65705.00	10978.00	20.06	10978.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082836	2026-03-03 08:39:06.082836
258d0a62-cf70-4c0e-83fe-2c1ce9662cbf	2026-02-02	196e3761-a30c-4af1-b443-33670b8c971c	105	SALES	2	2181818.00	1800000.00	1800000.00	\N	\N	\N	\N	\N	\N	2181818.00	\N	2181818.00	381818.00	21.21	190909.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082839	2026-03-03 08:39:06.08284
409c59de-aa67-471d-95c9-7053be5cbc87	2026-02-02	bf127d8e-e428-40ff-af91-d676a9d6a23f	109	SALES	5	814091.00	725000.00	725000.00	\N	\N	\N	\N	\N	\N	814091.00	\N	814091.00	89091.00	12.29	17818.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082843	2026-03-03 08:39:06.082844
aedb0bca-d87a-450c-bd4f-dc6de9944ae5	2026-02-02	772eee3f-b282-43a0-bede-1047ad139fcf	110	SALES	21	5875000.00	4899000.00	5574000.00	\N	\N	\N	\N	675000.00	\N	5875000.00	\N	5875000.00	301000.00	5.40	14333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082848	2026-03-03 08:39:06.082848
0cc3c7de-8d9f-4df1-9bac-f170182ccc40	2026-02-02	45c13653-c3f1-4453-ab7b-f581e7b444de	111	SALES	15	3720000.00	3094000.00	3235000.00	\N	\N	\N	\N	141000.00	\N	3720000.00	\N	3720000.00	485000.00	14.99	32333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082852	2026-03-03 08:39:06.082852
c3f3c6ab-d8a8-41ea-94b7-12b7125a0590	2026-02-02	00dae90e-a6a3-4569-8a64-92c70bf34a4d	112	SALES	1	100000.00	88000.00	88000.00	\N	\N	\N	\N	\N	\N	100000.00	\N	100000.00	12000.00	13.64	12000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082855	2026-03-03 08:39:06.082856
9aa391e9-dc96-4569-a3a3-def26907db5f	2026-02-02	82c17c05-e4d9-4c83-9dea-da7b1d177363	113	SALES	10	7627000.00	6954000.00	7459000.00	\N	\N	\N	\N	505000.00	\N	7627000.00	\N	7627000.00	168000.00	2.25	16800.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082859	2026-03-03 08:39:06.08286
de32600e-058b-4400-b491-c409123045df	2026-02-02	5ac88854-845a-471c-a1d3-82673bb52489	114	SALES	7	5570000.00	5195363.00	5315363.00	\N	\N	\N	\N	60000.00	60000.00	5570000.00	\N	5570000.00	254637.00	4.79	36377.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082863	2026-03-03 08:39:06.082863
eaa44893-d6a7-48ac-9d95-a66d6a69b560	2026-02-02	4e0c76d8-9c9f-4d72-bf05-eb8e17a56e06	126	SALES	2	1320000.00	1050000.00	1095000.00	\N	\N	\N	\N	45000.00	\N	1320000.00	\N	1320000.00	225000.00	20.55	112500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082867	2026-03-03 08:39:06.082867
e4ec5c3c-91f2-44a0-9111-2548167ddbf1	2026-02-02	e5ba134e-9970-4b16-adbd-ae9e22f8e024	131	SALES	1	5455.00	0.00	\N	\N	\N	\N	\N	\N	\N	5455.00	\N	5455.00	5455.00	\N	5455.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08287	2026-03-03 08:39:06.082871
cc6b7d6a-739c-4983-aef2-31f597ab3ecc	2026-02-02	e5ba134e-9970-4b16-adbd-ae9e22f8e024	132	SALES	1	5455.00	0.00	\N	\N	\N	\N	\N	\N	\N	5455.00	\N	5455.00	5455.00	\N	5455.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082874	2026-03-03 08:39:06.082874
e561d702-9812-408a-866a-e6d6c5115523	2026-02-02	58a69881-1175-411a-b9c3-a73984aa504e	133	SALES	18	6565000.00	6335000.00	6375000.00	\N	\N	\N	\N	40000.00	\N	6565000.00	\N	6565000.00	190000.00	2.98	10556.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082878	2026-03-03 08:39:06.082878
0cb4b16e-49bf-4484-8e77-ad6f060083b1	2026-02-02	d9e4d59a-726e-4178-af2f-7780a62c8ff3	135	SALES	21	17005000.00	15494500.00	15968136.00	\N	\N	\N	\N	475000.00	-1364.00	17005000.00	\N	17005000.00	1036864.00	6.49	49374.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082882	2026-03-03 08:39:06.082882
efa611f7-75af-4b52-ae66-30c49bc7f76a	2026-02-02	23c41e48-2784-4cd8-a920-ab87165b72bb	136	SALES	37	8450000.00	7778000.00	7933000.00	\N	\N	\N	\N	155000.00	\N	8450000.00	\N	8450000.00	517000.00	6.52	13973.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082885	2026-03-03 08:39:06.082886
f4e0b9bb-8f9c-41d2-8138-76e088f22354	2026-02-03	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	6	SALES	19	2064767.00	1534000.00	1660000.00	\N	\N	\N	\N	126000.00	\N	2064767.00	\N	2064767.00	404767.00	24.38	21304.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082889	2026-03-03 08:39:06.08289
f64e5538-fe2c-47c2-9294-d2560593d575	2026-02-03	04be26d8-3adf-4bfe-9573-320e109c9ef7	7	SALES	7	1394107.00	1184000.00	1252000.00	\N	\N	\N	\N	68000.00	\N	1394107.00	\N	1394107.00	142107.00	11.35	20301.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082893	2026-03-03 08:39:06.082893
17a38498-bd58-4bcf-9a19-07334fee601c	2026-02-03	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	10	SALES	5	1517230.00	1193000.00	1243000.00	\N	\N	\N	\N	50000.00	\N	1517230.00	\N	1517230.00	274230.00	22.06	54846.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082897	2026-03-03 08:39:06.082897
3764077f-0ec6-4137-a4b8-68e1d158920e	2026-02-03	64673b02-2736-4a52-aabf-efb0c5410f9d	11	SALES	22	6812690.00	5853390.00	6054390.00	\N	\N	\N	\N	201000.00	\N	6812690.00	\N	6812690.00	758300.00	12.52	34468.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.0829	2026-03-03 08:39:06.082901
f9a68a5d-aa38-4e2a-9487-c1453a9eeaab	2026-02-03	546b9fe5-ed44-47ab-ad21-2050f33efc23	12	SALES	3	388328.00	270000.00	265000.00	\N	\N	\N	\N	-5000.00	\N	388328.00	\N	388328.00	123328.00	46.54	41109.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082904	2026-03-03 08:39:06.082905
5ad17479-b656-4286-bce6-d6107a88300f	2026-02-03	18b5ef55-910e-4504-b3bd-b6c96a2eb298	13	SALES	12	7592849.00	5998000.00	6488000.00	\N	\N	\N	\N	490000.00	\N	7592849.00	\N	7592849.00	1104849.00	17.03	92071.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082908	2026-03-03 08:39:06.082909
6e089776-3b19-4dcb-bb75-5cede02c9005	2026-02-03	184b1cb6-5cf6-40c7-8e65-dc384e2da567	17	SALES	112	17555205.00	13603000.00	15326000.00	\N	\N	\N	\N	1723000.00	\N	17555205.00	\N	17555205.00	2229205.00	14.55	19904.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082912	2026-03-03 08:39:06.082913
e7249a2e-529a-400f-a540-1625c9b9f000	2026-02-03	bf127d8e-e428-40ff-af91-d676a9d6a23f	18	SALES	43	14779636.00	13963520.00	14298520.00	\N	\N	\N	\N	305000.00	30000.00	14779636.00	\N	14779636.00	481116.00	3.36	11189.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082916	2026-03-03 08:39:06.082916
1fa40d21-8479-4cfe-bdff-30f9f2fc026b	2026-02-03	082cc299-bc65-42c6-b8b4-ceb4c0ac7430	21	SALES	1	284364.00	246000.00	246000.00	\N	\N	\N	\N	\N	\N	284364.00	\N	284364.00	38364.00	15.60	38364.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082919	2026-03-03 08:39:06.08292
4a6f6012-8e4c-4bc6-93c3-895d2c7cf65d	2026-02-03	a77fa567-0758-4a03-a67d-f3b22c3f4045	22	SALES	1	220091.00	195000.00	195000.00	\N	\N	\N	\N	\N	\N	220091.00	\N	220091.00	25091.00	12.87	25091.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082923	2026-03-03 08:39:06.082923
f60d9d2a-ebf8-4f86-830d-b744fff07913	2026-02-03	87a77c6d-5d37-4392-9e20-409c2cc3b854	24	SALES	33	11401024.00	9510408.00	10404408.00	\N	\N	\N	\N	844000.00	50000.00	11401024.00	\N	11401024.00	996616.00	9.58	30200.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082927	2026-03-03 08:39:06.082927
411b79d5-f5f7-4fa1-b7a5-63bc5865cab8	2026-02-03	6382e215-2506-4ff9-a0bd-babe31776f49	25	SALES	3	325000.00	226000.00	276000.00	\N	\N	\N	\N	50000.00	\N	325000.00	\N	325000.00	49000.00	17.75	16333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08293	2026-03-03 08:39:06.082931
73500041-ade7-4be1-9a68-627381ecac80	2026-02-03	772eee3f-b282-43a0-bede-1047ad139fcf	26	SALES	14	5760000.00	4966000.00	5387000.00	\N	\N	\N	\N	421000.00	\N	5760000.00	\N	5760000.00	373000.00	6.92	26643.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082934	2026-03-03 08:39:06.082934
2b1e6a04-8b14-4cad-bec2-e94735f2b1c9	2026-02-03	7ce77cb3-c864-4896-95b0-b71b8bfd5bdb	27	SALES	5	1770000.00	1422000.00	1607000.00	\N	\N	\N	\N	185000.00	\N	1770000.00	\N	1770000.00	163000.00	10.14	32600.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082938	2026-03-03 08:39:06.082938
2bb46948-8e30-4379-8e50-3bfaae50788e	2026-02-03	5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	28	SALES	1	220000.00	150000.00	185000.00	\N	\N	\N	\N	35000.00	\N	220000.00	\N	220000.00	35000.00	18.92	35000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082942	2026-03-03 08:39:06.082942
8c9f856e-0de7-44a7-80b9-82de8d25025a	2026-02-03	45c13653-c3f1-4453-ab7b-f581e7b444de	30	SALES	20	5225000.00	4311000.00	4388000.00	\N	\N	\N	\N	77000.00	\N	5225000.00	\N	5225000.00	837000.00	19.07	41850.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082945	2026-03-03 08:39:06.082946
0e5fa15a-c85b-4e24-a658-c181c829f7fe	2026-02-03	00dae90e-a6a3-4569-8a64-92c70bf34a4d	31	SALES	4	860000.00	649000.00	705000.00	\N	\N	\N	\N	56000.00	\N	860000.00	\N	860000.00	155000.00	21.99	38750.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082949	2026-03-03 08:39:06.082949
fd0f7e6b-e757-43fd-9e4c-a1af4891c02e	2026-02-03	7e52bf92-fcfc-448f-8bee-9e8514c03bb4	32	SALES	18	7350000.00	5850000.00	6470000.00	\N	\N	\N	\N	620000.00	\N	7350000.00	\N	7350000.00	880000.00	13.60	48889.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082953	2026-03-03 08:39:06.082953
482ff8a4-6741-44ca-876d-0c3a4b35ba07	2026-02-03	30573aa1-2438-46ab-a8c1-f93ef4303a94	67	SALES	1	330000.00	361000.00	311000.00	\N	\N	\N	\N	-50000.00	\N	330000.00	\N	330000.00	19000.00	6.11	19000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082956	2026-03-03 08:39:06.082957
aeaf6932-d244-401c-92e4-f728cd84a536	2026-02-03	cc9aa04d-07c7-4bb6-bd09-ed3dfd452816	71	SALES	4	5100000.00	4370000.00	4820000.00	\N	\N	\N	\N	450000.00	\N	5100000.00	\N	5100000.00	280000.00	5.81	70000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08296	2026-03-03 08:39:06.08296
bcb81558-5cdd-4d6c-8b55-b1294a106a31	2026-02-03	226dc0c8-617a-45ff-bc27-18ae398fc5fa	96	SALES	1	300000.00	295000.00	295000.00	\N	\N	\N	\N	\N	\N	300000.00	\N	300000.00	5000.00	1.69	5000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082964	2026-03-03 08:39:06.082964
48c10c82-1851-4a88-b7de-ef6548b4d457	2026-02-03	295052f8-3c8d-44f4-8a9d-57dcb9777ab7	99	SALES	5	345000.00	265000.00	320000.00	\N	\N	\N	\N	55000.00	\N	345000.00	\N	345000.00	25000.00	7.81	5000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082967	2026-03-03 08:39:06.082967
3637c213-9309-4f5a-9b83-00b515077e69	2026-02-03	322b6247-12d9-4cdd-a655-555744148372	105	SALES	1	950000.00	830000.00	900000.00	\N	\N	\N	\N	70000.00	\N	950000.00	\N	950000.00	50000.00	5.56	50000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082971	2026-03-03 08:39:06.082971
324c8966-40f7-4065-9748-3b78c1258a01	2026-02-03	e5ba134e-9970-4b16-adbd-ae9e22f8e024	110	SALES	1	13636.00	0.00	\N	\N	\N	\N	\N	\N	\N	13636.00	\N	13636.00	13636.00	\N	13636.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082974	2026-03-03 08:39:06.082974
770e1d0e-065a-4a64-acd6-8f460907b5ad	2026-02-03	d9e4d59a-726e-4178-af2f-7780a62c8ff3	134	SALES	10	750000.00	429000.00	656000.00	\N	\N	\N	\N	227000.00	\N	750000.00	\N	750000.00	94000.00	14.33	9400.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082978	2026-03-03 08:39:06.082978
ae0c546a-3e0c-4a4c-afa2-50edabcfdcaf	2026-02-03	dfc10db2-0295-4794-afb6-77ff8fbfd8d3	160	SALES	7	1770000.00	1487000.00	1768818.00	\N	\N	\N	\N	300000.00	-18182.00	1770000.00	\N	1770000.00	1182.00	0.07	169.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082981	2026-03-03 08:39:06.082982
2311f2db-91b6-4a13-a500-c3582907566d	2026-02-03	539627f6-0004-412c-a8bc-ebc7e9bacd50	164	SALES	24	8590000.00	7345000.00	8160000.00	\N	\N	\N	\N	815000.00	\N	8590000.00	\N	8590000.00	430000.00	5.27	17917.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082985	2026-03-03 08:39:06.082985
754b7af2-2a28-4f6c-afd3-98af837b728d	2026-02-03	c4ed6d88-ecf0-497d-bcf3-ae9370e8057b	169	SALES	4	880000.00	933000.00	700000.00	\N	\N	\N	\N	-233000.00	\N	880000.00	\N	880000.00	180000.00	25.71	45000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082988	2026-03-03 08:39:06.082989
29cbc5b0-962f-4db3-abc9-f8801257b720	2026-02-03	a8a3d02a-0a75-4282-90a8-30cc5fe498e7	178	SALES	19	2785000.00	3965000.00	2830000.00	\N	\N	\N	\N	-1290000.00	155000.00	2785000.00	\N	2785000.00	-45000.00	-1.59	-2368.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082992	2026-03-03 08:39:06.082992
4861cc39-a884-4fb5-89df-36c4604a87bc	2026-02-03	e5ba134e-9970-4b16-adbd-ae9e22f8e024	180	SALES	3	122727.00	21000.00	21000.00	\N	\N	\N	\N	\N	\N	122727.00	\N	122727.00	101727.00	484.41	33909.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082996	2026-03-03 08:39:06.082996
811dd163-2bd7-49bb-b43f-101f40b8b5d1	2026-02-03	e5ba134e-9970-4b16-adbd-ae9e22f8e024	183	SALES	1	5455.00	0.00	\N	\N	\N	\N	\N	\N	\N	5455.00	\N	5455.00	5455.00	\N	5455.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.082999	2026-03-03 08:39:06.082999
22eaa8c1-1ad1-46a5-875e-1174d2e0db0a	2026-02-03	4e0c76d8-9c9f-4d72-bf05-eb8e17a56e06	186	SALES	2	1320000.00	1032000.00	1072000.00	\N	\N	\N	\N	40000.00	\N	1320000.00	\N	1320000.00	248000.00	23.13	124000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083003	2026-03-03 08:39:06.083003
ebb5f4ea-1c65-4839-a9c2-2d2a5c46991f	2026-02-03	fe435be4-ea07-4b52-8732-15279d1f47ba	194	SALES	38	10500000.00	9470390.00	10100390.00	\N	\N	\N	\N	590000.00	40000.00	10500000.00	\N	10500000.00	399610.00	3.96	10516.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083006	2026-03-03 08:39:06.083007
b3f447dc-12a3-4384-88f8-8cfd4dfab3b2	2026-02-03	8668793e-2e5d-4fc5-a504-983dc694313a	203	SALES	55	7030000.00	5009000.00	6773000.00	\N	\N	\N	\N	1764000.00	\N	7030000.00	\N	7030000.00	257000.00	3.79	4673.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08301	2026-03-03 08:39:06.08301
85268ec7-dfd7-4603-87e0-65db5c103a2c	2026-02-03	8668793e-2e5d-4fc5-a504-983dc694313a	205	SALES	13	2340000.00	2153000.00	2243000.00	\N	\N	\N	\N	90000.00	\N	2340000.00	\N	2340000.00	97000.00	4.32	7462.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083014	2026-03-03 08:39:06.083014
8144a19a-ea1a-4b7c-9c01-b76cbe701e0d	2026-02-03	8668793e-2e5d-4fc5-a504-983dc694313a	208	SALES	19	1455000.00	970000.00	1365000.00	\N	\N	\N	\N	395000.00	\N	1455000.00	\N	1455000.00	90000.00	6.59	4737.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083017	2026-03-03 08:39:06.083018
8d5b50b3-b520-48b9-9b8d-a390fc70ae93	2026-02-03	8668793e-2e5d-4fc5-a504-983dc694313a	209	SALES	13	4430000.00	4039000.00	4139000.00	\N	\N	\N	\N	100000.00	\N	4430000.00	\N	4430000.00	291000.00	7.03	22385.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083021	2026-03-03 08:39:06.083021
261f865f-794e-4b48-8fb1-f3ff18b0ee11	2026-02-03	6eb1110b-8ec8-487c-9a82-e2442663d029	214	SALES	52	15740000.00	14090000.00	14763500.00	\N	\N	\N	\N	633500.00	40000.00	15740000.00	\N	15740000.00	976500.00	6.61	18779.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083024	2026-03-03 08:39:06.083025
2e233a6d-c716-45f9-b253-513fbae4c76e	2026-02-03	8668793e-2e5d-4fc5-a504-983dc694313a	215	SALES	22	3754000.00	3279000.00	3608000.00	\N	\N	\N	\N	329000.00	\N	3754000.00	\N	3754000.00	146000.00	4.05	6636.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083028	2026-03-03 08:39:06.083028
1ec2fba5-15f0-4cb9-8c0d-94e86f2e41cd	2026-02-03	58a69881-1175-411a-b9c3-a73984aa504e	218	SALES	52	6150000.00	5022000.00	5793000.00	\N	\N	\N	\N	771000.00	\N	6150000.00	\N	6150000.00	357000.00	6.16	6865.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083032	2026-03-03 08:39:06.083032
6c4cb389-9049-4bc6-bfb7-f1089ce8dec3	2026-02-03	23c41e48-2784-4cd8-a920-ab87165b72bb	236	SALES	43	13070000.00	12227000.00	12446000.00	\N	\N	\N	\N	219000.00	\N	13070000.00	\N	13070000.00	624000.00	5.01	14512.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083035	2026-03-03 08:39:06.083036
683c5859-5c62-4655-8bba-6e1f888b5c9e	2026-02-03	b9132696-b6b9-4d5a-a959-659676233f24	237	SALES	70	17783760.00	18765000.00	17900000.00	\N	\N	\N	\N	-865000.00	\N	18420160.00	-636400.00	17783760.00	-116240.00	-0.65	-1661.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083039	2026-03-03 08:39:06.083039
450fa1f4-12dc-49f8-ab62-89c78f00124b	2026-02-03	b9132696-b6b9-4d5a-a959-659676233f24	239	SALES	28	4605920.00	4934000.00	4514000.00	\N	\N	\N	\N	-420000.00	\N	5405920.00	-800000.00	4605920.00	91920.00	2.04	3283.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083042	2026-03-03 08:39:06.083043
4237f58a-a279-465f-a4c7-2250f50fc08c	2026-02-03	b9132696-b6b9-4d5a-a959-659676233f24	240	SALES	39	2742800.00	5926000.00	2598000.00	\N	\N	\N	\N	-3328000.00	\N	2842800.00	-100000.00	2742800.00	144800.00	5.57	3713.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083046	2026-03-03 08:39:06.083046
9e607ad5-eacf-4df2-98e2-f4d5424792bf	2026-02-03	b9132696-b6b9-4d5a-a959-659676233f24	243	SALES	34	19428730.00	16720000.00	18475000.00	\N	\N	\N	\N	1570000.00	185000.00	19534080.00	-105350.00	19428730.00	953730.00	5.16	28051.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083049	2026-03-03 08:39:06.08305
9416006d-02db-426c-8aad-3c8f0f0db7f7	2026-02-03	30573aa1-2438-46ab-a8c1-f93ef4303a94	253	SALES	21	5595000.00	4910000.00	5320000.00	\N	\N	\N	\N	400000.00	10000.00	5595000.00	\N	5595000.00	275000.00	5.17	13095.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083053	2026-03-03 08:39:06.083053
596c4b86-68c6-41a0-926a-0a92d3670bda	2026-02-04	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	22	SALES	12	4390902.00	3630000.00	3790000.00	\N	\N	\N	\N	160000.00	\N	4390902.00	\N	4390902.00	600902.00	15.85	50075.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083057	2026-03-03 08:39:06.083057
707ab1cd-71be-4fb7-9729-3e8263d9222c	2026-02-04	04be26d8-3adf-4bfe-9573-320e109c9ef7	23	SALES	6	1095079.00	993000.00	1032000.00	\N	\N	\N	\N	39000.00	\N	1095079.00	\N	1095079.00	63079.00	6.11	10513.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08306	2026-03-03 08:39:06.08306
9b3dc201-2417-4599-b0e6-08793489685e	2026-02-04	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	24	SALES	4	884719.00	680000.00	740000.00	\N	\N	\N	\N	60000.00	\N	884719.00	\N	884719.00	144719.00	19.56	36180.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083064	2026-03-03 08:39:06.083064
0003fde9-96d9-46b5-bc04-75bdc891ecaa	2026-02-04	64673b02-2736-4a52-aabf-efb0c5410f9d	25	SALES	11	3919353.00	3431000.00	3508000.00	\N	\N	\N	\N	77000.00	\N	3919353.00	\N	3919353.00	411353.00	11.73	37396.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083067	2026-03-03 08:39:06.083068
25f65bdf-1bd1-4e1b-bb00-d8c686b17855	2026-02-04	67b38c33-88a8-4c33-afcd-fa18220875ce	28	SALES	7	5300000.00	4429000.00	4924453.00	\N	\N	\N	\N	-20000.00	515453.00	5300000.00	\N	5300000.00	375547.00	7.63	53650.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083071	2026-03-03 08:39:06.083071
1d1a2b4d-6b7b-4e26-b5db-581a1aeebf06	2026-02-04	18b5ef55-910e-4504-b3bd-b6c96a2eb298	29	SALES	6	2937076.00	2196800.00	2406800.00	\N	\N	\N	\N	210000.00	\N	2937076.00	\N	2937076.00	530276.00	22.03	88379.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083075	2026-03-03 08:39:06.083075
b7cc0f09-94ed-4df9-ad18-40dc318171e7	2026-02-04	184b1cb6-5cf6-40c7-8e65-dc384e2da567	32	SALES	34	5542570.00	4044000.00	4576000.00	\N	\N	\N	\N	532000.00	\N	5542570.00	\N	5542570.00	966570.00	21.12	28429.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083078	2026-03-03 08:39:06.083079
a05a7132-3a8b-48a1-8c26-a0db353107ca	2026-02-04	bf127d8e-e428-40ff-af91-d676a9d6a23f	34	SALES	11	2856273.00	2560704.00	2740704.00	\N	\N	\N	\N	180000.00	\N	2856273.00	\N	2856273.00	115569.00	4.22	10506.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083082	2026-03-03 08:39:06.083082
426e2e4d-ce58-4d48-9aa9-ac8b10e60cde	2026-02-04	87a77c6d-5d37-4392-9e20-409c2cc3b854	36	SALES	14	6169070.00	6115112.00	6350112.00	\N	\N	\N	\N	235000.00	\N	6169070.00	\N	6169070.00	-181042.00	-2.85	-12932.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083085	2026-03-03 08:39:06.083086
f13e61be-8529-4a2f-b650-11b13375bcf9	2026-02-04	c3a020ac-224d-4ba1-acf3-c2c824eb5807	38	SALES	2	474709.00	421000.00	406000.00	\N	\N	\N	\N	-15000.00	\N	474709.00	\N	474709.00	68709.00	16.92	34355.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083089	2026-03-03 08:39:06.083089
70f8dd25-809f-4139-bc7a-ff068ac0df2e	2026-02-04	6382e215-2506-4ff9-a0bd-babe31776f49	39	SALES	1	115000.00	53000.00	85000.00	\N	\N	\N	\N	32000.00	\N	115000.00	\N	115000.00	30000.00	35.29	30000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083093	2026-03-03 08:39:06.083093
74d27c8e-7e08-4fd1-971e-1420ad3286cd	2026-02-04	5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	41	SALES	2	675000.00	530000.00	640000.00	\N	\N	\N	\N	110000.00	\N	675000.00	\N	675000.00	35000.00	5.47	17500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083096	2026-03-03 08:39:06.083096
20c124fd-dc2b-49fe-a47c-21ced2b9ef44	2026-02-04	772eee3f-b282-43a0-bede-1047ad139fcf	42	SALES	10	3935000.00	3261000.00	3568000.00	\N	\N	\N	\N	307000.00	\N	3935000.00	\N	3935000.00	367000.00	10.29	36700.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.0831	2026-03-03 08:39:06.0831
0827fcd6-eb94-4d00-a335-ea6642bc5891	2026-02-04	7ce77cb3-c864-4896-95b0-b71b8bfd5bdb	43	SALES	1	810000.00	700000.00	780000.00	\N	\N	\N	\N	80000.00	\N	810000.00	\N	810000.00	30000.00	3.85	30000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083103	2026-03-03 08:39:06.083103
24d1dc41-8909-4378-bb91-eee6914aa04f	2026-02-04	9c66af2a-0eaa-40d6-a87c-5a4fe001c857	44	SALES	13	12824700.00	10765000.00	11860000.00	\N	\N	\N	\N	1075000.00	20000.00	12824700.00	\N	12824700.00	964700.00	8.13	74208.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083107	2026-03-03 08:39:06.083107
3b9be2e1-1b11-4196-873e-41d8ba3eb28b	2026-02-04	9c66af2a-0eaa-40d6-a87c-5a4fe001c857	45	SALES	13	13177400.00	11315000.00	12130000.00	\N	\N	\N	\N	795000.00	20000.00	13177400.00	\N	13177400.00	1047400.00	8.63	80569.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08311	2026-03-03 08:39:06.083111
ba65c68e-dc28-4d17-b4a5-5d75338f3936	2026-02-04	45c13653-c3f1-4453-ab7b-f581e7b444de	47	SALES	11	2270000.00	1783000.00	2153000.00	\N	\N	\N	\N	370000.00	\N	2270000.00	\N	2270000.00	117000.00	5.43	10636.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083115	2026-03-03 08:39:06.083115
6e358100-3485-4419-8602-d1697f4e71be	2026-02-04	00dae90e-a6a3-4569-8a64-92c70bf34a4d	48	SALES	1	60000.00	65000.00	65000.00	\N	\N	\N	\N	\N	\N	60000.00	\N	60000.00	-5000.00	-7.69	-5000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083119	2026-03-03 08:39:06.083119
c53744dc-ab64-428e-afae-c7957184dbcc	2026-02-04	7e52bf92-fcfc-448f-8bee-9e8514c03bb4	49	SALES	3	1550000.00	1306000.00	1341000.00	\N	\N	\N	\N	35000.00	\N	1550000.00	\N	1550000.00	209000.00	15.59	69667.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083122	2026-03-03 08:39:06.083123
67cb8bc2-0840-4c0a-9681-7bf7d512b69c	2026-02-04	5ac88854-845a-471c-a1d3-82673bb52489	51	SALES	8	6010000.00	5162000.00	5792000.00	\N	\N	\N	\N	630000.00	\N	6010000.00	\N	6010000.00	218000.00	3.76	27250.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083126	2026-03-03 08:39:06.083126
255e0c18-5228-4789-8281-63df7582b796	2026-02-04	923f7434-4e13-44f7-bc87-ed5c7a7dbf12	52	SALES	2	245000.00	119000.00	191000.00	\N	\N	\N	\N	72000.00	\N	245000.00	\N	245000.00	54000.00	28.27	27000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083129	2026-03-03 08:39:06.08313
48973e44-b6fb-4ed2-aecc-c79884fb96d0	2026-02-04	964e5f21-bec6-4158-a95d-3e380a12eb6e	57	SALES	24	13310000.00	12043000.00	12513000.00	\N	\N	\N	\N	410000.00	60000.00	13310000.00	\N	13310000.00	797000.00	6.37	33208.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083133	2026-03-03 08:39:06.083133
97b20e1c-56c0-4360-b004-9883329deab1	2026-02-04	c4ed6d88-ecf0-497d-bcf3-ae9370e8057b	65	SALES	2	180000.00	375000.00	82000.00	\N	\N	\N	\N	-293000.00	\N	180000.00	\N	180000.00	98000.00	119.51	49000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083136	2026-03-03 08:39:06.083137
63aab0e5-3f9b-4890-96f2-8218ec224409	2026-02-04	1567a26e-599b-47e7-bd3c-55e435ff8d2d	68	SALES	2	750000.00	772000.00	742000.00	\N	\N	\N	\N	-30000.00	\N	750000.00	\N	750000.00	8000.00	1.08	4000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08314	2026-03-03 08:39:06.08314
09a49f32-103c-434f-bb67-1c40f48f0182	2026-02-04	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	97	SALES	1	0.00	1025709.00	1025709.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	-1025709.00	-100.00	-1025709.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083143	2026-03-03 08:39:06.083144
cc65cd3d-f19a-4118-8c16-ab277790b4cd	2026-02-04	3894796d-c426-46cc-adb5-3628b464657b	101	SALES	1	450000.00	425000.00	450000.00	\N	\N	\N	\N	25000.00	\N	450000.00	\N	450000.00	\N	\N	\N	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083147	2026-03-03 08:39:06.083147
9957c4fc-8940-4291-9549-d436ae2d857e	2026-02-04	fb8a00d5-c7ff-4553-bda5-d33f31772db8	148	SALES	39	14060000.00	12848000.00	12848000.00	\N	\N	\N	\N	\N	\N	15660000.00	-1600000.00	14060000.00	1212000.00	9.43	31077.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083151	2026-03-03 08:39:06.083151
a8534fec-4038-45ae-941c-a12226e1c5da	2026-02-04	30573aa1-2438-46ab-a8c1-f93ef4303a94	169	SALES	10	5695000.00	5541000.00	5631000.00	\N	\N	\N	\N	90000.00	\N	5695000.00	\N	5695000.00	64000.00	1.14	6400.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083208	2026-03-03 08:39:06.083208
87ca6b8f-a46a-48aa-9297-e4d19c501bb4	2026-02-04	0be3ba2e-83f7-4588-abde-25ceae9e6ee3	182	SALES	7	2135000.00	1715000.00	1872000.00	\N	\N	\N	\N	147000.00	10000.00	2135000.00	\N	2135000.00	263000.00	14.05	37571.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083214	2026-03-03 08:39:06.083214
4c86b19f-5755-4a50-9107-0c456aa1e157	2026-02-04	adc46688-90df-4d93-a5d4-1a34ceeae403	195	SALES	138	72670000.00	51103000.00	59760000.00	\N	\N	\N	\N	8627000.00	30000.00	74395000.00	-1725000.00	72670000.00	12910000.00	21.60	93551.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083219	2026-03-03 08:39:06.083219
55ba4a68-6f2b-4633-9287-c5d63b145cc8	2026-02-04	adc46688-90df-4d93-a5d4-1a34ceeae403	197	SALES	50	32015000.00	24417500.00	30812500.00	\N	\N	\N	\N	6355000.00	40000.00	32905000.00	-890000.00	32015000.00	1202500.00	3.90	24050.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083234	2026-03-03 08:39:06.083235
2b3d7924-0c1e-4347-93ed-5197bde35aec	2026-02-04	adc46688-90df-4d93-a5d4-1a34ceeae403	198	SALES	18	15710000.00	13563000.00	14508000.00	\N	\N	\N	\N	895000.00	50000.00	15760000.00	-50000.00	15710000.00	1202000.00	8.29	66778.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083239	2026-03-03 08:39:06.083239
cb5f0a7e-505e-4dad-8e76-2a17a2e27443	2026-02-04	adc46688-90df-4d93-a5d4-1a34ceeae403	199	SALES	29	11865000.00	10304390.00	12074390.00	\N	\N	\N	\N	1770000.00	\N	12365000.00	-500000.00	11865000.00	-209390.00	-1.73	-7220.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083242	2026-03-03 08:39:06.083242
f10395fd-8ee2-49e4-9599-9e814f1863e7	2026-02-04	0f07d7f9-a1d2-41a5-89cb-0e942fd7ed22	202	SALES	21	1755000.00	1082000.00	1520000.00	\N	\N	\N	\N	438000.00	\N	1755000.00	\N	1755000.00	235000.00	15.46	11190.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083246	2026-03-03 08:39:06.083246
0318b632-cac4-4355-ae7a-bd79cdc0d7db	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	203	SALES	1	43182.00	0.00	\N	\N	\N	\N	\N	\N	\N	43182.00	\N	43182.00	43182.00	\N	43182.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083249	2026-03-03 08:39:06.08325
df061fd5-cee7-4df4-81db-e7bf74e77957	2026-02-04	fb8a00d5-c7ff-4553-bda5-d33f31772db8	204	SALES	42	22105000.00	20213000.00	21158000.00	\N	\N	\N	\N	935000.00	10000.00	22295000.00	-190000.00	22105000.00	947000.00	4.48	22548.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083253	2026-03-03 08:39:06.083253
a2568177-85e9-4aaa-8c68-821295de757d	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	206	SALES	1	101818.00	0.00	\N	\N	\N	\N	\N	\N	\N	101818.00	\N	101818.00	101818.00	\N	101818.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083256	2026-03-03 08:39:06.083257
f1a85354-1b48-42f6-9d9d-0c828d904a3f	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	207	SALES	1	5455.00	0.00	\N	\N	\N	\N	\N	\N	\N	5455.00	\N	5455.00	5455.00	\N	5455.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08326	2026-03-03 08:39:06.08326
39b9a07a-6b6b-4835-bf24-1f1ddc39811f	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	209	SALES	1	23636.00	0.00	\N	\N	\N	\N	\N	\N	\N	23636.00	\N	23636.00	23636.00	\N	23636.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083263	2026-03-03 08:39:06.083264
89c7b89c-f3b0-4e4f-b217-ea4ee5ff77bc	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	210	SALES	1	5455.00	0.00	\N	\N	\N	\N	\N	\N	\N	5455.00	\N	5455.00	5455.00	\N	5455.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083267	2026-03-03 08:39:06.083267
9e138191-3bf3-42b9-9823-0b66ea5e7ff7	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	211	SALES	1	36364.00	0.00	\N	\N	\N	\N	\N	\N	\N	36364.00	\N	36364.00	36364.00	\N	36364.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08327	2026-03-03 08:39:06.083271
05a7322f-ef7c-4bfb-992d-58ca7593aaf6	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	212	SALES	1	41818.00	0.00	\N	\N	\N	\N	\N	\N	\N	41818.00	\N	41818.00	41818.00	\N	41818.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083274	2026-03-03 08:39:06.083274
cbf82388-dbb6-42b8-a2f6-2543b53df3e2	2026-02-04	e5ba134e-9970-4b16-adbd-ae9e22f8e024	214	SALES	1	90909.00	0.00	\N	\N	\N	\N	\N	\N	\N	90909.00	\N	90909.00	90909.00	\N	90909.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083277	2026-03-03 08:39:06.083278
f1d284cc-c689-4b82-b0f0-e277e60348b4	2026-02-04	6eb1110b-8ec8-487c-9a82-e2442663d029	216	SALES	29	14575000.00	13603000.00	14183000.00	\N	\N	\N	\N	580000.00	\N	14575000.00	\N	14575000.00	392000.00	2.76	13517.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083281	2026-03-03 08:39:06.083281
aa054671-4ea5-41f3-9b6a-6d69aaddf452	2026-02-04	23c41e48-2784-4cd8-a920-ab87165b72bb	219	SALES	32	7480000.00	7078000.00	6982000.00	\N	\N	\N	\N	-96000.00	\N	7480000.00	\N	7480000.00	498000.00	7.13	15563.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083284	2026-03-03 08:39:06.083285
294de6ec-82a9-4249-8cf9-238a38fba880	2026-02-04	8b759141-95bc-427b-a95c-75985ea71cf9	223	SALES	1	840000.00	651000.00	661000.00	\N	\N	\N	\N	\N	10000.00	840000.00	\N	840000.00	179000.00	27.08	179000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083288	2026-03-03 08:39:06.083288
f483fa9a-7767-42ab-a673-0af350aa4036	2026-02-04	adc46688-90df-4d93-a5d4-1a34ceeae403	226	SALES	173	23874000.00	15914000.00	23085000.00	\N	\N	\N	\N	7171000.00	\N	23874000.00	\N	23874000.00	789000.00	3.42	4561.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083292	2026-03-03 08:39:06.083292
32637ee3-c561-4fdb-aa29-8d84b6dbec9a	2026-02-04	6eb1110b-8ec8-487c-9a82-e2442663d029	228	SALES	33	18810000.00	17496500.00	18167000.00	\N	\N	\N	\N	670500.00	\N	18810000.00	\N	18810000.00	643000.00	3.54	19485.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083295	2026-03-03 08:39:06.083295
8969bdf7-8499-468a-a271-956cd61289b0	2026-02-04	fb8a00d5-c7ff-4553-bda5-d33f31772db8	231	SALES	35	17210000.00	15779800.00	16239800.00	\N	\N	\N	\N	450000.00	10000.00	17465000.00	-255000.00	17210000.00	970200.00	5.97	27720.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083299	2026-03-03 08:39:06.083299
3769d516-a775-442e-bd1b-0ede2e3ed088	2026-02-04	13aa1618-e174-46a0-9a3f-13c99a848bb3	245	SALES	1	0.00	65000.00	\N	\N	\N	\N	\N	\N	-65000.00	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083302	2026-03-03 08:39:06.083303
f3aab1ff-cbe7-4e18-9716-7f0224d43263	2026-02-04	58a69881-1175-411a-b9c3-a73984aa504e	246	SALES	17	3390000.00	2900000.00	3178000.00	\N	\N	\N	\N	278000.00	\N	3390000.00	\N	3390000.00	212000.00	6.67	12471.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083306	2026-03-03 08:39:06.083306
3c4a8af3-dffb-401d-b0bc-0898a4ed2bd5	2026-02-04	abd00751-2371-4fe7-9d14-bf7e58cb6316	247	SALES	77	26475000.00	25088800.00	25288800.00	\N	\N	\N	\N	190000.00	10000.00	26475000.00	\N	26475000.00	1186200.00	4.69	15405.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083309	2026-03-03 08:39:06.08331
0218dc53-cfdf-427d-b27c-a218e77df03e	2026-02-04	0db921d6-4add-4b3d-ad21-58bbd17844e1	249	SALES	1	10000.00	5000.00	5000.00	\N	\N	\N	\N	\N	\N	10000.00	\N	10000.00	5000.00	100.00	5000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083313	2026-03-03 08:39:06.083313
e9c11b0d-d782-4de4-9cc9-45649cfe9e32	2026-02-04	61b6ebe7-0bfc-4e26-9aab-683c23d69a9d	253	SALES	27	10240000.00	9715000.00	9405000.00	\N	\N	\N	\N	-310000.00	\N	10600000.00	-360000.00	10240000.00	835000.00	8.88	30926.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083316	2026-03-03 08:39:06.083316
795522e9-b4cb-4a51-915c-95183f6a22f6	2026-02-04	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	257	SALES	70	20234240.00	21351000.00	19696000.00	\N	\N	\N	\N	-1655000.00	\N	25860640.00	-5626400.00	20234240.00	538240.00	2.73	7689.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08332	2026-03-03 08:39:06.08332
46806a37-9964-43d9-8efd-1caa4692d7e7	2026-02-04	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	259	SALES	70	24645920.00	24215000.00	24215000.00	\N	\N	\N	\N	\N	\N	24645920.00	\N	24645920.00	430920.00	1.78	6156.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083323	2026-03-03 08:39:06.083324
cf8a82df-1afd-4652-9897-c761493617cb	2026-02-04	b9132696-b6b9-4d5a-a959-659676233f24	262	SALES	84	27972565.00	26922000.00	26951000.00	\N	\N	\N	\N	29000.00	\N	29026165.00	-1053600.00	27972565.00	1021565.00	3.79	12161.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083327	2026-03-03 08:39:06.083327
6a73b357-3227-4925-bf5c-a44c55719e3f	2026-02-04	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	265	SALES	70	20103200.00	19891000.00	19671000.00	\N	\N	\N	\N	-220000.00	\N	20196800.00	-93600.00	20103200.00	432200.00	2.20	6174.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08333	2026-03-03 08:39:06.083331
c91fbe2e-6313-444f-8d59-aeebf07be3af	2026-02-04	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	266	SALES	70	17386720.00	17771000.00	16831000.00	\N	\N	\N	\N	-940000.00	\N	20038720.00	-2652000.00	17386720.00	555720.00	3.30	7939.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083334	2026-03-03 08:39:06.083334
e60a0c34-6333-4307-a598-7c4d401d2493	2026-02-04	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	268	SALES	72	16816800.00	16990000.00	16515000.00	\N	\N	\N	\N	-475000.00	\N	19718400.00	-2901600.00	16816800.00	301800.00	1.83	4192.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083337	2026-03-03 08:39:06.083338
8c8b556a-7fd8-41f2-827e-8e593dd1a857	2026-02-04	3b8448cc-7f5d-4453-9528-ee8ad014b113	269	SALES	13	3115000.00	2864000.00	2864000.00	\N	\N	\N	\N	\N	\N	3115000.00	\N	3115000.00	251000.00	8.76	19308.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083341	2026-03-03 08:39:06.083341
1fdbb0d6-8210-4856-9260-ce08317defe4	2026-02-05	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	4	SALES	31	6358222.00	5308000.00	5288000.00	\N	\N	\N	\N	-20000.00	\N	6358222.00	\N	6358222.00	1070222.00	20.24	34523.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083344	2026-03-03 08:39:06.083345
c22df429-1634-4955-a779-83402f9ee79e	2026-02-05	04be26d8-3adf-4bfe-9573-320e109c9ef7	7	SALES	11	2619615.00	2417704.00	2407704.00	\N	\N	\N	\N	-10000.00	\N	2619615.00	\N	2619615.00	211911.00	8.80	19265.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083348	2026-03-03 08:39:06.083348
554ebd25-e54e-4b93-82a6-99669d01fb0a	2026-02-05	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	8	SALES	1	58240.00	24000.00	24000.00	\N	\N	\N	\N	\N	\N	58240.00	\N	58240.00	34240.00	142.67	34240.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083351	2026-03-03 08:39:06.083352
7cb14f61-5172-4482-8266-3052ae550e16	2026-02-05	64673b02-2736-4a52-aabf-efb0c5410f9d	9	SALES	14	4024748.00	3499000.00	3619000.00	\N	\N	\N	\N	120000.00	\N	4024748.00	\N	4024748.00	405748.00	11.21	28982.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083355	2026-03-03 08:39:06.083355
01891fa5-02dc-47d8-a563-f3c5600cdd1f	2026-02-05	18b5ef55-910e-4504-b3bd-b6c96a2eb298	11	SALES	1	564311.00	513000.00	513000.00	\N	\N	\N	\N	\N	\N	564311.00	\N	564311.00	51311.00	10.00	51311.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083359	2026-03-03 08:39:06.083359
1ff0adc4-cf36-4d33-b8f9-0c945b62064b	2026-02-05	9ac5678b-105f-4912-b08e-75e30f29aec5	18	SALES	12	2370000.00	1937000.00	1937000.00	\N	\N	\N	\N	\N	\N	2370000.00	\N	2370000.00	433000.00	22.35	36083.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083362	2026-03-03 08:39:06.083363
5141555d-5f41-4532-bf69-8d1b947b890e	2026-02-05	184b1cb6-5cf6-40c7-8e65-dc384e2da567	21	SALES	34	3630173.00	2347000.00	2823000.00	\N	\N	\N	\N	466000.00	10000.00	3630173.00	\N	3630173.00	807173.00	28.59	23740.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083366	2026-03-03 08:39:06.083366
512acec6-1465-43c9-8169-fbaf572044f5	2026-02-05	bf127d8e-e428-40ff-af91-d676a9d6a23f	23	SALES	7	2801818.00	2861408.00	3127408.00	\N	\N	\N	\N	246000.00	20000.00	2801818.00	\N	2801818.00	-325590.00	-10.41	-46513.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083369	2026-03-03 08:39:06.08337
d42a672d-30f5-4a1f-9899-bea0a6a8acc5	2026-02-05	87a77c6d-5d37-4392-9e20-409c2cc3b854	24	SALES	13	4073234.00	3240000.00	3570000.00	\N	\N	\N	\N	330000.00	\N	4073234.00	\N	4073234.00	503234.00	14.10	38710.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083373	2026-03-03 08:39:06.083373
d09ff8d3-993d-4fbb-b62f-dab2f12903bc	2026-02-05	519e85f6-0e7a-4b16-bb79-4f15674ef834	25	SALES	1	92615.00	79000.00	70000.00	\N	\N	\N	\N	-9000.00	\N	92615.00	\N	92615.00	22615.00	32.31	22615.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083376	2026-03-03 08:39:06.083377
484628c3-0b03-42b3-9d18-ff98267b9021	2026-02-05	5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	33	SALES	3	1050000.00	840000.00	955000.00	\N	\N	\N	\N	115000.00	\N	1050000.00	\N	1050000.00	95000.00	9.95	31667.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08338	2026-03-03 08:39:06.08338
6e381c3b-5bdb-4dd3-bd15-7db9644fccee	2026-02-05	772eee3f-b282-43a0-bede-1047ad139fcf	35	SALES	9	4000000.00	3389000.00	3800000.00	\N	\N	\N	\N	401000.00	10000.00	4000000.00	\N	4000000.00	200000.00	5.26	22222.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083384	2026-03-03 08:39:06.083384
02f063fd-cd9c-4efa-b647-7dea6695ff6b	2026-02-05	45c13653-c3f1-4453-ab7b-f581e7b444de	36	SALES	9	1565000.00	1250000.00	1385000.00	\N	\N	\N	\N	135000.00	\N	1565000.00	\N	1565000.00	180000.00	13.00	20000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083387	2026-03-03 08:39:06.083387
fab7f7d3-07c0-4ae5-9f1e-d0dac2ebc932	2026-02-05	00dae90e-a6a3-4569-8a64-92c70bf34a4d	37	SALES	2	550000.00	458000.00	550000.00	\N	\N	\N	\N	92000.00	\N	550000.00	\N	550000.00	\N	\N	\N	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083391	2026-03-03 08:39:06.083391
5fd70073-fe10-40ed-bad9-9316fb286ad7	2026-02-05	7e52bf92-fcfc-448f-8bee-9e8514c03bb4	38	SALES	3	820000.00	662000.00	692000.00	\N	\N	\N	\N	30000.00	\N	820000.00	\N	820000.00	128000.00	18.50	42667.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083394	2026-03-03 08:39:06.083395
ea255af3-4b10-44a9-9ff8-44dbbdae6095	2026-02-05	b9132696-b6b9-4d5a-a959-659676233f24	42	SALES	4	1250000.00	1852000.00	1272000.00	\N	\N	\N	\N	-580000.00	\N	1250000.00	\N	1250000.00	-22000.00	-1.73	-5500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083398	2026-03-03 08:39:06.083398
9faf2da6-bcec-48b5-99be-9cf87c65c167	2026-02-05	9ceeda3a-520b-401c-bd0f-61f0bb6840f7	58	SALES	1	390000.00	357000.00	357000.00	\N	\N	\N	\N	\N	\N	390000.00	\N	390000.00	33000.00	9.24	33000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083401	2026-03-03 08:39:06.083402
5436bdb1-ec7f-4971-ae88-755c28112c12	2026-02-05	fe435be4-ea07-4b52-8732-15279d1f47ba	69	SALES	19	4790000.00	4308000.00	4498000.00	\N	\N	\N	\N	180000.00	10000.00	4790000.00	\N	4790000.00	292000.00	6.49	15368.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083405	2026-03-03 08:39:06.083405
0d582f32-b8eb-4cd0-8f81-35296354ec64	2026-02-05	fe435be4-ea07-4b52-8732-15279d1f47ba	75	SALES	4	335000.00	308000.00	308500.00	\N	\N	\N	\N	500.00	\N	335000.00	\N	335000.00	26500.00	8.59	6625.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083408	2026-03-03 08:39:06.083409
b05bfc74-d909-4f0a-999f-3c7299de8551	2026-02-05	4be7a678-c8ea-49c8-aa70-bd60f0c317cb	76	SALES	2	1460000.00	1370000.00	1430000.00	\N	\N	\N	\N	60000.00	\N	1460000.00	\N	1460000.00	30000.00	2.10	15000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083412	2026-03-03 08:39:06.083412
2d062dc7-e081-4d6f-ad24-7602671caffb	2026-02-05	d20fc7c5-529f-41c9-904d-19c1eb0efaf8	115	SALES	52	3779000.00	3984500.00	3444500.00	\N	\N	\N	\N	-540000.00	\N	3779000.00	\N	3779000.00	334500.00	9.71	6433.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083415	2026-03-03 08:39:06.083416
983cbd83-77ef-47ae-92d5-fe6923f95788	2026-02-05	adc46688-90df-4d93-a5d4-1a34ceeae403	125	SALES	692	170195000.00	162516800.00	171414800.00	\N	\N	\N	\N	8648000.00	250000.00	170195000.00	\N	170195000.00	-1219800.00	-0.71	-1763.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083419	2026-03-03 08:39:06.083419
c2d4996a-ef32-409d-ba76-acb17ac8b29d	2026-02-05	d20fc7c5-529f-41c9-904d-19c1eb0efaf8	129	SALES	56	2324000.00	3705000.00	2182000.00	\N	\N	\N	\N	-1523000.00	\N	2324000.00	\N	2324000.00	142000.00	6.51	2536.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083422	2026-03-03 08:39:06.083423
8687ec93-9888-441d-aaf2-d405a054817a	2026-02-05	adc46688-90df-4d93-a5d4-1a34ceeae403	134	SALES	79	21550000.00	20917000.00	20992000.00	\N	\N	\N	\N	75000.00	\N	21550000.00	\N	21550000.00	558000.00	2.66	7063.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083426	2026-03-03 08:39:06.083426
d9c90b82-dcc8-4efc-b434-4e5f73a13a2b	2026-02-05	adc46688-90df-4d93-a5d4-1a34ceeae403	137	SALES	80	51470000.00	27020000.00	30165000.00	\N	\N	\N	\N	3095000.00	50000.00	52755000.00	-1285000.00	51470000.00	21305000.00	70.63	266313.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083429	2026-03-03 08:39:06.08343
7b9aa9a8-4869-4fdf-b321-bfc5fc5e7e30	2026-02-05	0cb5faff-5f33-416a-9294-0aaed356494c	140	SALES	40	11190000.00	9864000.00	11347000.00	\N	\N	\N	\N	1483000.00	\N	11190000.00	\N	11190000.00	-157000.00	-1.38	-3925.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083433	2026-03-03 08:39:06.083433
08c7c887-e1a4-4cd1-ac27-75e85b596fbf	2026-02-05	adc46688-90df-4d93-a5d4-1a34ceeae403	145	SALES	5	4450000.00	3972000.00	4112000.00	\N	\N	\N	\N	140000.00	\N	4485000.00	-35000.00	4450000.00	338000.00	8.22	67600.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083436	2026-03-03 08:39:06.083437
58d02882-68e8-4742-907d-546978ee2183	2026-02-05	adc46688-90df-4d93-a5d4-1a34ceeae403	148	SALES	17	11105000.00	9435000.00	10155000.00	\N	\N	\N	\N	700000.00	20000.00	11370000.00	-265000.00	11105000.00	950000.00	9.35	55882.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08344	2026-03-03 08:39:06.08344
e5199be3-40c2-4efd-8a79-8adb53091b1b	2026-02-05	6eb1110b-8ec8-487c-9a82-e2442663d029	149	SALES	14	645000.00	608000.00	525000.00	\N	\N	\N	\N	-83000.00	\N	645000.00	\N	645000.00	120000.00	22.86	8571.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083443	2026-03-03 08:39:06.083444
c7e6cff2-676a-4f4f-81df-54bde3aca8cc	2026-02-05	72ca8edd-d551-4ec1-b56e-119ec94f4650	151	SALES	126	8015000.00	8321000.00	8231000.00	\N	\N	\N	\N	-90000.00	\N	8035000.00	-20000.00	8015000.00	-216000.00	-2.62	-1714.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083447	2026-03-03 08:39:06.083448
6de0cf1f-1efb-4021-8309-6d41b94bca49	2026-02-05	72ca8edd-d551-4ec1-b56e-119ec94f4650	152	SALES	18	815000.00	1120000.00	804000.00	\N	\N	\N	\N	-316000.00	\N	815000.00	\N	815000.00	11000.00	1.37	611.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083451	2026-03-03 08:39:06.083451
fc160dbf-6894-4a66-973e-fc39d7e89238	2026-02-05	4e0c76d8-9c9f-4d72-bf05-eb8e17a56e06	158	SALES	2	900000.00	565000.00	665000.00	\N	\N	\N	\N	100000.00	\N	900000.00	\N	900000.00	235000.00	35.34	117500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083454	2026-03-03 08:39:06.083455
31aa646a-b4cc-486f-b527-45894980f458	2026-02-05	fa3774ae-dc33-4aae-9f10-3fcfd2ff3ade	162	SALES	2	435000.00	281000.00	356000.00	\N	\N	\N	\N	75000.00	\N	435000.00	\N	435000.00	79000.00	22.19	39500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083458	2026-03-03 08:39:06.083458
717946ad-8eb5-4c9d-b17a-09a68ea8b493	2026-02-05	adc46688-90df-4d93-a5d4-1a34ceeae403	165	SALES	11	5400000.00	3391000.00	5276000.00	\N	\N	\N	\N	-540000.00	2425000.00	5490000.00	-90000.00	5400000.00	124000.00	2.35	11273.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083462	2026-03-03 08:39:06.083462
6c15a177-9e58-4cff-9750-1cd371d6a523	2026-02-05	e5ba134e-9970-4b16-adbd-ae9e22f8e024	172	SALES	1	18182.00	0.00	\N	\N	\N	\N	\N	\N	\N	18182.00	\N	18182.00	18182.00	\N	18182.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083465	2026-03-03 08:39:06.083465
a46295a7-cf84-4140-861c-cd74801d4c52	2026-02-05	6eb1110b-8ec8-487c-9a82-e2442663d029	179	SALES	97	3555000.00	4990500.00	2604500.00	\N	\N	\N	\N	-2386000.00	\N	3555000.00	\N	3555000.00	950500.00	36.49	9799.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083469	2026-03-03 08:39:06.083469
d51496b3-370c-4955-990b-ba6cfe955253	2026-02-05	c4ed6d88-ecf0-497d-bcf3-ae9370e8057b	181	SALES	5	2160000.00	1060000.00	2005000.00	\N	\N	\N	\N	10000.00	935000.00	2160000.00	\N	2160000.00	155000.00	7.73	31000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083472	2026-03-03 08:39:06.083472
96c5d3eb-6ca2-4a94-a88b-c2d1fc7ca010	2026-02-05	23c41e48-2784-4cd8-a920-ab87165b72bb	199	SALES	46	12320000.00	11523000.00	11788000.00	\N	\N	\N	\N	265000.00	\N	12320000.00	\N	12320000.00	532000.00	4.51	11565.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083476	2026-03-03 08:39:06.083476
ffda5c04-5e40-4e1b-b5c0-95a9c361daad	2026-02-05	8668793e-2e5d-4fc5-a504-983dc694313a	203	SALES	19	1945000.00	1708000.00	1750500.00	\N	\N	\N	\N	42500.00	\N	1945000.00	\N	1945000.00	194500.00	11.11	10237.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083479	2026-03-03 08:39:06.08348
13f08a4d-c233-48df-9957-f73a5f8bb2fa	2026-02-05	6eb1110b-8ec8-487c-9a82-e2442663d029	204	SALES	34	14985000.00	14213500.00	14255500.00	\N	\N	\N	\N	-33000.00	75000.00	14985000.00	\N	14985000.00	729500.00	5.12	21456.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083483	2026-03-03 08:39:06.083483
76a42e02-746a-4379-b682-76a6a35dfa85	2026-02-05	6eb1110b-8ec8-487c-9a82-e2442663d029	206	SALES	8	8290000.00	8050000.00	8050000.00	\N	\N	\N	\N	\N	\N	8290000.00	\N	8290000.00	240000.00	2.98	30000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083486	2026-03-03 08:39:06.083487
6d20cafb-d129-46c9-b6d0-19504f55ce98	2026-02-05	58a69881-1175-411a-b9c3-a73984aa504e	207	SALES	43	4765000.00	4189500.00	4425000.00	\N	\N	\N	\N	235500.00	\N	4765000.00	\N	4765000.00	340000.00	7.68	7907.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08349	2026-03-03 08:39:06.08349
e9d8c05c-9f6a-40f9-a323-efec169b271a	2026-02-05	58f1b10f-5ca4-46fe-a406-1f0bc3533667	210	SALES	22	1980000.00	2086000.00	1913000.00	\N	\N	\N	\N	-173000.00	\N	1980000.00	\N	1980000.00	67000.00	3.50	3045.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083493	2026-03-03 08:39:06.083494
65f29069-2c69-4b19-86a1-63b0c6339c32	2026-02-05	964e5f21-bec6-4158-a95d-3e380a12eb6e	220	SALES	15	7150000.00	6526000.00	6796000.00	\N	\N	\N	\N	250000.00	20000.00	7150000.00	\N	7150000.00	354000.00	5.21	23600.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083497	2026-03-03 08:39:06.083498
f01c63e8-5b68-4cac-89f2-e03aa873b626	2026-02-05	30573aa1-2438-46ab-a8c1-f93ef4303a94	221	SALES	12	3845000.00	3598000.00	3709000.00	\N	\N	\N	\N	111000.00	\N	3845000.00	\N	3845000.00	136000.00	3.67	11333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083501	2026-03-03 08:39:06.083501
d66928e7-b4c4-41bc-b915-7402fd73a2cf	2026-02-06	5b94afc0-22df-4331-aef7-f2d5d3f15733	4	SALES	43	6492000.00	5360000.00	6016000.00	\N	\N	\N	\N	656000.00	\N	6492000.00	\N	6492000.00	476000.00	7.91	11070.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083505	2026-03-03 08:39:06.083505
331bb5c5-7a73-47ba-b0c1-ad53ebdf23c7	2026-02-06	5b94afc0-22df-4331-aef7-f2d5d3f15733	8	SALES	43	5487000.00	5804000.00	5076000.00	\N	\N	\N	\N	-728000.00	\N	6177000.00	-690000.00	5487000.00	411000.00	8.10	9558.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083508	2026-03-03 08:39:06.083508
ace2b1e8-80a4-49f6-8f7e-d03575578f27	2026-02-06	5d46a0d1-11ac-4931-9582-e07495cb0eca	15	SALES	9	2330000.00	1975000.00	2174000.00	\N	\N	\N	\N	199000.00	\N	2330000.00	\N	2330000.00	156000.00	7.18	17333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083512	2026-03-03 08:39:06.083512
937925d2-d416-4261-bb50-c8fcef6829be	2026-02-06	5b94afc0-22df-4331-aef7-f2d5d3f15733	22	SALES	7	997000.00	1029000.00	979000.00	\N	\N	\N	\N	-50000.00	\N	997000.00	\N	997000.00	18000.00	1.84	2571.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083515	2026-03-03 08:39:06.083516
eae3aadb-234e-4cdb-a46c-85912353b6d0	2026-02-06	7eae8065-8201-4a14-8523-f3c2ab734ce3	24	SALES	15	3120000.00	3067000.00	3067000.00	\N	\N	\N	\N	\N	\N	3120000.00	\N	3120000.00	53000.00	1.73	3533.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083519	2026-03-03 08:39:06.083519
b882b6d9-eef6-4c33-9723-9196a73d64e3	2026-02-06	adc46688-90df-4d93-a5d4-1a34ceeae403	30	SALES	11	6065000.00	4770000.00	5530000.00	\N	\N	\N	\N	-780000.00	1540000.00	6145000.00	-80000.00	6065000.00	535000.00	9.67	48636.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083523	2026-03-03 08:39:06.083523
ae77687e-8bf4-43e1-b088-ba53b75ab651	2026-02-06	adc46688-90df-4d93-a5d4-1a34ceeae403	31	SALES	13	10090000.00	8310000.00	9770000.00	\N	\N	\N	\N	1460000.00	\N	10150000.00	-60000.00	10090000.00	320000.00	3.28	24615.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083526	2026-03-03 08:39:06.083526
7d05075d-fdc3-45fe-90e7-301f395209d2	2026-02-06	adc46688-90df-4d93-a5d4-1a34ceeae403	32	SALES	110	40550000.00	34792000.00	39418000.00	\N	\N	\N	\N	4622000.00	4000.00	41055000.00	-505000.00	40550000.00	1132000.00	2.87	10291.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083529	2026-03-03 08:39:06.08353
aa23c4c4-efac-4088-b8a5-b33acd664b2a	2026-02-06	adc46688-90df-4d93-a5d4-1a34ceeae403	35	SALES	58	14703000.00	13866000.00	14368000.00	\N	\N	\N	\N	485000.00	17000.00	14703000.00	\N	14703000.00	335000.00	2.33	5776.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083533	2026-03-03 08:39:06.083533
a2ebc4af-72b4-40ca-859c-e0b6322e1ed5	2026-02-06	8668793e-2e5d-4fc5-a504-983dc694313a	56	SALES	2	3700000.00	3650000.00	3650000.00	\N	\N	\N	\N	\N	\N	3700000.00	\N	3700000.00	50000.00	1.37	25000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083536	2026-03-03 08:39:06.083537
ce9f9655-db9b-4d4d-889c-21cbd1fe7f14	2026-02-06	011820fe-3424-4969-8264-84751e578ad7	62	SALES	98	29022000.00	28038000.00	28128000.00	\N	\N	\N	\N	90000.00	\N	29022000.00	\N	29022000.00	894000.00	3.18	9122.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08354	2026-03-03 08:39:06.08354
19c5a62c-8f25-4002-bec4-a44af1512975	2026-02-06	dfc10db2-0295-4794-afb6-77ff8fbfd8d3	74	SALES	5	2060000.00	1698000.00	2004636.00	\N	\N	\N	\N	343000.00	-36364.00	2060000.00	\N	2060000.00	55364.00	2.76	11073.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083543	2026-03-03 08:39:06.083544
145c9a78-fa38-4b15-be04-00273d7af470	2026-02-06	5cf21947-99ef-4cbc-b01b-7604e3c45dfd	86	SALES	1	540000.00	480000.00	530000.00	\N	\N	\N	\N	50000.00	\N	540000.00	\N	540000.00	10000.00	1.89	10000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083547	2026-03-03 08:39:06.083547
b4ee1bd3-ced9-477f-bc67-a195caba83a4	2026-02-06	bcb23087-0819-43b2-97cf-f9f4c33d21a1	89	SALES	30	5400000.00	5029000.00	5129000.00	\N	\N	\N	\N	100000.00	\N	5400000.00	\N	5400000.00	271000.00	5.28	9033.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083551	2026-03-03 08:39:06.083551
0b2188e3-9c5c-4ceb-baf2-4cc361efd67f	2026-02-06	81f09a0a-1e29-4017-aace-be235f9b8c88	90	SALES	5	2500000.00	2388000.00	2388000.00	\N	\N	\N	\N	\N	\N	2500000.00	\N	2500000.00	112000.00	4.69	22400.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083554	2026-03-03 08:39:06.083555
83d6356b-924f-4012-b320-33ec14571c32	2026-02-06	bcb23087-0819-43b2-97cf-f9f4c33d21a1	91	SALES	22	2240000.00	1816000.00	2099000.00	\N	\N	\N	\N	273000.00	10000.00	2240000.00	\N	2240000.00	141000.00	6.72	6409.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083558	2026-03-03 08:39:06.083558
9c9c4a9d-d195-4602-8724-85a2acf05272	2026-02-06	539627f6-0004-412c-a8bc-ebc7e9bacd50	107	SALES	13	5050000.00	4387000.00	4728818.00	\N	\N	\N	\N	365000.00	-23182.00	5050000.00	\N	5050000.00	321182.00	6.79	24706.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083561	2026-03-03 08:39:06.083562
7048d0b0-9af1-4c9e-ab52-e8988761a8c1	2026-02-06	741050b9-3c8a-4fc2-8d95-2498204228d7	109	SALES	14	535000.00	682000.00	287000.00	\N	\N	\N	\N	-395000.00	\N	535000.00	\N	535000.00	248000.00	86.41	17714.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083565	2026-03-03 08:39:06.083565
88826af5-cc16-4c9c-91e8-3dceff9dc939	2026-02-06	a9a42747-977a-4c68-a2f1-f4f03a811346	115	SALES	30	12555000.00	11130000.00	12260000.00	\N	\N	\N	\N	1130000.00	\N	12555000.00	\N	12555000.00	295000.00	2.41	9833.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083568	2026-03-03 08:39:06.083569
5687ac22-820d-4e1a-9eda-3059e6c3914a	2026-02-06	fb8a00d5-c7ff-4553-bda5-d33f31772db8	128	SALES	22	9460000.00	9027000.00	9052000.00	\N	\N	\N	\N	5000.00	20000.00	9460000.00	\N	9460000.00	408000.00	4.51	18545.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083572	2026-03-03 08:39:06.083572
3e871108-fd69-49c1-8a3a-61dfcf41aa8a	2026-02-06	4e0c76d8-9c9f-4d72-bf05-eb8e17a56e06	129	SALES	2	875000.00	555000.00	675000.00	\N	\N	\N	\N	120000.00	\N	875000.00	\N	875000.00	200000.00	29.63	100000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083575	2026-03-03 08:39:06.083576
13b3e154-4426-4d10-9816-410771501830	2026-02-06	e5ba134e-9970-4b16-adbd-ae9e22f8e024	131	SALES	1	18182.00	0.00	\N	\N	\N	\N	\N	\N	\N	18182.00	\N	18182.00	18182.00	\N	18182.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083579	2026-03-03 08:39:06.083579
d37e0bfa-28fc-43b0-b498-cbe51b26a5f5	2026-02-06	e5ba134e-9970-4b16-adbd-ae9e22f8e024	132	SALES	1	5455.00	0.00	\N	\N	\N	\N	\N	\N	\N	5455.00	\N	5455.00	5455.00	\N	5455.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083583	2026-03-03 08:39:06.083583
e08fa807-c8b4-4dae-92b2-fa24bbdd2670	2026-02-06	fb8a00d5-c7ff-4553-bda5-d33f31772db8	139	SALES	3	540000.00	685000.00	465000.00	\N	\N	\N	\N	-220000.00	\N	680000.00	-140000.00	540000.00	75000.00	16.13	25000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083587	2026-03-03 08:39:06.083587
f9e28c60-c3ec-4cfe-93f5-1e36a796a73c	2026-02-06	d5867d9d-07e6-4b06-872c-73d84b25ccc8	146	SALES	200	48000000.00	39000000.00	39000000.00	\N	\N	\N	\N	\N	\N	48000000.00	\N	48000000.00	9000000.00	23.08	45000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083591	2026-03-03 08:39:06.083591
75aca63d-7a83-45dc-92c7-1e64f72489e7	2026-02-06	6eb1110b-8ec8-487c-9a82-e2442663d029	149	SALES	25	9865000.00	8561500.00	9437500.00	\N	\N	\N	\N	876000.00	\N	9865000.00	\N	9865000.00	427500.00	4.53	17100.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083595	2026-03-03 08:39:06.083595
9af3052d-ce0c-46a9-8d92-b85ce621a382	2026-02-06	23c41e48-2784-4cd8-a920-ab87165b72bb	151	SALES	25	8200000.00	8590000.00	7924000.00	\N	\N	\N	\N	-666000.00	\N	8200000.00	\N	8200000.00	276000.00	3.48	11040.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083598	2026-03-03 08:39:06.083598
b22530d9-f94c-41cb-8fb0-7787bce433f0	2026-02-06	3894796d-c426-46cc-adb5-3628b464657b	164	SALES	1	800000.00	640000.00	790000.00	\N	\N	\N	\N	150000.00	\N	800000.00	\N	800000.00	10000.00	1.27	10000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083602	2026-03-03 08:39:06.083602
034593c8-b59b-4abe-84d3-ed2984922ab1	2026-02-06	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	165	SALES	53	16677440.00	17801000.00	16296000.00	\N	\N	\N	\N	-1505000.00	\N	17667520.00	-990080.00	16677440.00	381440.00	2.34	7197.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083605	2026-03-03 08:39:06.083605
39b2cd75-c342-44cb-93ae-40c7dd995612	2026-02-06	61b6ebe7-0bfc-4e26-9aab-683c23d69a9d	168	SALES	11	3815000.00	3777000.00	3607000.00	\N	\N	\N	\N	-170000.00	\N	3815000.00	\N	3815000.00	208000.00	5.77	18909.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083609	2026-03-03 08:39:06.083609
01aeda9c-7456-49d8-a25d-1ea170fcfb86	2026-02-06	fb8a00d5-c7ff-4553-bda5-d33f31772db8	169	SALES	44	12645000.00	11918000.00	12758000.00	\N	\N	\N	\N	840000.00	\N	12725000.00	-80000.00	12645000.00	-113000.00	-0.89	-2568.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083612	2026-03-03 08:39:06.083612
dc2af554-d9b3-4696-bceb-62544f5e15d0	2026-02-06	58a69881-1175-411a-b9c3-a73984aa504e	173	SALES	22	3850000.00	3237000.00	3676200.00	\N	\N	\N	\N	431000.00	8200.00	3850000.00	\N	3850000.00	173800.00	4.73	7900.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083615	2026-03-03 08:39:06.083616
723bffd4-8aa2-4475-a052-737c6ba19a90	2026-02-06	fb8a00d5-c7ff-4553-bda5-d33f31772db8	182	SALES	20	12290000.00	10405000.00	11900000.00	\N	\N	\N	\N	1495000.00	\N	12290000.00	\N	12290000.00	390000.00	3.28	19500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083619	2026-03-03 08:39:06.083619
d520d4dc-f102-4e31-9051-78c5a3e1ab51	2026-02-06	6eb1110b-8ec8-487c-9a82-e2442663d029	185	SALES	114	29070000.00	29355000.00	29445000.00	\N	\N	\N	\N	90000.00	\N	29070000.00	\N	29070000.00	-375000.00	-1.27	-3289.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083622	2026-03-03 08:39:06.083623
706c4095-7d48-449e-87a5-e02bb6449331	2026-02-06	6eb1110b-8ec8-487c-9a82-e2442663d029	188	SALES	16	12085000.00	10368000.00	11768000.00	\N	\N	\N	\N	1390000.00	10000.00	12085000.00	\N	12085000.00	317000.00	2.69	19813.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083626	2026-03-03 08:39:06.083626
d973413f-e0a1-48e8-bd6b-8c4063c2fdf8	2026-02-06	b9132696-b6b9-4d5a-a959-659676233f24	189	SALES	35	23546881.00	19722000.00	22427000.00	\N	\N	\N	\N	1685000.00	1020000.00	23697931.00	-151050.00	23546881.00	1119881.00	4.99	31997.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08363	2026-03-03 08:39:06.08363
1b9f77e4-a796-4e3e-a7cd-ca529c7c7fd4	2026-02-06	5b94afc0-22df-4331-aef7-f2d5d3f15733	190	SALES	38	3277000.00	2991000.00	3005000.00	\N	\N	\N	\N	14000.00	\N	3277000.00	\N	3277000.00	272000.00	9.05	7158.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083633	2026-03-03 08:39:06.083633
0bae7b10-ff9c-42e8-b3bf-4981dcaff5ee	2026-02-06	30573aa1-2438-46ab-a8c1-f93ef4303a94	195	SALES	18	3695000.00	3066000.00	3321000.00	\N	\N	\N	\N	245000.00	10000.00	3695000.00	\N	3695000.00	374000.00	11.26	20778.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083636	2026-03-03 08:39:06.083637
4c96e43a-3f04-4b21-8bbe-8adc1688d68e	2026-02-08	23c41e48-2784-4cd8-a920-ab87165b72bb	5	SALES	31	13200000.00	12103000.00	12743000.00	\N	\N	\N	\N	640000.00	\N	13200000.00	\N	13200000.00	457000.00	3.59	14742.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08364	2026-03-03 08:39:06.08364
1744125c-62ca-43e9-b818-90c525360484	2026-02-09	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	13	SALES	54	11399485.00	9785000.00	9835000.00	\N	\N	\N	\N	50000.00	\N	11399485.00	\N	11399485.00	1564485.00	15.91	28972.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083643	2026-03-03 08:39:06.083644
0ed4bf59-00ed-4563-9a5b-3aa189e37d5f	2026-02-09	64673b02-2736-4a52-aabf-efb0c5410f9d	15	SALES	25	8192365.00	6822800.00	7040800.00	\N	\N	\N	\N	218000.00	\N	8192365.00	\N	8192365.00	1151565.00	16.36	46063.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083647	2026-03-03 08:39:06.083647
7dc44097-23d3-40d7-8ac6-55b2fe6dd549	2026-02-09	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	16	SALES	5	1171576.00	1033000.00	1058000.00	\N	\N	\N	\N	25000.00	\N	1171576.00	\N	1171576.00	113576.00	10.73	22715.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08365	2026-03-03 08:39:06.083651
0a227fba-2d29-40d0-93ed-2d34daf01bde	2026-02-09	04be26d8-3adf-4bfe-9573-320e109c9ef7	17	SALES	18	3556703.00	3104000.00	3330000.00	\N	\N	\N	\N	226000.00	\N	3556703.00	\N	3556703.00	226703.00	6.81	12595.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083654	2026-03-03 08:39:06.083654
d746394b-ff0e-457b-9be1-d91eaf419bca	2026-02-09	546b9fe5-ed44-47ab-ad21-2050f33efc23	18	SALES	1	202868.00	73000.00	73000.00	\N	\N	\N	\N	\N	\N	202868.00	\N	202868.00	129868.00	177.90	129868.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083657	2026-03-03 08:39:06.083658
63cc3310-44a0-4aba-be0f-263b1c11e8a9	2026-02-09	adc46688-90df-4d93-a5d4-1a34ceeae403	19	SALES	1	185000.00	170000.00	200000.00	\N	\N	\N	\N	30000.00	\N	185000.00	\N	185000.00	-15000.00	-7.50	-15000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083661	2026-03-03 08:39:06.083661
2c8da56a-5d23-4ae0-9476-731941a38e3c	2026-02-09	184b1cb6-5cf6-40c7-8e65-dc384e2da567	23	SALES	70	9250976.00	6335780.00	7378780.00	\N	\N	\N	\N	1035000.00	8000.00	9250976.00	\N	9250976.00	1872196.00	25.37	26746.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083664	2026-03-03 08:39:06.083665
f53b7722-eea2-4514-b1d9-52e4baee8787	2026-02-09	bf127d8e-e428-40ff-af91-d676a9d6a23f	26	SALES	25	7490455.00	6007000.00	6362000.00	\N	\N	\N	\N	355000.00	\N	7490455.00	\N	7490455.00	1128455.00	17.74	45138.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083668	2026-03-03 08:39:06.083668
9978a4dc-c322-42cd-868a-b7ce36d80453	2026-02-09	87a77c6d-5d37-4392-9e20-409c2cc3b854	27	SALES	31	8859335.00	7354704.00	7690704.00	\N	\N	\N	\N	326000.00	10000.00	8859335.00	\N	8859335.00	1168631.00	15.20	37698.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083671	2026-03-03 08:39:06.083672
9e8c41af-08c6-4653-b4ff-e9deca83a521	2026-02-09	c3a020ac-224d-4ba1-acf3-c2c824eb5807	28	SALES	2	356820.00	209000.00	221000.00	\N	\N	\N	\N	12000.00	\N	356820.00	\N	356820.00	135820.00	61.46	67910.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083675	2026-03-03 08:39:06.083675
a6d6a204-9745-42b7-a9ab-e16bd13f8c76	2026-02-09	6382e215-2506-4ff9-a0bd-babe31776f49	29	SALES	3	910000.00	647000.00	759000.00	\N	\N	\N	\N	112000.00	\N	910000.00	\N	910000.00	151000.00	19.89	50333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083678	2026-03-03 08:39:06.083679
4216297c-5c3a-4371-90d2-9645106a32ef	2026-02-09	f08cafdc-365e-4c67-b64d-7c7360bc238c	33	SALES	60	33600000.00	29740000.00	33335000.00	\N	\N	\N	\N	3275000.00	320000.00	33600000.00	\N	33600000.00	265000.00	0.79	4417.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083682	2026-03-03 08:39:06.083682
8533b777-0a8d-46d2-97fe-2756b19ba8b8	2026-02-09	a4a4a6fc-6f9a-4f5f-9382-88ea5e0102d6	35	SALES	6	2005000.00	1611000.00	1961000.00	\N	\N	\N	\N	350000.00	\N	2005000.00	\N	2005000.00	44000.00	2.24	7333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083685	2026-03-03 08:39:06.083686
cf0cd1d6-32ff-403b-a85f-fb57f089b88a	2026-02-09	adc46688-90df-4d93-a5d4-1a34ceeae403	38	SALES	4	3660000.00	3180000.00	3510000.00	\N	\N	\N	\N	330000.00	\N	3730000.00	-70000.00	3660000.00	150000.00	4.27	37500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083689	2026-03-03 08:39:06.083689
17d54dde-7346-4637-a1bc-247f358c1706	2026-02-09	adc46688-90df-4d93-a5d4-1a34ceeae403	39	SALES	38	28070000.00	22196000.00	27321000.00	\N	\N	\N	\N	5095000.00	30000.00	28425000.00	-355000.00	28070000.00	749000.00	2.74	19711.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083692	2026-03-03 08:39:06.083693
2ec323a5-3ce0-47de-acb6-a9fdab020470	2026-02-09	adc46688-90df-4d93-a5d4-1a34ceeae403	40	SALES	135	51515000.00	42145000.00	50245000.00	\N	\N	\N	\N	8040000.00	60000.00	52670000.00	-1155000.00	51515000.00	1270000.00	2.53	9407.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083696	2026-03-03 08:39:06.083696
496399e8-364b-4cc4-bbaf-ec45006d2f01	2026-02-09	f30b1e3b-e380-49de-b846-9ce726b2bcca	42	SALES	1	850000.00	850000.00	850000.00	\N	\N	\N	\N	\N	\N	850000.00	\N	850000.00	\N	\N	\N	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083699	2026-03-03 08:39:06.0837
399a8ddf-9ae6-4146-9b68-61f9f0db44bc	2026-02-09	772eee3f-b282-43a0-bede-1047ad139fcf	45	SALES	14	5770000.00	4791000.00	5426000.00	\N	\N	\N	\N	635000.00	\N	5770000.00	\N	5770000.00	344000.00	6.34	24571.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083703	2026-03-03 08:39:06.083703
f3b7ebd8-f317-40e8-a52f-9c495a9ae07b	2026-02-09	7ce77cb3-c864-4896-95b0-b71b8bfd5bdb	46	SALES	1	560000.00	491000.00	541000.00	\N	\N	\N	\N	50000.00	\N	560000.00	\N	560000.00	19000.00	3.51	19000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083706	2026-03-03 08:39:06.083706
fc5d2f81-d26f-4e5f-baa4-c5569c08bcaa	2026-02-09	5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	47	SALES	1	360000.00	260000.00	310000.00	\N	\N	\N	\N	50000.00	\N	360000.00	\N	360000.00	50000.00	16.13	50000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083709	2026-03-03 08:39:06.08371
bb98ec57-e396-47d2-895d-218e616eab11	2026-02-09	adc46688-90df-4d93-a5d4-1a34ceeae403	48	SALES	35	9750000.00	9058000.00	9469000.00	\N	\N	\N	\N	391000.00	20000.00	9750000.00	\N	9750000.00	281000.00	2.97	8029.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083713	2026-03-03 08:39:06.083713
7fb3b13f-f0e8-4afe-80b0-a075284c97c5	2026-02-09	45c13653-c3f1-4453-ab7b-f581e7b444de	49	SALES	13	2100000.00	1688000.00	1856000.00	\N	\N	\N	\N	168000.00	\N	2100000.00	\N	2100000.00	244000.00	13.15	18769.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083716	2026-03-03 08:39:06.083717
eaabad9c-294d-4d3d-ae40-5a62f74da5a6	2026-02-09	00dae90e-a6a3-4569-8a64-92c70bf34a4d	50	SALES	4	800000.00	661000.00	806000.00	\N	\N	\N	\N	145000.00	\N	800000.00	\N	800000.00	-6000.00	-0.74	-1500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08372	2026-03-03 08:39:06.08372
aa6ba252-fc5b-48ae-bdf1-de7eb8f89984	2026-02-09	7e52bf92-fcfc-448f-8bee-9e8514c03bb4	51	SALES	9	3325000.00	2650000.00	2922000.00	\N	\N	\N	\N	272000.00	\N	3325000.00	\N	3325000.00	403000.00	13.79	44778.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083723	2026-03-03 08:39:06.083724
dae8e9e0-7b7b-42c4-9063-c60843d065f2	2026-02-09	082cc299-bc65-42c6-b8b4-ceb4c0ac7430	55	SALES	11	1158827.00	848636.00	848636.00	\N	\N	\N	\N	\N	\N	1158827.00	\N	1158827.00	310191.00	36.55	28199.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083727	2026-03-03 08:39:06.083727
fcd25c70-194d-40a7-a830-48d4e897a7c7	2026-02-09	d8752df9-aa5e-4e7b-a717-df2d2a95686f	56	SALES	2	827273.00	772728.00	772728.00	\N	\N	\N	\N	\N	\N	827273.00	\N	827273.00	54545.00	7.06	27273.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08373	2026-03-03 08:39:06.083731
7e4f160a-4a13-4676-b8c8-8e79bce8e6dd	2026-02-09	82f57867-459c-40b8-845a-4d71229218a4	57	SALES	21	1219831.00	1163912.00	1163912.00	\N	\N	\N	\N	\N	\N	1219831.00	\N	1219831.00	55919.00	4.80	2663.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083734	2026-03-03 08:39:06.083734
50b138d0-9fac-4521-b921-f3849af32361	2026-02-09	5b7a1424-4208-45db-b515-36bf310b8d42	58	SALES	7	1716822.00	1547489.00	1547489.00	\N	\N	\N	\N	\N	\N	1716822.00	\N	1716822.00	169333.00	10.94	24190.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083737	2026-03-03 08:39:06.083738
1fef64ba-bb08-4da4-ba96-2db38e060f24	2026-02-09	bf127d8e-e428-40ff-af91-d676a9d6a23f	59	SALES	127	27651272.00	20425546.00	20425546.00	\N	\N	\N	\N	\N	\N	27651272.00	\N	27651272.00	7225726.00	35.38	56895.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083741	2026-03-03 08:39:06.083741
1e4ca67f-d348-4e8a-8abc-9f8c962cf824	2026-02-09	47b01d71-a5e0-469c-8d48-835fe2a323b9	60	SALES	5	3808633.00	3227272.00	3227272.00	\N	\N	\N	\N	\N	\N	3808633.00	\N	3808633.00	581361.00	18.01	116272.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083744	2026-03-03 08:39:06.083744
ea102381-15ba-4bcf-8f02-76a4b0beba5f	2026-02-09	87a77c6d-5d37-4392-9e20-409c2cc3b854	61	SALES	6	825490.00	705000.00	705000.00	\N	\N	\N	\N	\N	\N	825490.00	\N	825490.00	120490.00	17.09	20082.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083748	2026-03-03 08:39:06.083748
55bf1572-cfd1-499a-8c92-501c3d62846a	2026-02-09	a8a3d02a-0a75-4282-90a8-30cc5fe498e7	62	SALES	16	2320000.00	4214000.00	2064000.00	\N	\N	\N	\N	-2150000.00	\N	2320000.00	\N	2320000.00	256000.00	12.40	16000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083751	2026-03-03 08:39:06.083752
36ae24b9-e4d7-4cd8-98b6-fe3a8340890c	2026-02-09	dc950987-84c6-4a80-be79-d7354cb8f9bb	63	SALES	1	932852.00	803000.00	803000.00	\N	\N	\N	\N	\N	\N	932852.00	\N	932852.00	129852.00	16.17	129852.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083755	2026-03-03 08:39:06.083755
cac5f2fd-ac5a-4868-b344-68d7716cd73c	2026-02-09	9f5d79c6-e380-4e90-b15c-f4ad55260d94	64	SALES	1	50320.00	43527.00	43527.00	\N	\N	\N	\N	\N	\N	50320.00	\N	50320.00	6793.00	15.61	6793.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083758	2026-03-03 08:39:06.083759
7364bde5-f1d9-4723-aced-5ad809172402	2026-02-09	e5ba134e-9970-4b16-adbd-ae9e22f8e024	66	SALES	2	18091.00	9000.00	9000.00	\N	\N	\N	\N	\N	\N	18091.00	\N	18091.00	9091.00	101.01	4546.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083762	2026-03-03 08:39:06.083762
4c9de24d-8fed-44ee-b5f5-11060c723926	2026-02-09	6eb1110b-8ec8-487c-9a82-e2442663d029	70	SALES	23	1160000.00	1366000.00	893000.00	\N	\N	\N	\N	-473000.00	\N	1160000.00	\N	1160000.00	267000.00	29.90	11609.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083765	2026-03-03 08:39:06.083766
d1f2fc99-9b7f-4860-98a9-8084b5260beb	2026-02-09	6eb1110b-8ec8-487c-9a82-e2442663d029	72	SALES	18	8730000.00	8569000.00	8519000.00	\N	\N	\N	\N	-50000.00	\N	8730000.00	\N	8730000.00	211000.00	2.48	11722.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083769	2026-03-03 08:39:06.083769
5bba4963-8142-40c1-b366-1c5ee461d5ac	2026-02-09	6eb1110b-8ec8-487c-9a82-e2442663d029	73	SALES	14	9275000.00	7845000.00	9085000.00	\N	\N	\N	\N	1240000.00	\N	9275000.00	\N	9275000.00	190000.00	2.09	13571.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083772	2026-03-03 08:39:06.083773
120a3dbe-f5f3-43cd-aa4f-de1f62122b04	2026-02-09	18b5ef55-910e-4504-b3bd-b6c96a2eb298	76	SALES	1	52750.00	0.00	\N	\N	\N	\N	\N	\N	\N	52750.00	\N	52750.00	52750.00	\N	52750.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083776	2026-03-03 08:39:06.083776
55bf4519-921f-42a2-9167-ab36643b11af	2026-02-09	18b5ef55-910e-4504-b3bd-b6c96a2eb298	77	SALES	1	0.00	772627.00	772627.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	-772627.00	-100.00	-772627.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083779	2026-03-03 08:39:06.083779
9f283654-c503-423f-bc9a-8e523c2d99f7	2026-02-09	75a6e0de-b3a1-43f9-be9b-1e86c64112bb	86	SALES	10	750000.00	517000.00	402000.00	\N	\N	\N	\N	-115000.00	\N	750000.00	\N	750000.00	348000.00	86.57	34800.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083783	2026-03-03 08:39:06.083783
af93e6c2-fc51-478b-a38e-2c2e0fbee923	2026-02-09	c7bf6d4a-3730-4143-9d6d-88eb950ba168	87	SALES	325	107250000.00	96214000.00	109116000.00	\N	\N	\N	\N	12882000.00	20000.00	107250000.00	\N	107250000.00	-1866000.00	-1.71	-5742.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083786	2026-03-03 08:39:06.083786
fba3c0b5-1e29-4c1d-9d06-9bfdf27bb971	2026-02-09	5b94afc0-22df-4331-aef7-f2d5d3f15733	97	SALES	18	5370000.00	6036000.00	4831000.00	\N	\N	\N	\N	-1205000.00	\N	6210000.00	-840000.00	5370000.00	539000.00	11.16	29944.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08379	2026-03-03 08:39:06.08379
8be3a784-d028-45a9-93ba-d705b8ec7b19	2026-02-09	23c41e48-2784-4cd8-a920-ab87165b72bb	103	SALES	77	15445000.00	13789000.00	14627000.00	\N	\N	\N	\N	828000.00	10000.00	15445000.00	\N	15445000.00	818000.00	5.59	10623.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083793	2026-03-03 08:39:06.083793
8c0dace0-e2fa-4675-bcdf-37786ddc4c59	2026-02-09	4e0c76d8-9c9f-4d72-bf05-eb8e17a56e06	108	SALES	1	870000.00	752000.00	752000.00	\N	\N	\N	\N	\N	\N	870000.00	\N	870000.00	118000.00	15.69	118000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083797	2026-03-03 08:39:06.083797
53d982dc-558b-48e7-afd4-e354fed3c450	2026-02-09	e5ba134e-9970-4b16-adbd-ae9e22f8e024	113	SALES	1	5455.00	0.00	\N	\N	\N	\N	\N	\N	\N	5455.00	\N	5455.00	5455.00	\N	5455.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.0838	2026-03-03 08:39:06.0838
5af59a94-60bc-47dc-80ff-9fb7a5d87902	2026-02-09	2bb880f2-a435-484a-9726-577e1634b6ee	123	SALES	34	8330000.00	6616000.00	8277000.00	\N	\N	\N	\N	1641000.00	20000.00	8330000.00	\N	8330000.00	53000.00	0.64	1559.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083803	2026-03-03 08:39:06.083804
d3c9472f-a7bd-4c5b-b3bf-beba97e3ee10	2026-02-10	e5ba134e-9970-4b16-adbd-ae9e22f8e024	7	SALES	1	354545.00	350000.00	325000.00	\N	\N	\N	\N	-25000.00	\N	354545.00	\N	354545.00	29545.00	9.09	29545.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083807	2026-03-03 08:39:06.083807
c34ad7fe-2438-4f85-89e9-7eb490551ba4	2026-02-10	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	13	SALES	41	9445069.00	7408000.00	7553000.00	\N	\N	\N	\N	135000.00	10000.00	9445069.00	\N	9445069.00	1892069.00	25.05	46148.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08381	2026-03-03 08:39:06.083811
e314385b-b515-4f6e-bbed-56426969e624	2026-02-10	04be26d8-3adf-4bfe-9573-320e109c9ef7	14	SALES	11	2635773.00	1931800.00	2091800.00	\N	\N	\N	\N	160000.00	\N	2635773.00	\N	2635773.00	543973.00	26.01	49452.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083814	2026-03-03 08:39:06.083814
7a008fd5-089d-4b56-9ffb-334a5359d37d	2026-02-10	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	15	SALES	7	2967391.00	2478000.00	2583000.00	\N	\N	\N	\N	105000.00	\N	2967391.00	\N	2967391.00	384391.00	14.88	54913.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083817	2026-03-03 08:39:06.083818
a35f00ef-c669-4ddc-bb3f-49b44bdcbc49	2026-02-10	64673b02-2736-4a52-aabf-efb0c5410f9d	16	SALES	38	8914604.00	7086000.00	7364000.00	\N	\N	\N	\N	278000.00	\N	8914604.00	\N	8914604.00	1550604.00	21.06	40805.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083821	2026-03-03 08:39:06.083822
05890aba-4be9-408b-a4eb-8a45ecc75cce	2026-02-10	546b9fe5-ed44-47ab-ad21-2050f33efc23	17	SALES	1	231728.00	212000.00	212000.00	\N	\N	\N	\N	\N	\N	231728.00	\N	231728.00	19728.00	9.31	19728.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083825	2026-03-03 08:39:06.083825
94cc93b8-f1a9-4a1b-84ba-4bf0b2dd67dd	2026-02-10	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	21	SALES	1	0.00	1372646.00	1372646.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	-1372646.00	-100.00	-1372646.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083829	2026-03-03 08:39:06.083829
3ef1fbb6-20d4-435d-86bd-a1ee60079350	2026-02-10	184b1cb6-5cf6-40c7-8e65-dc384e2da567	26	SALES	85	13830870.00	10629000.00	11724000.00	\N	\N	\N	\N	1095000.00	\N	13830870.00	\N	13830870.00	2106870.00	17.97	24787.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083832	2026-03-03 08:39:06.083832
48d198c3-2ff2-4240-848e-a2b6e5b0bbd5	2026-02-10	bf127d8e-e428-40ff-af91-d676a9d6a23f	28	SALES	25	7269545.00	5919000.00	6014000.00	\N	\N	\N	\N	95000.00	\N	7269545.00	\N	7269545.00	1255545.00	20.88	50222.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083835	2026-03-03 08:39:06.083836
87fab681-0fa7-465a-acf8-1cbae5e83307	2026-02-10	87a77c6d-5d37-4392-9e20-409c2cc3b854	29	SALES	33	11707977.00	9113000.00	9703000.00	\N	\N	\N	\N	570000.00	20000.00	11707977.00	\N	11707977.00	2004977.00	20.66	60757.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083839	2026-03-03 08:39:06.083839
dee0e2e3-a66c-439a-89e2-65c19b61ebfa	2026-02-10	c3a020ac-224d-4ba1-acf3-c2c824eb5807	31	SALES	1	329659.00	245000.00	270000.00	\N	\N	\N	\N	25000.00	\N	329659.00	\N	329659.00	59659.00	22.10	59659.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083842	2026-03-03 08:39:06.083843
190d8ee9-d9d2-4201-86fb-6bfb146bbd72	2026-02-10	a77fa567-0758-4a03-a67d-f3b22c3f4045	32	SALES	1	539182.00	440000.00	460000.00	\N	\N	\N	\N	20000.00	\N	539182.00	\N	539182.00	79182.00	17.21	79182.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083846	2026-03-03 08:39:06.083846
4b3b8dd1-4adb-4690-9ad4-6b289fc5034b	2026-02-10	082cc299-bc65-42c6-b8b4-ceb4c0ac7430	33	SALES	3	734062.00	509000.00	606000.00	\N	\N	\N	\N	97000.00	\N	734062.00	\N	734062.00	128062.00	21.13	42687.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083849	2026-03-03 08:39:06.08385
fdece441-aa3b-4535-9477-ce7549c3f641	2026-02-10	6382e215-2506-4ff9-a0bd-babe31776f49	34	SALES	1	110000.00	95000.00	95000.00	\N	\N	\N	\N	\N	\N	110000.00	\N	110000.00	15000.00	15.79	15000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083853	2026-03-03 08:39:06.083853
45d8cefa-f324-4d97-8bee-d454f7481284	2026-02-10	772eee3f-b282-43a0-bede-1047ad139fcf	38	SALES	19	10440000.00	8906000.00	9831000.00	\N	\N	\N	\N	925000.00	\N	10440000.00	\N	10440000.00	609000.00	6.19	32053.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083856	2026-03-03 08:39:06.083857
e4ac7281-bd14-49ff-8f31-0990791b9362	2026-02-10	7ce77cb3-c864-4896-95b0-b71b8bfd5bdb	39	SALES	2	1030000.00	830000.00	975000.00	\N	\N	\N	\N	145000.00	\N	1030000.00	\N	1030000.00	55000.00	5.64	27500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08386	2026-03-03 08:39:06.08386
b1bb896a-032f-4cc4-9f5f-cee703b96c31	2026-02-10	5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	40	SALES	2	1000000.00	850000.00	920000.00	\N	\N	\N	\N	70000.00	\N	1000000.00	\N	1000000.00	80000.00	8.70	40000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083863	2026-03-03 08:39:06.083864
5cc38c8d-c08f-4672-bedf-10437fa61a0a	2026-02-10	45c13653-c3f1-4453-ab7b-f581e7b444de	43	SALES	10	1730000.00	1637000.00	1655000.00	\N	\N	\N	\N	18000.00	\N	1730000.00	\N	1730000.00	75000.00	4.53	7500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083867	2026-03-03 08:39:06.083867
1cc3d264-73f1-4a98-9e0a-3778a2bc4c93	2026-02-10	00dae90e-a6a3-4569-8a64-92c70bf34a4d	45	SALES	5	1020000.00	875000.00	951000.00	\N	\N	\N	\N	76000.00	\N	1020000.00	\N	1020000.00	69000.00	7.26	13800.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08387	2026-03-03 08:39:06.083871
453b7e5c-5a71-45e3-bfb8-fcfea6526bf0	2026-02-10	7e52bf92-fcfc-448f-8bee-9e8514c03bb4	46	SALES	11	3550000.00	2816000.00	3086000.00	\N	\N	\N	\N	270000.00	\N	3550000.00	\N	3550000.00	464000.00	15.04	42182.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083874	2026-03-03 08:39:06.083874
14f7f628-3ad9-46f0-8109-090f201f30a9	2026-02-10	87a77c6d-5d37-4392-9e20-409c2cc3b854	48	SALES	9	414743.00	347026.00	347026.00	\N	\N	\N	\N	\N	\N	414743.00	\N	414743.00	67717.00	19.51	7524.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083877	2026-03-03 08:39:06.083877
160fc062-e1cb-4065-9688-22f9d4fe70d8	2026-02-10	082cc299-bc65-42c6-b8b4-ceb4c0ac7430	50	SALES	151	4480909.00	4279594.00	4279594.00	\N	\N	\N	\N	\N	\N	4480909.00	\N	4480909.00	201315.00	4.70	1333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083881	2026-03-03 08:39:06.083881
c4de4989-77c4-47f6-af14-955842dd0ade	2026-02-10	d8752df9-aa5e-4e7b-a717-df2d2a95686f	54	SALES	9	418182.00	375000.00	375000.00	\N	\N	\N	\N	\N	\N	418182.00	\N	418182.00	43182.00	11.52	4798.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083884	2026-03-03 08:39:06.083884
06e676cb-f646-4718-b240-c637d385a207	2026-02-10	dc950987-84c6-4a80-be79-d7354cb8f9bb	56	SALES	1	678206.00	609091.00	609091.00	\N	\N	\N	\N	\N	\N	678206.00	\N	678206.00	69115.00	11.35	69115.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083888	2026-03-03 08:39:06.083888
881dd937-3869-4e00-8c4a-4330f33e9ced	2026-02-10	519e85f6-0e7a-4b16-bb79-4f15674ef834	62	SALES	19	649739.00	547250.00	547250.00	\N	\N	\N	\N	\N	\N	649739.00	\N	649739.00	102489.00	18.73	5394.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083891	2026-03-03 08:39:06.083891
7cec4d0f-9e19-4d59-b742-776e96c94d54	2026-02-10	bf127d8e-e428-40ff-af91-d676a9d6a23f	66	SALES	70	18691528.00	16198539.00	16198539.00	\N	\N	\N	\N	\N	\N	18691528.00	\N	18691528.00	2492989.00	15.39	35614.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083895	2026-03-03 08:39:06.083895
23944df1-5996-443b-91ea-c624b5698256	2026-02-10	5b94afc0-22df-4331-aef7-f2d5d3f15733	70	SALES	2	1820000.00	1580000.00	1775000.00	\N	\N	\N	\N	195000.00	\N	1820000.00	\N	1820000.00	45000.00	2.54	22500.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083898	2026-03-03 08:39:06.083898
c077ab0b-07c4-4d6b-80eb-68af6052fe68	2026-02-10	fe435be4-ea07-4b52-8732-15279d1f47ba	72	SALES	14	3515000.00	3051000.00	3299000.00	\N	\N	\N	\N	248000.00	\N	3515000.00	\N	3515000.00	216000.00	6.55	15429.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083902	2026-03-03 08:39:06.083902
45d2c29f-2937-4d87-af08-be8e9bf3a968	2026-02-10	23c41e48-2784-4cd8-a920-ab87165b72bb	92	SALES	3	340000.00	336000.00	336000.00	\N	\N	\N	\N	\N	\N	340000.00	\N	340000.00	4000.00	1.19	1333.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083905	2026-03-03 08:39:06.083905
bb6d09ea-e076-4ac0-83a8-57f12921b7a0	2026-02-10	fe435be4-ea07-4b52-8732-15279d1f47ba	109	SALES	5	1480000.00	1484000.00	1484000.00	\N	\N	\N	\N	\N	\N	1480000.00	\N	1480000.00	-4000.00	-0.27	-800.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083909	2026-03-03 08:39:06.083909
5019a323-e6cd-40e1-b23c-ed6a13f54574	2026-02-10	dfc10db2-0295-4794-afb6-77ff8fbfd8d3	120	SALES	5	1665000.00	1423000.00	1588000.00	\N	\N	\N	\N	165000.00	\N	1665000.00	\N	1665000.00	77000.00	4.85	15400.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083912	2026-03-03 08:39:06.083913
1eaf69ea-653e-4b11-8bff-f47669a0e0d5	2026-02-10	67b38c33-88a8-4c33-afcd-fa18220875ce	123	SALES	9	7580000.00	5790000.00	6750000.00	\N	\N	\N	\N	960000.00	\N	7580000.00	\N	7580000.00	830000.00	12.30	92222.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083916	2026-03-03 08:39:06.083916
25a2d74e-11d3-4fa2-bccf-dda12b670e51	2026-02-10	23c41e48-2784-4cd8-a920-ab87165b72bb	146	SALES	82	14345000.00	13932000.00	13321000.00	\N	\N	\N	\N	-611000.00	\N	14345000.00	\N	14345000.00	1024000.00	7.69	12488.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083919	2026-03-03 08:39:06.083919
1a4e57cb-c580-4827-8516-51e4087a1745	2026-02-10	5cf21947-99ef-4cbc-b01b-7604e3c45dfd	155	SALES	1	540000.00	505000.00	595000.00	\N	\N	\N	\N	90000.00	\N	540000.00	\N	540000.00	-55000.00	-9.24	-55000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083923	2026-03-03 08:39:06.083923
d43c0bc6-77a4-44cf-8d05-c1d79d2654de	2026-02-10	e5ba134e-9970-4b16-adbd-ae9e22f8e024	158	SALES	1	4545.00	4545.00	4545.00	\N	\N	\N	\N	\N	\N	4545.00	\N	4545.00	\N	\N	\N	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083926	2026-03-03 08:39:06.083926
fe069bc6-52a8-44d4-86c5-1ebe956d5edd	2026-02-10	516733e4-e694-44bf-8add-090a239834ff	172	SALES	85	20500000.00	18435250.00	21037062.00	\N	\N	\N	\N	3434000.00	-832188.00	20500000.00	\N	20500000.00	-537062.00	-2.55	-6318.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083929	2026-03-03 08:39:06.08393
b8efdc0a-6d29-4b0d-93f0-c5e50dfb91a5	2026-02-10	c4ed6d88-ecf0-497d-bcf3-ae9370e8057b	187	SALES	11	3150000.00	2178000.00	2688000.00	\N	\N	\N	\N	510000.00	\N	3150000.00	\N	3150000.00	462000.00	17.19	42000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083933	2026-03-03 08:39:06.083933
1501b3d9-6bf4-4b82-a78a-4703cdc1b7a8	2026-02-10	0f07d7f9-a1d2-41a5-89cb-0e942fd7ed22	193	SALES	34	5520000.00	4106000.00	5132000.00	\N	\N	\N	\N	1026000.00	\N	5520000.00	\N	5520000.00	388000.00	7.56	11412.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083937	2026-03-03 08:39:06.083937
e03dbd86-3ba2-4514-b711-2410e790d8cd	2026-02-10	e5ba134e-9970-4b16-adbd-ae9e22f8e024	197	SALES	1	72727.00	63636.00	63636.00	\N	\N	\N	\N	\N	\N	72727.00	\N	72727.00	9091.00	14.29	9091.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08394	2026-03-03 08:39:06.08394
1a8e443c-2533-49f8-b765-3620451c7d64	2026-02-10	6eb1110b-8ec8-487c-9a82-e2442663d029	221	SALES	40	14660000.00	13769500.00	14043500.00	\N	\N	\N	\N	274000.00	\N	14660000.00	\N	14660000.00	616500.00	4.39	15413.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083943	2026-03-03 08:39:06.083944
8b832e5c-647c-449e-afce-cf93381a0ab6	2026-02-10	516733e4-e694-44bf-8add-090a239834ff	238	SALES	88	15610000.00	12573000.00	14157818.00	\N	\N	\N	\N	1618000.00	-33182.00	15610000.00	\N	15610000.00	1452182.00	10.26	16502.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083947	2026-03-03 08:39:06.083947
c29b1ff9-dfa8-49c9-a430-62984b11cfc9	2026-02-10	6eb1110b-8ec8-487c-9a82-e2442663d029	243	SALES	57	23245000.00	20917000.00	22187000.00	\N	\N	\N	\N	1270000.00	\N	23245000.00	\N	23245000.00	1058000.00	4.77	18561.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083951	2026-03-03 08:39:06.083951
ae347c70-4b96-4f14-a646-5fb495e348b3	2026-02-10	aab52bb6-4aff-4da5-b81e-4d0bd0ffb42a	244	SALES	56	22095840.00	24541000.00	21476000.00	\N	\N	\N	\N	-3065000.00	\N	24123840.00	-2028000.00	22095840.00	619840.00	2.89	11069.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083954	2026-03-03 08:39:06.083954
c933473a-12ba-478d-9120-294ea44555c6	2026-02-10	6eb1110b-8ec8-487c-9a82-e2442663d029	247	SALES	58	14010000.00	12469000.00	13497000.00	\N	\N	\N	\N	1028000.00	\N	14010000.00	\N	14010000.00	513000.00	3.80	8845.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083957	2026-03-03 08:39:06.083958
3cbd6052-35c7-4e4d-a765-793487ac9e05	2026-02-10	30573aa1-2438-46ab-a8c1-f93ef4303a94	254	SALES	45	5825000.00	4298000.00	5344000.00	\N	\N	\N	\N	1046000.00	\N	5825000.00	\N	5825000.00	481000.00	9.00	10689.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083961	2026-03-03 08:39:06.083961
aaed22f1-3e3c-4da1-942b-4ef26f23d355	2026-02-11	5ac88854-845a-471c-a1d3-82673bb52489	5	SALES	11	7830000.00	6772000.00	7412000.00	\N	\N	\N	\N	640000.00	\N	7830000.00	\N	7830000.00	418000.00	5.64	38000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083964	2026-03-03 08:39:06.083965
c8d54982-da48-44b3-8090-1cac147f3845	2026-02-11	7eae8065-8201-4a14-8523-f3c2ab734ce3	24	SALES	22	20730000.00	19085000.00	19085000.00	\N	\N	\N	\N	\N	\N	20730000.00	\N	20730000.00	1645000.00	8.62	74773.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083968	2026-03-03 08:39:06.083968
47dc3df0-392e-467b-bec6-99ebd23a92a1	2026-02-11	7db3adcd-ecaf-40d9-9e09-13c6dc53cc14	27	SALES	9	5200000.00	4851000.00	5101000.00	\N	\N	\N	\N	250000.00	\N	5200000.00	\N	5200000.00	99000.00	1.94	11000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083971	2026-03-03 08:39:06.083972
f8e83593-79e1-4c41-95d6-6b63191eb6ff	2026-02-11	f8f444b1-069e-4fd0-befa-6068f3c1f2b6	31	SALES	10	1606889.00	1026000.00	1092000.00	\N	\N	\N	\N	66000.00	\N	1606889.00	\N	1606889.00	514889.00	47.15	51489.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083975	2026-03-03 08:39:06.083975
de69fc4e-7ddf-4806-9a3b-36371f611787	2026-02-11	04be26d8-3adf-4bfe-9573-320e109c9ef7	32	SALES	10	2231423.00	1801000.00	1908000.00	\N	\N	\N	\N	107000.00	\N	2231423.00	\N	2231423.00	323423.00	16.95	32342.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083978	2026-03-03 08:39:06.083979
7295a9bd-1869-4d54-a30b-a74a43354c10	2026-02-11	1d4c8aec-c05b-4369-b4ec-c6fd1984097b	33	SALES	4	506135.00	354000.00	384000.00	\N	\N	\N	\N	30000.00	\N	506135.00	\N	506135.00	122135.00	31.81	30534.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083982	2026-03-03 08:39:06.083982
5d7a8bcd-17a7-4825-ae76-6422cbf8f01f	2026-02-11	64673b02-2736-4a52-aabf-efb0c5410f9d	34	SALES	17	5552617.00	4863000.00	5101000.00	\N	\N	\N	\N	238000.00	\N	5552617.00	\N	5552617.00	451617.00	8.85	26566.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083986	2026-03-03 08:39:06.083986
5db0762f-e256-4047-b6ca-0d8fe47eca27	2026-02-11	546b9fe5-ed44-47ab-ad21-2050f33efc23	35	SALES	1	231728.00	220000.00	230000.00	\N	\N	\N	\N	10000.00	\N	231728.00	\N	231728.00	1728.00	0.75	1728.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083989	2026-03-03 08:39:06.08399
408dd118-df7c-41a4-a564-eab0d45403ee	2026-02-11	5b94afc0-22df-4331-aef7-f2d5d3f15733	41	SALES	1	700000.00	500000.00	670000.00	\N	\N	\N	\N	170000.00	\N	700000.00	\N	700000.00	30000.00	4.48	30000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083993	2026-03-03 08:39:06.083993
a110776d-515b-4b68-bc1b-3df1f245cdc6	2026-02-11	0dfae848-f45b-4eb8-92e1-053f06cb46e6	57	SALES	8	1750000.00	1341000.00	1596000.00	\N	\N	\N	\N	255000.00	\N	1750000.00	\N	1750000.00	154000.00	9.65	19250.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.083996	2026-03-03 08:39:06.083997
059b4ef6-9e83-43e1-a8b2-55614654b6a9	2026-02-11	184b1cb6-5cf6-40c7-8e65-dc384e2da567	58	SALES	63	10606825.00	8440780.00	9102780.00	\N	\N	\N	\N	662000.00	\N	10606825.00	\N	10606825.00	1504045.00	16.52	23874.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084	2026-03-03 08:39:06.084
fd053b50-68bd-4399-8bf1-ff5952c62269	2026-02-11	bf127d8e-e428-40ff-af91-d676a9d6a23f	59	SALES	1	193909.00	155000.00	160000.00	\N	\N	\N	\N	5000.00	\N	193909.00	\N	193909.00	33909.00	21.19	33909.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084003	2026-03-03 08:39:06.084004
b6357826-2e50-4b68-86f6-a2a54c455b2f	2026-02-11	87a77c6d-5d37-4392-9e20-409c2cc3b854	61	SALES	8	2860278.00	2239000.00	2424000.00	\N	\N	\N	\N	185000.00	\N	2860278.00	\N	2860278.00	436278.00	18.00	54535.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084007	2026-03-03 08:39:06.084007
3ce34071-0cec-47ae-b059-3701d71b7e88	2026-02-11	c3a020ac-224d-4ba1-acf3-c2c824eb5807	62	SALES	2	420118.00	279000.00	290000.00	\N	\N	\N	\N	11000.00	\N	420118.00	\N	420118.00	130118.00	44.87	65059.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08401	2026-03-03 08:39:06.08401
fd3325c3-d21c-4de3-a1f1-c78bf7e70294	2026-02-11	6382e215-2506-4ff9-a0bd-babe31776f49	64	SALES	1	90000.00	59000.00	59000.00	\N	\N	\N	\N	\N	\N	90000.00	\N	90000.00	31000.00	52.54	31000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084014	2026-03-03 08:39:06.084014
724b439c-26b6-4c81-a5a5-8bb2d1febd2b	2026-02-11	772eee3f-b282-43a0-bede-1047ad139fcf	76	SALES	8	5270000.00	4638000.00	4948000.00	\N	\N	\N	\N	310000.00	\N	5270000.00	\N	5270000.00	322000.00	6.51	40250.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084017	2026-03-03 08:39:06.084017
047824bb-0105-49b3-9573-3e4c3903744d	2026-02-11	7ce77cb3-c864-4896-95b0-b71b8bfd5bdb	77	SALES	1	480000.00	405000.00	430000.00	\N	\N	\N	\N	25000.00	\N	480000.00	\N	480000.00	50000.00	11.63	50000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08402	2026-03-03 08:39:06.084021
8b40c94f-6e22-4b53-8d70-f11403e9da21	2026-02-11	5d5776f3-b2be-4e5d-aa7f-2818bd62a75d	79	SALES	1	480000.00	440000.00	465000.00	\N	\N	\N	\N	25000.00	\N	480000.00	\N	480000.00	15000.00	3.23	15000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084024	2026-03-03 08:39:06.084024
6e78308b-1b98-42bb-8cdb-3d20300f2c59	2026-02-11	45c13653-c3f1-4453-ab7b-f581e7b444de	80	SALES	4	1195000.00	1048000.00	1072000.00	\N	\N	\N	\N	24000.00	\N	1195000.00	\N	1195000.00	123000.00	11.47	30750.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084027	2026-03-03 08:39:06.084028
408e0cd4-82c1-4d2d-9b11-5d62c5b477e3	2026-02-11	00dae90e-a6a3-4569-8a64-92c70bf34a4d	81	SALES	10	2505000.00	1974000.00	2381000.00	\N	\N	\N	\N	407000.00	\N	2505000.00	\N	2505000.00	124000.00	5.21	12400.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084031	2026-03-03 08:39:06.084031
c9145e67-30f8-46d6-99a5-886e239a7191	2026-02-11	7e52bf92-fcfc-448f-8bee-9e8514c03bb4	82	SALES	4	910000.00	811000.00	821000.00	\N	\N	\N	\N	10000.00	\N	910000.00	\N	910000.00	89000.00	10.84	22250.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084034	2026-03-03 08:39:06.084035
c7920a73-399b-4c4e-b37d-4e28b706432d	2026-02-11	87a77c6d-5d37-4392-9e20-409c2cc3b854	87	SALES	13	561518.00	465908.00	465908.00	\N	\N	\N	\N	\N	\N	561518.00	\N	561518.00	95610.00	20.52	7355.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084038	2026-03-03 08:39:06.084038
cdf7f9a3-e17d-4dbb-91b6-6f007c144406	2026-02-11	082cc299-bc65-42c6-b8b4-ceb4c0ac7430	88	SALES	177	3682045.00	3667535.00	3667535.00	\N	\N	\N	\N	\N	\N	3682045.00	\N	3682045.00	14510.00	0.40	82.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084041	2026-03-03 08:39:06.084042
c530b37e-3c33-4d02-8d96-b3ab15ab7065	2026-02-11	dc950987-84c6-4a80-be79-d7354cb8f9bb	90	SALES	1	84797.00	70000.00	70000.00	\N	\N	\N	\N	\N	\N	84797.00	\N	84797.00	14797.00	21.14	14797.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084045	2026-03-03 08:39:06.084045
c2243209-e571-4b9f-b858-d30695ef0119	2026-02-11	6eb1110b-8ec8-487c-9a82-e2442663d029	96	SALES	46	1500000.00	1073000.00	1082500.00	\N	\N	\N	\N	9500.00	\N	1500000.00	\N	1500000.00	417500.00	38.57	9076.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084048	2026-03-03 08:39:06.084049
51798716-c2d2-40d2-af45-20574c4c03e0	2026-02-11	d8752df9-aa5e-4e7b-a717-df2d2a95686f	101	SALES	6	488182.00	442727.00	442727.00	\N	\N	\N	\N	\N	\N	488182.00	\N	488182.00	45455.00	10.27	7576.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084052	2026-03-03 08:39:06.084052
a5d25ccd-c7e2-4754-8d0a-91ffc84e85e4	2026-02-11	fa3774ae-dc33-4aae-9f10-3fcfd2ff3ade	103	SALES	3	890000.00	620000.00	780000.00	\N	\N	\N	\N	160000.00	\N	890000.00	\N	890000.00	110000.00	14.10	36667.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084055	2026-03-03 08:39:06.084056
610b08e4-1e9d-4609-88cf-6e20f254a1b0	2026-02-11	bf127d8e-e428-40ff-af91-d676a9d6a23f	110	SALES	95	2661955.00	2068292.00	2068292.00	\N	\N	\N	\N	\N	\N	2661955.00	\N	2661955.00	593663.00	28.70	6249.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084059	2026-03-03 08:39:06.084059
6ee4a739-355a-4cf0-979f-20f7116c1478	2026-02-11	6eb1110b-8ec8-487c-9a82-e2442663d029	117	SALES	23	13300000.00	11702500.00	12909000.00	\N	\N	\N	\N	1206500.00	\N	13300000.00	\N	13300000.00	391000.00	3.03	17000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084062	2026-03-03 08:39:06.084063
bb968fa5-3d6d-4f6a-9e6a-d6faa61d3bb7	2026-02-11	e2ccce5a-62ae-4221-bb15-4bffdf86bd8f	120	SALES	2	830000.00	842000.00	812000.00	\N	\N	\N	\N	-30000.00	\N	830000.00	\N	830000.00	18000.00	2.22	9000.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084066	2026-03-03 08:39:06.084066
ffe23c0a-f24a-417b-88c3-ba1e179b8216	2026-02-11	6eb1110b-8ec8-487c-9a82-e2442663d029	123	SALES	10	1060000.00	1136000.00	1026000.00	\N	\N	\N	\N	-110000.00	\N	1060000.00	\N	1060000.00	34000.00	3.31	3400.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084069	2026-03-03 08:39:06.08407
1a74aaa0-d8cf-43af-addf-63ed71f43416	2026-02-11	a17e9781-114b-40eb-802c-d840251348d9	126	SALES	36	12470000.00	10239400.00	10985400.00	\N	\N	\N	\N	716000.00	30000.00	12470000.00	\N	12470000.00	1484600.00	13.51	41239.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084073	2026-03-03 08:39:06.084073
479fdf14-52b7-4488-9466-180ac8483318	2026-02-11	c4ed6d88-ecf0-497d-bcf3-ae9370e8057b	129	SALES	4	1240000.00	816000.00	1011000.00	\N	\N	\N	\N	195000.00	\N	1240000.00	\N	1240000.00	229000.00	22.65	57250.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084076	2026-03-03 08:39:06.084077
e09be2e7-6ace-4c06-8f7d-8933acbaad92	2026-02-11	519e85f6-0e7a-4b16-bb79-4f15674ef834	139	SALES	3	53060.00	38727.00	38727.00	\N	\N	\N	\N	\N	\N	53060.00	\N	53060.00	14333.00	37.01	4778.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08408	2026-03-03 08:39:06.08408
2438e8e5-c0fb-4220-a1de-3d7133b842ad	2026-02-11	c3a020ac-224d-4ba1-acf3-c2c824eb5807	142	SALES	2	59604.00	47454.00	47454.00	\N	\N	\N	\N	\N	\N	59604.00	\N	59604.00	12150.00	25.60	6075.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084083	2026-03-03 08:39:06.084084
ae944aff-ae8e-475e-b597-16a6ffe07888	2026-02-11	e5ba134e-9970-4b16-adbd-ae9e22f8e024	179	SALES	1	409091.00	275000.00	330000.00	\N	\N	\N	\N	55000.00	\N	409091.00	\N	409091.00	79091.00	23.97	79091.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084087	2026-03-03 08:39:06.084087
7ff718da-b5de-4507-923e-0675a333de5b	2026-02-11	18bf6904-6745-49dd-995c-c74ae1cca540	183	SALES	4	1530000.00	1760000.00	1495000.00	\N	\N	\N	\N	-265000.00	\N	1530000.00	\N	1530000.00	35000.00	2.34	8750.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.08409	2026-03-03 08:39:06.08409
eef49049-bf4b-4f41-8a59-c8cf54edce05	2026-02-11	23c41e48-2784-4cd8-a920-ab87165b72bb	186	SALES	47	11220000.00	10058000.00	9976000.00	\N	\N	\N	\N	-82000.00	\N	11220000.00	\N	11220000.00	1244000.00	12.47	26468.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084094	2026-03-03 08:39:06.084094
994c7ad1-99ff-49b7-971a-6fc5eb941e41	2026-02-11	dfc10db2-0295-4794-afb6-77ff8fbfd8d3	199	SALES	9	2160000.00	1499000.00	2020000.00	\N	\N	\N	\N	521000.00	\N	2160000.00	\N	2160000.00	140000.00	6.93	15556.00	f	\N	\N	\N	OPEN	UNPAID	\N	c43a4227-25e4-49ec-aca6-052a258bcd58	d6d5ffc1-d162-4e76-a4c8-1fb92b8ff77f	2026-03-03 08:39:06.084097	2026-03-03 08:39:06.084097
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_import_jobs bank_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_jobs
    ADD CONSTRAINT bank_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: bank_import_lines bank_import_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_pkey PRIMARY KEY (id);


--
-- Name: branches branches_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_name_key UNIQUE (name);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: compare_list_models compare_list_models_model_id_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_model_id_key UNIQUE (model_id);


--
-- Name: compare_list_models compare_list_models_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_pkey PRIMARY KEY (id);


--
-- Name: counterparties counterparties_code_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_code_key UNIQUE (code);


--
-- Name: counterparties counterparties_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_name_key UNIQUE (name);


--
-- Name: counterparties counterparties_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_pkey PRIMARY KEY (id);


--
-- Name: counterparty_aliases counterparty_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_pkey PRIMARY KEY (id);


--
-- Name: counterparty_transactions counterparty_transactions_bank_reference_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_bank_reference_key UNIQUE (bank_reference);


--
-- Name: counterparty_transactions counterparty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_pkey PRIMARY KEY (id);


--
-- Name: deduction_items deduction_items_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_items
    ADD CONSTRAINT deduction_items_name_key UNIQUE (name);


--
-- Name: deduction_items deduction_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_items
    ADD CONSTRAINT deduction_items_pkey PRIMARY KEY (id);


--
-- Name: deduction_levels deduction_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_levels
    ADD CONSTRAINT deduction_levels_pkey PRIMARY KEY (id);


--
-- Name: grade_prices grade_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_pkey PRIMARY KEY (id);


--
-- Name: grades grades_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_name_key UNIQUE (name);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: hq_price_applies hq_price_applies_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_pkey PRIMARY KEY (id);


--
-- Name: hq_price_apply_locks hq_price_apply_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_apply_locks
    ADD CONSTRAINT hq_price_apply_locks_pkey PRIMARY KEY (id);


--
-- Name: netting_records netting_records_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_pkey PRIMARY KEY (id);


--
-- Name: netting_voucher_links netting_voucher_links_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_pkey PRIMARY KEY (id);


--
-- Name: partner_mappings partner_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_pkey PRIMARY KEY (id);


--
-- Name: partner_prices partner_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_pkey PRIMARY KEY (id);


--
-- Name: partners partners_name_key; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_name_key UNIQUE (name);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: period_locks period_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_pkey PRIMARY KEY (id);


--
-- Name: ssot_models ssot_models_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.ssot_models
    ADD CONSTRAINT ssot_models_pkey PRIMARY KEY (id);


--
-- Name: transaction_allocations transaction_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_pkey PRIMARY KEY (id);


--
-- Name: upload_jobs upload_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_pkey PRIMARY KEY (id);


--
-- Name: upload_templates upload_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_templates
    ADD CONSTRAINT upload_templates_pkey PRIMARY KEY (id);


--
-- Name: counterparty_aliases uq_counterparty_alias_name; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT uq_counterparty_alias_name UNIQUE (alias_name);


--
-- Name: netting_voucher_links uq_nvl_netting_voucher; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT uq_nvl_netting_voucher UNIQUE (netting_record_id, voucher_id);


--
-- Name: period_locks uq_period_lock_year_month; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT uq_period_lock_year_month UNIQUE (year_month);


--
-- Name: transaction_allocations uq_ta_transaction_voucher; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT uq_ta_transaction_voucher UNIQUE (transaction_id, voucher_id);


--
-- Name: user_counterparty_favorites uq_user_counterparty_favorite; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT uq_user_counterparty_favorite UNIQUE (user_id, counterparty_id);


--
-- Name: user_partner_favorites uq_user_partner_favorite; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT uq_user_partner_favorite UNIQUE (user_id, partner_id);


--
-- Name: vouchers uq_voucher_counterparty_date_number; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT uq_voucher_counterparty_date_number UNIQUE (counterparty_id, trade_date, voucher_number);


--
-- Name: user_counterparty_favorites user_counterparty_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_list_items user_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_pkey PRIMARY KEY (id);


--
-- Name: user_lists user_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_lists
    ADD CONSTRAINT user_lists_pkey PRIMARY KEY (id);


--
-- Name: user_partner_favorites user_partner_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: voucher_change_requests voucher_change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_pkey PRIMARY KEY (id);


--
-- Name: vouchers vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_action_created; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_action_created ON public.audit_logs USING btree (action, created_at);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_target; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_target ON public.audit_logs USING btree (target_type, target_id);


--
-- Name: ix_audit_logs_trace_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_trace_id ON public.audit_logs USING btree (trace_id);


--
-- Name: ix_audit_logs_user_created; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_audit_logs_user_created ON public.audit_logs USING btree (user_id, created_at);


--
-- Name: ix_bij_created_at; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bij_created_at ON public.bank_import_jobs USING btree (created_at);


--
-- Name: ix_bij_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bij_status ON public.bank_import_jobs USING btree (status);


--
-- Name: ix_bil_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_counterparty ON public.bank_import_lines USING btree (counterparty_id);


--
-- Name: ix_bil_duplicate_key; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_duplicate_key ON public.bank_import_lines USING btree (duplicate_key);


--
-- Name: ix_bil_import_job; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_import_job ON public.bank_import_lines USING btree (import_job_id);


--
-- Name: ix_bil_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_bil_status ON public.bank_import_lines USING btree (status);


--
-- Name: ix_compare_list_models_sort; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_compare_list_models_sort ON public.compare_list_models USING btree (sort_order);


--
-- Name: ix_ct_counterparty_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_counterparty_date ON public.counterparty_transactions USING btree (counterparty_id, transaction_date);


--
-- Name: ix_ct_source; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_source ON public.counterparty_transactions USING btree (source);


--
-- Name: ix_ct_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ct_status ON public.counterparty_transactions USING btree (status);


--
-- Name: ix_deduction_levels_item_name; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_deduction_levels_item_name ON public.deduction_levels USING btree (item_id, name);


--
-- Name: ix_grade_prices_model_grade; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_grade_prices_model_grade ON public.grade_prices USING btree (model_id, grade_id);


--
-- Name: ix_nr_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_counterparty ON public.netting_records USING btree (counterparty_id);


--
-- Name: ix_nr_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_date ON public.netting_records USING btree (netting_date);


--
-- Name: ix_nr_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_nr_status ON public.netting_records USING btree (status);


--
-- Name: ix_partner_mappings_partner_expression; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_partner_mappings_partner_expression ON public.partner_mappings USING btree (partner_id, partner_expression);


--
-- Name: ix_partner_prices_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_partner_prices_model ON public.partner_prices USING btree (model_id);


--
-- Name: ix_partner_prices_partner_model_grade; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_partner_prices_partner_model_grade ON public.partner_prices USING btree (partner_id, model_id, grade_id);


--
-- Name: ix_payments_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_payments_voucher_id ON public.payments USING btree (voucher_id);


--
-- Name: ix_receipts_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_receipts_voucher_id ON public.receipts USING btree (voucher_id);


--
-- Name: ix_ssot_models_model_code; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_ssot_models_model_code ON public.ssot_models USING btree (model_code);


--
-- Name: ix_ssot_models_model_key; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_model_key ON public.ssot_models USING btree (model_key);


--
-- Name: ix_ssot_models_series; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_series ON public.ssot_models USING btree (series);


--
-- Name: ix_ssot_models_type_manufacturer; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ssot_models_type_manufacturer ON public.ssot_models USING btree (device_type, manufacturer);


--
-- Name: ix_ta_transaction; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ta_transaction ON public.transaction_allocations USING btree (transaction_id);


--
-- Name: ix_ta_voucher; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_ta_voucher ON public.transaction_allocations USING btree (voucher_id);


--
-- Name: ix_user_counterparty_favorites_user_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_counterparty_favorites_user_id ON public.user_counterparty_favorites USING btree (user_id);


--
-- Name: ix_user_favorites_user_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_favorites_user_model ON public.user_favorites USING btree (user_id, model_id);


--
-- Name: ix_user_list_items_list_model; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_list_items_list_model ON public.user_list_items USING btree (list_id, model_id);


--
-- Name: ix_user_lists_user; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_lists_user ON public.user_lists USING btree (user_id);


--
-- Name: ix_user_lists_user_name; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_user_lists_user_name ON public.user_lists USING btree (user_id, name);


--
-- Name: ix_user_partner_favorites_user_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_user_partner_favorites_user_id ON public.user_partner_favorites USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_voucher_change_requests_voucher_id; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_voucher_change_requests_voucher_id ON public.voucher_change_requests USING btree (voucher_id);


--
-- Name: ix_vouchers_counterparty; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_counterparty ON public.vouchers USING btree (counterparty_id);


--
-- Name: ix_vouchers_trade_date; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_trade_date ON public.vouchers USING btree (trade_date);


--
-- Name: ix_vouchers_type_status; Type: INDEX; Schema: public; Owner: dwt_user
--

CREATE INDEX ix_vouchers_type_status ON public.vouchers USING btree (voucher_type, settlement_status);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_import_jobs bank_import_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_jobs
    ADD CONSTRAINT bank_import_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_import_lines bank_import_lines_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE SET NULL;


--
-- Name: bank_import_lines bank_import_lines_import_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_import_job_id_fkey FOREIGN KEY (import_job_id) REFERENCES public.bank_import_jobs(id) ON DELETE CASCADE;


--
-- Name: bank_import_lines bank_import_lines_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.bank_import_lines
    ADD CONSTRAINT bank_import_lines_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.counterparty_transactions(id) ON DELETE SET NULL;


--
-- Name: branches branches_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compare_list_models compare_list_models_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compare_list_models compare_list_models_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.compare_list_models
    ADD CONSTRAINT compare_list_models_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: counterparties counterparties_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: counterparty_aliases counterparty_aliases_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE CASCADE;


--
-- Name: counterparty_aliases counterparty_aliases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_aliases
    ADD CONSTRAINT counterparty_aliases_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_bank_import_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_bank_import_line_id_fkey FOREIGN KEY (bank_import_line_id) REFERENCES public.bank_import_lines(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: counterparty_transactions counterparty_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: counterparty_transactions counterparty_transactions_netting_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.counterparty_transactions
    ADD CONSTRAINT counterparty_transactions_netting_record_id_fkey FOREIGN KEY (netting_record_id) REFERENCES public.netting_records(id) ON DELETE SET NULL;


--
-- Name: deduction_levels deduction_levels_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.deduction_levels
    ADD CONSTRAINT deduction_levels_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.deduction_items(id) ON DELETE CASCADE;


--
-- Name: grade_prices grade_prices_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON DELETE RESTRICT;


--
-- Name: grade_prices grade_prices_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.grade_prices
    ADD CONSTRAINT grade_prices_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: hq_price_applies hq_price_applies_applied_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_applied_by_fkey FOREIGN KEY (applied_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hq_price_applies hq_price_applies_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_applies
    ADD CONSTRAINT hq_price_applies_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: hq_price_apply_locks hq_price_apply_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.hq_price_apply_locks
    ADD CONSTRAINT hq_price_apply_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_records netting_records_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_records netting_records_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: netting_records netting_records_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_records
    ADD CONSTRAINT netting_records_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: netting_voucher_links netting_voucher_links_netting_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_netting_record_id_fkey FOREIGN KEY (netting_record_id) REFERENCES public.netting_records(id) ON DELETE CASCADE;


--
-- Name: netting_voucher_links netting_voucher_links_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.netting_voucher_links
    ADD CONSTRAINT netting_voucher_links_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE RESTRICT;


--
-- Name: partner_mappings partner_mappings_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: partner_mappings partner_mappings_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_mappings
    ADD CONSTRAINT partner_mappings_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON DELETE RESTRICT;


--
-- Name: partner_prices partner_prices_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: partner_prices partner_prices_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partner_prices
    ADD CONSTRAINT partner_prices_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: partners partners_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: partners partners_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: period_locks period_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: period_locks period_locks_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.period_locks
    ADD CONSTRAINT period_locks_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: receipts receipts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: receipts receipts_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: transaction_allocations transaction_allocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transaction_allocations transaction_allocations_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.counterparty_transactions(id) ON DELETE CASCADE;


--
-- Name: transaction_allocations transaction_allocations_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.transaction_allocations
    ADD CONSTRAINT transaction_allocations_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE RESTRICT;


--
-- Name: upload_jobs upload_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: upload_jobs upload_jobs_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_jobs
    ADD CONSTRAINT upload_jobs_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: upload_templates upload_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.upload_templates
    ADD CONSTRAINT upload_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_counterparty_favorites user_counterparty_favorites_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE CASCADE;


--
-- Name: user_counterparty_favorites user_counterparty_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_counterparty_favorites
    ADD CONSTRAINT user_counterparty_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_list_items user_list_items_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.user_lists(id) ON DELETE CASCADE;


--
-- Name: user_list_items user_list_items_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_list_items
    ADD CONSTRAINT user_list_items_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ssot_models(id) ON DELETE CASCADE;


--
-- Name: user_lists user_lists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_lists
    ADD CONSTRAINT user_lists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_partner_favorites user_partner_favorites_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: user_partner_favorites user_partner_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.user_partner_favorites
    ADD CONSTRAINT user_partner_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: voucher_change_requests voucher_change_requests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: voucher_change_requests voucher_change_requests_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- Name: voucher_change_requests voucher_change_requests_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.voucher_change_requests
    ADD CONSTRAINT voucher_change_requests_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: vouchers vouchers_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE RESTRICT;


--
-- Name: vouchers vouchers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: vouchers vouchers_original_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_original_voucher_id_fkey FOREIGN KEY (original_voucher_id) REFERENCES public.vouchers(id) ON DELETE SET NULL;


--
-- Name: vouchers vouchers_upload_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwt_user
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_upload_job_id_fkey FOREIGN KEY (upload_job_id) REFERENCES public.upload_jobs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict iYDinn5hE3NQ5bgot3wSf8fVaXYKRfn25SQ8p3cRC5m7qC79mY3OTG0exFtzMuh

